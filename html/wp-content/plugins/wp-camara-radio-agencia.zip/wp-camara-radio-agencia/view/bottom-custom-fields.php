<?php require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
use radio\agencia\mapeamento\CamposDB as CamposDB;
?>

<div class="tab1">
    <table id="resumo" class="field-table resumo">
        <tr>
            <td>
                <div>
                    <label>Resumo:</label><br>
                    <textarea class="text-area-fields" style="resize: none;" id="excerpt" name="excerpt" rows="2" cols="40" data-label="Resumo" id="excerpt"><?php echo $this->radioAgencia->getResumo() ?></textarea>
                    <div class="qtd-caracteres">(<span id="resumo-qtd-c"></span> caracteres)</div>
                </div>
            </td>
        </tr>
    </table>
    <table id="rodape" class="field-table rodape">
        <tr>
            <td>
                <div style="width: 100%;">
                    <label>Rodapé:</label><br>
                    <textarea class="text-area-fields" style="resize: none;" name="<?= CamposDB::CD_RADIO_AGENCIA_RODAPE ?>" rows="1" cols="40" data-label="Rodapé" id="<?= CamposDB::CD_RADIO_AGENCIA_RODAPE ?>"><?php echo $this->radioAgencia->getRodape() ?></textarea>
                </div>
            </td>
        </tr>
    </table>
</div>

<div class="tab2">
    <table id="tags" class="field-table tags">
        <tr>
            <td>
                <div>
                    <label for="<?= CamposDB::CD_RADIO_AGENCIA_TAGS ?>"><b>Tags</b>:</label><br>
                    <select name="<?= CamposDB::CD_RADIO_AGENCIA_TAGS ?>[]" id="<?= CamposDB::CD_RADIO_AGENCIA_TAGS ?>" multiple="multiple" style="width: 92%;">
                        <?php foreach ($this->getTags() as $tag) :
                            if (in_array($tag, $this->radioAgencia->getTags())) {
                                echo "<option selected='selected' value=\"$tag->id\" >$tag->titulo</option>";
                            } else {
                                echo "<option value=\"$tag->id\" >$tag->titulo</option>";
                            }
                        endforeach; ?>
                    </select>
                </div>
            </td>
        </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
        <tr>
            <td>
                <div class="tb-container">
                    <div class="conteudo-relacionado">
                        <table>
                            <tr>
                                <td>
                                    <div class="box-titulo"><b>Conteúdo Relacionado</b></div>
                                </td>
                                <td class="td-associar"><button class="button add_media" type="button" onclick="open_dlg_associar()">Associar</button></td>
                            <tr>
                        </table>
                        <input type="hidden" name="<?php echo CamposDB::CD_RADIO_AGENCIA_RELACIONADA ?>" id="<?php echo CamposDB::CD_RADIO_AGENCIA_RELACIONADA ?>" />

                        <!-- Campo para controle  -->
                        <input type="hidden" name="post_id" id="post_id" value="<?php echo get_the_ID() ?>" />

                        <table id="grid-relacionadas" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </td>
        </tr>
    </table>
</div>