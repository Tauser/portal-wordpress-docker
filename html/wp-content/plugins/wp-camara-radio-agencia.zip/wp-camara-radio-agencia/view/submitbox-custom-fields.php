<?php require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php'); 
use radio\agencia\mapeamento\CamposDB as CamposDB;
?>

<div class="tema-principal">
    <label for="<?= CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL ?>" class="required"><b>Tema Principal: </b></label>
    <select id="<?= CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL ?>" name="<?= CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL ?>"  style="width: 100%">
        <option value="">Selecione</option>
        <?php foreach ($this->getTemas() as $tema) :
            if ($this->radioAgencia->getTemaPrincipal() && $this->radioAgencia->getTemaPrincipal()->id == $tema->id) {
                echo "<option selected='selected' value=\"$tema->id\" >$tema->titulo</option>";
            } else {
                echo "<option value=\"$tema->id\" >$tema->titulo</option>";
            }
        endforeach; ?>
    </select>
</div>

<div class="outros-temas">
    <label style="margin-left: 5px;" for="<?= CamposDB::CD_RADIO_AGENCIA_TEMAS ?>"><b>Outros temas: </b></label>
    <select name="<?= CamposDB::CD_RADIO_AGENCIA_TEMAS ?>[]" id="<?= CamposDB::CD_RADIO_AGENCIA_TEMAS ?>" multiple="multiple" style="width: 100%;">
        <?php foreach ($this->getTemas() as $tema) :
            if (in_array($tema, $this->radioAgencia->getTemas())) {
                echo "<option selected='selected' value=\"$tema->id\" >$tema->titulo</option>";
            } else {
                echo "<option value=\"$tema->id\" >$tema->titulo</option>";
            }
        endforeach; ?>
    </select>
</div>

<div class="misc-pub-section curtime misc-pub-curtime">
<input type="checkbox" name="<?= CamposDB::CD_RADIO_AGENCIA_VISIVEL_HOME ?>" <?=$this->radioAgencia->getVisivelHome() == 'true' ? 'checked' : '' ?>>
<label>Visível na Home</label>
</div>
<div class="misc-pub-section curtime misc-pub-curtime">
<input type="checkbox" name="<?= CamposDB::CD_RADIO_AGENCIA_VISIVEL_BOLETIM ?>" <?=$this->radioAgencia->getVisivelBoletim() == 'true' ? 'checked' : ''?>>
<label>Visível no Boletim</label>
</div>
<div class="misc-pub-section curtime misc-pub-curtime">
<input type="checkbox" name="<?= CamposDB::CD_RADIO_AGENCIA_PORTAL_CONGRESSO ?>" <?=$this->radioAgencia->getPortalCongresso() == 'true' ? 'checked' : ''?>>
<label>Visível no Portal do Congresso</label>
</div>