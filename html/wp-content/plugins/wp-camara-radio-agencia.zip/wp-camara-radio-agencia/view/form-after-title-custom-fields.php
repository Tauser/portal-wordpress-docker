<?php require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
use radio\agencia\mapeamento\CamposDB as CamposDB;
?>
<table id="tipo-midia-select" class="tab1">
    <tr>
        <td>
            <div style="padding-right: 10px;">
                <label class="required">Tipo:</label><br/>
                <select name="<?= CamposDB::CD_RADIO_AGENCIA_TIPO ?>" id="<?= CamposDB::CD_RADIO_AGENCIA_TIPO ?>" style="width: 130px;">
                    <option value="">Selecione</option>
                    <?php foreach ($this->radioAgencia->getTipos() as $key => $value) :
                        if ($this->radioAgencia->getTipo() == $key) {
                            echo "<option selected='selected' value=\"$key\" >$value</option>";
                        } else {
                            echo "<option value=\"$key\" >$value</option>";
                        }
                    endforeach; ?>

                </select>
            </div>
        </td>
        <td>
            <div style="padding-right: 10px;">
                <label class="required">Midia:</label><br/>
                <select name="<?= CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA ?>" id="<?= CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA ?>" style="width: 130px;">
                    <option value="">Selecione</option>
                    <?php foreach ($this->radioAgencia->getTiposMidias() as $key => $value) :
                        if ($this->radioAgencia->getTipoMidia() == $key) {
                            echo "<option selected='selected' value=\"$key\" >$value</option>";
                        } else {
                            echo "<option value=\"$key\" >$value</option>";
                        }
                    endforeach; ?>

                </select>
            </div>
        </td>
    </tr>
</table>
<table id="retranca" class="field-table retranca">
        <tr>
            <td>
                <div>
                    <label>Retranca:</label><br>
                    <textarea class="text-area-fields" style="resize: none;" id="<?= CamposDB::CD_RADIO_AGENCIA_RETRANCA ?>" name="<?= CamposDB::CD_RADIO_AGENCIA_RETRANCA ?>" rows="2" cols="40" data-label="Retranca" id="retranca"><?php echo $this->radioAgencia->getRetranca() ?></textarea>
                    <div class="qtd-caracteres">(<span id="cd_retranca-qtd-c"></span> caracteres)</div>
                </div>
            </td>
        </tr>
</table>