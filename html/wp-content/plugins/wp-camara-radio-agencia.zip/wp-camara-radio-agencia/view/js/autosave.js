jQuery(document).ajaxSend(function(e, x, a) {
    // Adicionando todos os parametros do formulário.
    var arrayForm = jQuery('#post').serializeArray();
    var arrayCamposInseridos = [];
    for (index in arrayForm) {
        var field = arrayForm[index];
        if (field.name.startsWith("cd") || field.name.startsWith("cd")) {
            var renderObject = {};
            var fieldName = field.name;
            var fieldValue = field.value;
            // Valida o valor do campo e verifica se ele já não foi inserido, pois no form existem campos duplicados
            if (fieldValue != null && fieldValue !== '' 
                &&  String(fieldValue).length !== 0 
                && String(fieldValue) !== "0"
                && jQuery.inArray(fieldName.toString(), arrayCamposInseridos) === -1) {
                // Cria novo objeto
                renderObject[fieldName.toString()] = fieldValue;
                arrayCamposInseridos.push(fieldName.toString());
                a.data += '&' + jQuery.param( renderObject );
            }
        }
    }
});