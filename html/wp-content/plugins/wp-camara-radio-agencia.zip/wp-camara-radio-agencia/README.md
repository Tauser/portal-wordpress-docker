# PLUGIN DO WORDPRESS - RÁDIO AGÊNCIA

## CAMPOS CUSTOMIZADOS SALVOS NA TABELA POST META

```
post_type = radioagencia

cd_radioAgencia_rodape [texto]
cd_radioAgencia_tipo [caixa de seleção (1 escolha)]
cd_radioAgencia_relacionada [caixa de seleção (n escolhas, 1 registro meta para o ID de cada POST)]
cd_radioAgencia_portalDoCongresso [boolean]
cd_radioAgencia_visivelHome [boolean]
cd_radioAgencia_visivelBoletim [boolean]
cd_radioAgencia_temas [caixa de seleção (n escolhas, 1 registro meta para o ID de cada Taxonomia 'Tema')]
cd_radioAgencia_temaPrincipal [caixa de seleção (1 escolha)]
cd_radioAgencia_temaDoDia [caixa de seleção (n escolhas, 1 registro meta para o ID de cada Taxonomia 'Tema do dia')]

```

![alt text](ARQUITETURA -  PLUGIN.PNG.png)