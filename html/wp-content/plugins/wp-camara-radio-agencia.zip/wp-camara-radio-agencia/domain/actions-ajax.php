<?php namespace radio\agencia\domain;

abstract class ActionsAjax
{
    const VALIDATOR_RADIO_AGENCIA = "validador_radio_agencia";
    const TEMA_DO_DIA = "temadodia_radio_agencia";
    const TAGS = "tags_radio_agencia";
    const RELACIONADAS = "obter_relacionadas_radio_agencia";
    const DUPLICAR_POST = "radio_agencia_duplicate_post";

    public static function getValores() {
        return array(self::VALIDATOR_RADIO_AGENCIA, 
                    self::TEMA_DO_DIA,
                    self::RELACIONADAS,
                    self::TAGS,
                    self::DUPLICAR_POST);
    }
}

?>