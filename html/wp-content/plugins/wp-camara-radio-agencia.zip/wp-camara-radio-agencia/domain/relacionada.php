<?php namespace radio\agencia\domain;

class Relacionada
{

    public function __construct($id, $titulo, $data, $thumbnail, $resumo, $tipoDePost) {
        $this->ID = $id;
        $this->titulo = $titulo;
        $this->data = date('d/m/Y', strtotime($data));
        $this->thumbnail = $thumbnail;
        $this->resumo = str_replace('"', "'", $resumo);
        $this->tipoDePost = $tipoDePost;
    }

    public function getId() {
        return $this->ID;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function getData() {
        return $this->data;
    }

    public function getThumbnail() {
        return $this->thumbnail;
    }

    public function getResumo () {
        return $this->resumo;
    }

    public function getTipoDePost() {
        return $this->tipoDePost;
    }

}

?>