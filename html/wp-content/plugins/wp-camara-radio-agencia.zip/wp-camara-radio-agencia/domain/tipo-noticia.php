<?php namespace radio\agencia\domain;

abstract class TipoNoticia
{
    const NOTICIA = "Notícia";
    const BLOCO_DE_PROGRAMA = "Bloco de Programa";
    const INTEGRA = "Íntegra";
    const TITULO = "Título";

    public static function getKey($value) {
        $class = new \ReflectionClass(__CLASS__);
        $constants = array_flip($class->getConstants());
        return $constants[$value];
    }

    public static function getValores() {
        return array('NOTICIA' => self::NOTICIA, 
                    'BLOCO_DE_PROGRAMA' => self::BLOCO_DE_PROGRAMA, 
                    'INTEGRA' => self::INTEGRA, 
                    'TITULO' => self::TITULO);
    }
}

?>