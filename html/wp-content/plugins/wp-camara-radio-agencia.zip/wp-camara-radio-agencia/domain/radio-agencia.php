<?php namespace radio\agencia\domain;

require_once(plugin_dir_path(__FILE__) . './tipo-noticia.php');
require_once(plugin_dir_path(__FILE__) . './tipo-midia.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');

use radio\agencia\mapeamento\CamposDB as CamposDB;
use radio\agencia\domain\TipoNoticia as TipoNoticia;
use radio\agencia\domain\TipoMidia as TipoMidia;

class RadioAgencia {

    private $title;
    private $content;
    private $tipo;
    private $visivelHome;
    private $visivelBoletim;
    private $rodape;
    private $portalCongresso;
    private $temaPrincipal;
    private $temas;
    private $relacionadas;
    private $tipoMidia;
    private $tags;
    private $resumo;
    private $retranca;

    public function __construct($title, $content, $tipo, $visivelHome, $visivelBoletim, $rodape, $portalCongresso, $temaPrincipal, $temas, $relacionadas, $tipoMidia, $tags, $resumo, $retranca) {
        $this->title = $title;
        $this->content = $content;
        $this->tipo = $tipo == null ? TipoNoticia::getKey(TipoNoticia::NOTICIA) : $tipo;
        $this->rodape = sanitize_text_field($rodape);
        $this->temaPrincipal = $temaPrincipal;
        $this->temas = is_array($temas) ? $temas : array($temas);
        $this->tags = is_array($tags) ? $tags : array($tags);
        $this->tipoMidia = $tipoMidia == null ? TipoMidia::getKey(TipoMidia::AUDIO) : $tipoMidia;

        if (!is_array($relacionadas) && !empty($relacionadas) && !is_null($relacionadas)) {
            $this->relacionadas = explode(',', $relacionadas);
        } else if (!is_null($relacionadas)) {
            $this->relacionadas = $relacionadas;
        }
        $this->resumo = $resumo;
        $this->retranca = $retranca;

        // Adiciona o valor default como true
        $this->set_default_value_checkbox($portalCongresso, $visivelBoletim, $visivelHome);
    }

    private function set_default_value_checkbox ($portalCongresso, $visivelBoletim, $visivelHome) {
        $is_new = !$this->check_is_new_object();

        if ($portalCongresso == null && $is_new ) {
            $this->portalCongresso = true;
        } else if ($portalCongresso == null && !$is_new) {
            $this->portalCongresso = false;
        } else {
            $this->portalCongresso = true;
        }

        if ($visivelBoletim == null && $is_new ) {
            $this->visivelBoletim = true;
        } else if ($visivelBoletim == null && !$is_new) {
            $this->visivelBoletim = false;
        } else {
            $this->visivelBoletim = true;
        }

        if ($visivelHome == null && $is_new ) {
            $this->visivelHome = true;
        } else if ($visivelHome == null && !$is_new) {
            $this->visivelHome = false;
        } else {
            $this->visivelHome = true;
        }
    } 

    private function check_is_new_object () {
        return $this->title != "" || $this->content != "" || $this->temaPrincipal;
    }

    public function getRetranca() {
        return $this->retranca;
    }

    public function getResumo() {
        return $this->resumo;
    }

    public function getTipoMidia() {
        return $this->tipoMidia;
    }

    public function getTiposMidias() {
        return TipoMidia::getValores();
    }

    public function getTemaPrincipal() {
        return $this->temaPrincipal;
    }

    public function getTemas() {
        return $this->temas;
    }

    public function getTags() {
        return $this->tags;
    }

    public function getRelacionadas() {
        return $this->relacionadas;
    }

    public function getTipos() {
        return TipoNoticia::getValores();
    }

    public static function validarTotalCaracteres($post_data, $values) {
        $fields = '';
        if ($post_data['post_status'] != 'trash') {
            if (!empty($values[CamposDB::CD_RADIO_AGENCIA_RETRANCA]) && strlen($values[CamposDB::CD_RADIO_AGENCIA_RETRANCA]) > 128) {
                $fields = $fields .  "Digite somente 128 caracteres para Retranca, ";
            }
        }
        return substr(trim($fields), 0, -1);
    }

    public static function isRequired($post_data, $values) {
        $fields = '';
        if ($post_data['post_status'] != 'trash') {
            if (empty($values[CamposDB::CD_RADIO_AGENCIA_TIPO])) {
                $fields = $fields .  "Tipo de Notícia, ";
            }
            if (empty($values[CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA])) {
                $fields = $fields .  "Tipo de Midia, ";
            }
            if (empty($values['post_title'])) {
                $fields = $fields . "Título, ";
            }
            if (empty($values['post_content'])) {
                $fields = $fields . "Conteúdo, ";
            }
            if (empty($values[CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL])) {
                $fields = $fields .  "Tema Principal, ";
            }
        }
        return substr(trim($fields), 0, -1);
    }

    public function getPortalCongresso() {
        return $this->portalCongresso == 1 ? true : false;
    }

    public function getVisivelBoletim() {
        return $this->visivelBoletim == 1 ? true : false;
    }

    public function getVisivelBoletimBoolean() {
        return $this->visivelBoletim;
    }

    public function getVisivelHome() {
        return $this->visivelHome == 1 ? true : false;
    }

    public function getVisivelHomeBoolean() {
        return $this->visivelHome;
    }

    public function getPortalCongressoBoolean() {
        return $this->portalCongresso;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getRodape() {
        return sanitize_text_field($this->rodape);
    }
}
?>