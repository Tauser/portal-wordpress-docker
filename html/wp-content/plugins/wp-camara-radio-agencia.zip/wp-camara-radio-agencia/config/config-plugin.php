<?php namespace radio\agencia\config;

require_once(plugin_dir_path(__FILE__) . './config-form.php');
require_once(plugin_dir_path(__FILE__) . './config-styles.php');
require_once(plugin_dir_path(__FILE__) . './config-scripts.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');

use radio\agencia\config\ConfigForm as ConfigForm;
use radio\agencia\config\ConfigStyles as ConfigStyles;
use radio\agencia\config\ConfigScripts as ConfigScripts;
use radio\agencia\domain\ActionsAjax as ActionsAjax;

class ConfigPlugin
{
    private const PLUGIN_NAME = 'Rádio Agência';
    private const PLUGIN_SINGULAR_NAME = 'Rádio Agência';
    private const PLUGIN_DESCRIPTION = 'Posts de Rádio Agência';
    private const PLUGIN_ADD_NEW = 'Nova Notícia';
    private const PLUGIN_SEARCH_ITEMS = 'Pesquisar Notícia de Rádioagência';
    private const PLUGIN_ADD_NEW_ITEM = 'Adicionar Nova Notícia';
    private const PLUGIN_EDIT_ITEM = 'Edita Notícia';
    public const POST_TYPE_NAME = 'radioagencia';
    private const URL_PREVIEW_TES = 'https://socittes.camara.gov.br';
    private $baseUrl;
    private $actions_ajax;
    private $configScripts;

    public function __construct($baseUrl)
    {
        $this->baseUrl = $baseUrl;
        $this->actions_ajax = array();
        $this->configScripts = new ConfigScripts();
    }

    public function config()
    {
        $this->register_post_type();
    
        if ($this->isWPPreview()) {
            return $this->process(true);
        }
        if ($this->isHeartbeat()) {
            return $this->process(true);
        }
        if ($this->isActionAjaxCustom()) {
            return $this->process(true);
        }
        if ($this->isPostTypeValid()) {
            return $this->process(true);
        }
        return false;
    }

    private function process($valid) {
        if ($valid) {
            $this->config_filters();
            new ConfigStyles($this->baseUrl);
            $this->configScripts->config_scripts($this->baseUrl);
            $this->configForm()->config_remove_meta_box(self::POST_TYPE_NAME);
        }
        return $valid;
    }

    public function configForm()
    {
        return new ConfigForm();
    }

    public function add_ajax_action($action, $callback)
    {
        $this->configScripts->add_ajax_action($action, $callback);
    }

    public function register_post_type()
    {
        register_post_type(self::POST_TYPE_NAME, $this->config_post_type());
    }

    /**
     * Metodo para retornar a url do preview
     * Tem que ser public porque e acessado por um hook
     */
    public function config_the_preview_fix()
    {
        return $this->get_link_preview();
    }

    private function config_post_type()
    {
        return array(
            'labels' => array(
                'name' => self::PLUGIN_NAME,
                'singular_name' => self::PLUGIN_SINGULAR_NAME,
                'add_new' => self::PLUGIN_ADD_NEW,
                'search_items' => self::PLUGIN_SEARCH_ITEMS,
                'add_new_item' => self::PLUGIN_ADD_NEW_ITEM,
                'edit_item' => self::PLUGIN_EDIT_ITEM
            ),
            'description' => self::PLUGIN_DESCRIPTION,
            'supports' => array(
                'title', 'revisions', 'editor'
            ),
            'public' => true,
            'menu_icon' => 'dashicons-megaphone',
            'menu_position' => 16,
            'rewrite' => false
        );

    }

    private function config_filters()
    {
        add_filter('post_link', array($this, 'config_the_preview_fix'));
        add_filter('preview_post_link', array($this, 'config_the_preview_fix'));
        add_filter('post_row_actions', array($this, 'alter_link_preview'), 10, 2 );
    }

    function alter_link_preview( $actions, $post ) {
        if ($post->post_type == self::POST_TYPE_NAME) {
            $actions['view'] = '<a href="' . $this->get_link_preview() . '">Visualizar</a>';
        }
        return $actions;
    }

    private function isHeartbeat () {
        return $_POST['action'] == 'heartbeat' && $_POST['screen_id'] == self::POST_TYPE_NAME;
    }

    private function isWPPreview () {
        return isset($_POST['wp-preview']) && 'dopreview' == $_POST['wp-preview']  && $_POST['post_type'] == self::POST_TYPE_NAME;
    }

    private function isActionAjaxCustom () {
        if ($_POST['action'] || $_GET['action'] != 'edit') {
            $actions_ajax = ActionsAjax::getValores();
            if (in_array($_POST['action'], $actions_ajax) || in_array($_GET['action'], $actions_ajax)) {
                return true;
            }
        }
        return false;
    }

    private function isPostTypeValid() {
        if ($_GET['post_type'] || $_GET['post'] || $_POST['post_type']) {
            $post_type = $_GET['post_type'] ? $_GET['post_type'] : get_post_type($_GET['post']);
            if ($post_type == self::POST_TYPE_NAME || $_POST['post_type'] == self::POST_TYPE_NAME) {
                return true;
            }
        }
        return false;
    }

    private function get_link_preview() {
        $link = get_permalink(get_the_ID());
        switch (getenv("WP_AMBIENTE")) {
            case "dev":
                return self::URL_PREVIEW_TES . $link;
            default:
                return $link;
        }
    }
}

?>