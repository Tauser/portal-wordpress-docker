<?php namespace radio\agencia\config;

class ConfigForm {

    public function config_remove_meta_box($postType) {
        $this->postType = $postType;
        add_action( 'admin_menu' , array($this, 'remove_page_fields'));
         // Removendo 'opções de tela'
        add_filter('screen_options_show_screen', '__return_false');
    }

    public function remove_page_fields() {
        // removendo meta box slug
        remove_meta_box( 'slugdiv' , $this->postType , 'normal' ); 
        // removendo meta box tema do dia
        remove_meta_box( 'tagsdiv-tema_do_dia' , $this->postType , 'normal' ); 
        // removendo meta box glossario
        remove_meta_box( 'tagsdiv-glossario-tema_do_dia' , $this->postType , 'normal' );
        remove_meta_box( 'tagsdiv-glossario' , $this->postType , 'normal' );
    }

    public function config_edit_form_top($callback) {
        $this->validatorCallbackActions($callback);
        add_action('edit_form_top', $callback);
    }

    public function config_edit_form_after_editor($callback) {
        $this->validatorCallbackActions($callback);
        add_action('edit_form_after_editor', $callback);
    }

    public function config_edit_form_after_title($callback) {
        $this->validatorCallbackActions($callback);
        add_action('edit_form_after_title', $callback);
    }

    public function config_post_submitbox_misc_actions($callback) {
        $this->validatorCallbackActions($callback);
        add_action('post_submitbox_misc_actions', $callback);
    }

    public function config_save_post($callback) {
        $this->validatorCallbackActions($callback);
        add_action('save_post', $callback, 10, 3);
    }

    public function config_pre_post_update($callback) {
        $this->validatorCallbackActions($callback);
        add_action('pre_post_update', $callback, 10, 2);
    }

    private function validatorCallbackActions($callback) {
        if(!is_array($callback)) {
            throw new \Exception('O formato do callback deve ser um array. Ex: array($this, "nome do método") ');
        }
    }
}

?>