<?php namespace radio\agencia\config;

class ConfigStyles {

    public function __construct($baseUrl) {
        $this->config_styles($baseUrl);
    }

    private function config_styles($baseUrl) {
        wp_register_style('radio-agencia-css', $baseUrl . '/view/css/radio-agencia.css');
        wp_enqueue_style('radio-agencia-css');
        wp_register_style('radio-agencia-select2-css', $baseUrl . '/view/css/select2.min.css');
        wp_enqueue_style('radio-agencia-select2-css');
        wp_register_style('radio-agencia-datatables', $baseUrl . '/view/css/datatables.min.css');
        wp_enqueue_style('radio-agencia-datatables');
    }
}

?>