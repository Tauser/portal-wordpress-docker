<?php namespace radio\agencia\config;

class ConfigDuplicatePost
{   
    private $post_type;
    private const DUPLICATE_SETTINGS_FIELD_NAME = 'radio_agencia_post_duplicator_settings';
    public const JS_NONCE_SECURITY_NAME = 'camara_radio_agencia_ajax_file_nonce';

    public function __construct($post_type)
    {
        $this->post_type = $post_type;
        $this->initActions();
        $this->register_filters();
    }

    private function initActions() {
        // Registra o botão de duplicar post na edição do post
        add_action( 'post_submitbox_misc_actions', array($this, 'post_duplicator_submitbox'));
        add_action('admin_notices', array($this, 'post_duplicator_notice'));
    }

    public function post_duplicator_action_row( $actions, $post ){
        $actions['duplicate_post'] = $this->post_duplicator_action_row_link( $post );
        return $actions;
    }

    private function register_filters () {
        add_filter( 'post_row_actions', array($this, 'post_duplicator_action_row'), 10, 2 );
        add_filter( 'page_row_actions', array($this, 'post_duplicator_action_row'), 10, 2 );
        add_filter( 'cuar/core/admin/content-list-table/row-actions', array($this, 'post_duplicator_action_row'), 10, 2 );
    }

    public function post_duplicator_submitbox( $post ) {
        $nonce = wp_create_nonce(self::JS_NONCE_SECURITY_NAME); ?>
            <div class="misc-pub-section misc-pub-duplicator" id="duplicator">
                <a class="camara-duplicate-post button button-small" rel="<?php echo $nonce; ?>" href="#" data-postid="<?php echo $post->ID; ?>">Duplicar</a><span class="spinner" style="float:none;margin-top:2px;margin-left:4px;"></span>
            </div>
        <?php
    }

    private function post_duplicator_action_row_link( $post ) {
        $nonce = wp_create_nonce( self::JS_NONCE_SECURITY_NAME );
        return '<a class="camara-duplicate-post" rel="'.$nonce.'" href="#" data-postid="'.$post->ID.'">Duplicar</a>';
    }

    public function get_post_duplicate_settings() {
	
        $settings = get_option(self::DUPLICATE_SETTINGS_FIELD_NAME, array());
        
        $defaults = array(
            'status' => 'same',
            'type' => 'same',
            'timestamp' => 'current',
            'title' => __('Copia', $this->post_type),
            'slug' => 'copia',
            'time_offset' => false,
            'time_offset_days' => 0,
            'time_offset_hours' => 0,
            'time_offset_minutes' => 0,
            'time_offset_seconds' => 0,
            'time_offset_direction' => 'newer'
        );
        
        // Filter the settings
        $settings = apply_filters(self::DUPLICATE_SETTINGS_FIELD_NAME, $settings );
        
        // Return the settings
        return wp_parse_args( $settings, $defaults );
    }

    /** Apresenta a mensagem de sucesso em caso de duplicação do post */
    public function post_duplicator_notice() {
        
        $duplicated_id = isset($_GET['post-duplicated']) ? htmlspecialchars($_GET['post-duplicated'], ENT_QUOTES, 'UTF-8') : '';
        if( $duplicated_id != '' ) {
            
            $settings = $this->get_post_duplicate_settings();
        
            // Get the post type object
            $duplicated_post = get_post($duplicated_id);
            $post_type = get_post_type_object( $duplicated_post->post_type );
            
            // Set the button label
            $pt = $post_type->labels->singular_name;
            $link = '<a href="'.get_edit_post_link($duplicated_id).'">'.__('Aqui', $this->post_type).'</a>';
            $label = sprintf( __( 'Rádio agência duplicada com sucesso ! Você pode editar %1$s %2$s.', $this->post_type), $pt, $link );
            
            ?>
            <div class="updated">
            <p><?php echo $label; ?></p>
            </div>
            <?php
        }
    }



}

?>