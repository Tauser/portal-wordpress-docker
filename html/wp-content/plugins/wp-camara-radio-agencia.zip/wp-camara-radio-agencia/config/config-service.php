<?php namespace radio\agencia\config;
require_once(plugin_dir_path(__FILE__) . '../service/radio-agencia-service.php');

use radio\agencia\service\RadioAgenciaService as RadioAgenciaService;

class ConfigService {
    public function radioAgenciaService () {
        return new RadioAgenciaService();
    }
}

?>