<?php namespace radio\agencia\config;

class ConfigScripts
{

    public function __construct() {
        $this->actions_ajax = array();
    } 

    public function add_ajax_action($action, $callback) {
        $this->validatorCallbackActions($callback);
        add_action('wp_ajax_' . $action, $callback);
        add_action('wp_ajax_nopriv_' . $action, $callback); 
        return $action;
    }

    public function get_actions_ajax() {
        return $this->actions_ajax;
    }

    public function config_scripts($baseUrl)
    {
        global $pagenow;

        if ($pagenow != 'edit.php') {
            wp_enqueue_script('custom_form_js', $baseUrl . '/view/js/custom-scripts.js');
            wp_enqueue_script('select2-js', $baseUrl . '/view/js/select2.min.js');
            wp_enqueue_script('datatables_radio_agencia', $baseUrl . '/view/js/datatables.min.js');
            wp_enqueue_script('autosave_custom', $baseUrl . '/view/js/autosave.js');
            wp_enqueue_script('validador_radio_agencia', $baseUrl . '/view/js/form-validator.js');
            wp_enqueue_script('autocomplete_radio_agencia', $baseUrl . '/view/js/autocomplete.js');
            wp_enqueue_script('materias_relacionadas_radio_agencia', $baseUrl . '/view/js/materias-relacionadas.js');
            wp_enqueue_script('radio_agencia_duplicate_post_js', $baseUrl . '/view/js/post-duplicate.js');
            wp_enqueue_script('i18n_pt_BR', $baseUrl . '/view/js/pt-BR.js');
        }
    }

    private function validatorCallbackActions($callback) {
        if(!is_array($callback)) {
            throw new \Exception('O formato do callback deve ser um array. Ex: array($this, "nome do método") ');
        }
    }
}

?>