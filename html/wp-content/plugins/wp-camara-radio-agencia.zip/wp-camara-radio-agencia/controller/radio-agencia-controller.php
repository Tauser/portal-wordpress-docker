<?php namespace radio\agencia\controller;

require_once(plugin_dir_path(__FILE__) . '../domain/radio-agencia.php');
require_once(plugin_dir_path(__FILE__) . '../util/message-util.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');

use radio\agencia\util\MessageUtil as MessageUtil;
use radio\agencia\mapeamento\CamposDB as CamposDB;
use radio\agencia\domain\RadioAgencia as RadioAgencia;
use radio\agencia\domain\ActionsAjax as ActionsAjax;

class RadioAgenciaController
{

    private $messageUtil;
    private $radioAgencia;
    private $radioAgenciaService;
    private $configPlugin;
    private $configForm;

    public function __construct($configPlugin, $radioAgenciaService)
    {
        $this->configPlugin = $configPlugin;
        if ($this->configPlugin->config()) {
            $this->configForm = $configPlugin->configForm();
            $this->messageUtil = new MessageUtil($radioAgenciaService);
            $this->radioAgencia = null;
            $this->radioAgenciaService = $radioAgenciaService;
            $this->init_form();
            $this->add_scripts();
        }
    }

    /**
     * Metodo para validacao dos campos
     * Tem que ser public porque e acessado por um hook
     */
    public function pre_post_update($post_id, $post_data)
    {
        if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || $_GET['action'] == 'trash' || $_GET['action'] == 'untrash') {
            return;
        }
        $obrigatorios = RadioAgencia::isRequired($post_data, $_POST);
        if ($obrigatorios != '') {
            $this->messageUtil->errorFieldsRequired(false, $obrigatorios);
            return;
        }
        $totalCaracteres = RadioAgencia::validarTotalCaracteres($post_data, $_POST);
        if ($totalCaracteres != '') {
            $this->messageUtil->errorFields(false, $totalCaracteres);
        }
    }

    /**
     * Metodo para salvar os customs fields
     * Tem que ser public porque e acessado por um hook
     */
    public function save_radio_agencia($post_ID)
    {
        $this->radioAgenciaService->save(
            $post_ID,
            new RadioAgencia(
                $_POST['post_title'],
                $_POST['content'],
                $_POST[CamposDB::CD_RADIO_AGENCIA_TIPO],
                $_POST[CamposDB::CD_RADIO_AGENCIA_VISIVEL_HOME],
                $_POST[CamposDB::CD_RADIO_AGENCIA_VISIVEL_BOLETIM],
                $_POST[CamposDB::CD_RADIO_AGENCIA_RODAPE],
                $_POST[CamposDB::CD_RADIO_AGENCIA_PORTAL_CONGRESSO],
                $_POST[CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL],
                $_POST[CamposDB::CD_RADIO_AGENCIA_TEMAS],
                $_POST[CamposDB::CD_RADIO_AGENCIA_RELACIONADA],
                $_POST[CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA],
                $_POST[CamposDB::CD_RADIO_AGENCIA_TAGS],
                null,
                $_POST[CamposDB::CD_RADIO_AGENCIA_RETRANCA]
            )
        );
    }

    /**
     * Metodo para registar os customs fields
     * Tem que ser public porque e acessado por um hook
     */
    public function form_top_custom_field($post)
    {
        $this->radioAgencia = new RadioAgencia(
            $post->post_title,
            $post->post_content,
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_TIPO),
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_VISIVEL_HOME),
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_VISIVEL_BOLETIM),
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_RODAPE),
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_PORTAL_CONGRESSO),
            $this->radioAgenciaService->get_tema_principal($post->ID, CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL, 'tema'),
            $this->radioAgenciaService->get_temas_by_id_post($post->ID),
            $this->radioAgenciaService->get_relacionadas($post->ID, CamposDB::CD_RADIO_AGENCIA_RELACIONADA),
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA),
            $this->radioAgenciaService->get_tags_by_id_post($post->ID),
            $post->post_excerpt,
            $this->radioAgenciaService->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_RETRANCA)
        );
        include(plugin_dir_path(__FILE__) . '../view/top-custom-fields.php');
    }

    public function bottom_custom_fields($post)
    {
        include(plugin_dir_path(__FILE__) . '../view/bottom-custom-fields.php');
    }

    public function form_after_title_custom_field($post)
    {
        include(plugin_dir_path(__FILE__) . '../view/form-after-title-custom-fields.php');
    }

    public function submitbox_custom_fields($post)
    {
        include(plugin_dir_path(__FILE__) . '../view/submitbox-custom-fields.php');
    }

    public function getTemas()
    {
        return $this->radioAgenciaService->get_temas();
    }

    public function getTags()
    {
        return $this->radioAgenciaService->get_tags();
    }

    private function init_form()
    {
        $this->configForm->config_edit_form_top(array($this, 'form_top_custom_field'));
        $this->configForm->config_edit_form_after_title(array($this, 'form_after_title_custom_field'));
        $this->configForm->config_edit_form_after_editor(array($this, 'bottom_custom_fields'));
        $this->configForm->config_post_submitbox_misc_actions(array($this, 'submitbox_custom_fields'));
        $this->configForm->config_save_post(array($this, 'save_radio_agencia'), 10, 3);
        $this->configForm->config_pre_post_update(array($this, 'pre_post_update'), 10, 2);
    }

    private function add_scripts()
    {
        $this->configPlugin->add_ajax_action(ActionsAjax::VALIDATOR_RADIO_AGENCIA, array($this, 'validador'));
        //$this->configPlugin->add_ajax_action(ActionsAjax::TEMA_DO_DIA, array($this, 'pesquisar_tema_do_dia'));
        $this->configPlugin->add_ajax_action(ActionsAjax::TAGS, array($this, 'pesquisar_tags'));
        $this->configPlugin->add_ajax_action(ActionsAjax::RELACIONADAS, array($this, 'obter_relacionadas'));
    }

    public function obter_relacionadas () {
        $posts = $this->radioAgenciaService->get_relacionadas($_POST['post_id'], CamposDB::CD_RADIO_AGENCIA_RELACIONADA);
        echo json_encode($posts);
        die;
    }

    public function pesquisar_tema_do_dia()
    {
        $terms = $this->radioAgenciaService->pesquisar_temas($_GET['q']);
        echo json_encode($terms);
        die;

    }

    public function pesquisar_tags()
    {
        $terms = $this->radioAgenciaService->pesquisar_tags($_GET['q']);
        echo json_encode($terms);
        die;

    }

    public function pesquisar_noticias_relacionadas()
    {
        $posts = $this->radioAgenciaService->get_posts($_GET['q']);
        echo json_encode($posts);
        die;
    }

    public function validador()
    {
        $fields = RadioAgencia::isRequired($_POST, $_POST);
        if ($fields != '') {
            $this->messageUtil->errorFieldsRequired(true, $fields);
        }
    }
}
?>