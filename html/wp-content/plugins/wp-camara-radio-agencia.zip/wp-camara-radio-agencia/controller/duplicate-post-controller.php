<?php namespace radio\agencia\controller;

require_once(plugin_dir_path(__FILE__) . '../config/config-duplicate.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');

use radio\agencia\config\ConfigDuplicatePost as ConfigDuplicatePost;
use radio\agencia\domain\ActionsAjax as ActionsAjax;
use radio\agencia\mapeamento\CamposDB as CamposDB;

class DuplicatePostController
{

    private $radioAgenciaService;
    private $radioAgencia;
    private $configPlugin;
    private $config;
    
    public function __construct($configPlugin, $radioAgenciaService)
    {   
        $this->configPlugin = $configPlugin;
        if ($this->configPlugin->config()) {
            $this->config = new ConfigDuplicatePost($configPlugin::POST_TYPE_NAME);
            $this->radioAgenciaService = $radioAgenciaService;
            $this->add_scripts();
        }
    }

    private function add_scripts() {
        $this->configPlugin->add_ajax_action(ActionsAjax::DUPLICAR_POST, array($this, 'duplicar_post'));
    }

    /** Função utilizada para duplicar post */
    public function duplicar_post ($args=array(), $do_action=true) {

        $ajaxSecurity = $this->config::JS_NONCE_SECURITY_NAME;
        check_ajax_referer( $ajaxSecurity, 'security' );

        $original_id  = $_POST['original_id'];
        $global_settings = $this->config->get_post_duplicate_settings();

        if (!isset($original_id)) {
            die();
        }

        $duplicate_id = $this->radioAgenciaService->duplicar_post($original_id, $global_settings);
        echo $duplicate_id;
        die;
    }
}
?>