<?php namespace radio\agencia\util;

class MessageUtil
{

    private const MENSAGEM = "mensagem-radio-agencia";
    private const CAMPO_OBRIGATORIO = "Campos obrigatórios:  ";

    public function __construct($service)
    {
        $this->service = $service;
        add_action('admin_notices', array($this, 'register_message'));
    }
    
    public function errorFields($ajax, $fields) {
        $this->service->update_option(self::MENSAGEM, $this->service->json_encode(array('error', $fields)));
        if(!$ajax) {
            header('Location: ' . get_edit_post_link($post_id, 'redirect'));
            exit;
        }
        $this->register_message();
    }

    public function errorFieldsRequired($ajax, $fields)
    {
        $this->service->update_option(self::MENSAGEM, $this->service->json_encode(array('error', self::CAMPO_OBRIGATORIO . $fields)));
        if(!$ajax) {
            header('Location: ' . get_edit_post_link($post_id, 'redirect'));
            exit;
        }
        $this->register_message();
    }

    /**
     * Metodo para registrar a mensagem de erro, info, warning...
     * Tem que ser public porque e acessado por um hook
     */
    public function register_message()
    {
        $notifications = $this->service->get_option(self::MENSAGEM);

        if (!empty($notifications)) {
            $notifications = $this->service->json_decode($notifications);
            switch ($notifications[0]) {
                case 'error':
                case 'updated':
                case 'update-nag':
                    $class = $notifications[0];
                    break;
                default:
                    $class = 'error';
                    break;
            }

            echo '<div id="message" class="' . $class . ' notice notice-error is-dismissible ">';
            if($notifications[1]) {
                echo '<p>' . $notifications[1] . '</p>';
            }
            echo '</div>';

            $this->service->update_option(self::MENSAGEM, false);
        }
    }
}
?>