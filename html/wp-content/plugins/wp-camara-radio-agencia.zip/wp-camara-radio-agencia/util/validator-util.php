<?php namespace radio\agencia\util;
/**
 * TODO - Criar aqui as validacoes dos campos do dominio
 */
class ValidationUtil
{

}