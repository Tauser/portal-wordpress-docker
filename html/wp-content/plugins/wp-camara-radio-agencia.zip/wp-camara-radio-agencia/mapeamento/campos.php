<?php namespace radio\agencia\mapeamento;

abstract class CamposDB
{
    const CD_RADIO_AGENCIA_TIPO = "cd_tipo";
    const CD_RADIO_AGENCIA_VISIVEL_HOME = "cd_visivelHome";
    const CD_RADIO_AGENCIA_VISIVEL_BOLETIM = "cd_radiogencia_visivelBoletim";
    const CD_RADIO_AGENCIA_RODAPE = "cd_rodape";
    const CD_RADIO_AGENCIA_PORTAL_CONGRESSO = "cd_portalDoCongresso";
    const CD_RADIO_AGENCIA_TEMA_PRINCIPAL = "cd_temaPrincipal";
    const CD_RADIO_AGENCIA_TEMAS = "cd_temas";
    const CD_RADIO_AGENCIA_RELACIONADA = "cd_relacionadas";
    const CD_RADIO_AGENCIA_TEMA_DO_DIA = "cd_temaDoDia";
    const CD_RADIO_AGENCIA_AREA = "cd_area";
    const CD_RADIO_AGENCIA_TAGS = "cd_tags";
    const CD_RADIO_AGENCIA_TIPO_MIDIA = "cd_tipoMidia";
    const CD_RADIO_AGENCIA_RETRANCA = "cd_retranca";
    
}

?>