<?php namespace radio\agencia\service;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
require_once(plugin_dir_path(__FILE__) . '../domain/tema.php');
require_once(plugin_dir_path(__FILE__) . '../domain/tags.php');
require_once(plugin_dir_path(__FILE__) . '../domain/relacionada.php');
require_once(plugin_dir_path(__FILE__) . '../domain/radio-agencia.php');

use radio\agencia\mapeamento\CamposDB as CamposDB;
use radio\agencia\domain\Tema as Tema;
use radio\agencia\domain\Tags as Tags;
use radio\agencia\domain\Relacionada as Relacionada;
use radio\agencia\domain\RadioAgencia as RadioAgencia;

class RadioAgenciaService
{

    public function duplicar_post($original_id, $global_settings) {
        $duplicate = get_post( $original_id, 'ARRAY_A' );
        $originalPost = get_post( $original_id);      
        $settings = wp_parse_args( $args, $global_settings );

        $appended = ( $settings['title'] != '' ) ? ' '.$settings['title'] : '';
        $duplicate['post_title'] = $duplicate['post_title'].' - '.$appended;
        $duplicate['post_name'] = sanitize_title($duplicate['post_name'].'-'.$settings['slug']);
        $duplicate['post_status'] = 'draft';      
        $timestamp = ( $settings['timestamp'] == 'duplicate' ) ? strtotime($duplicate['post_date']) : current_time('timestamp',0);
	    $timestamp_gmt = ( $settings['timestamp'] == 'duplicate' ) ? strtotime($duplicate['post_date_gmt']) : current_time('timestamp',1);
	
        if( $settings['time_offset'] ) {
            $offset = intval($settings['time_offset_seconds']+$settings['time_offset_minutes']*60+$settings['time_offset_hours']*3600+$settings['time_offset_days']*86400);
            if( $settings['time_offset_direction'] == 'newer' ) {
                $timestamp = intval($timestamp+$offset);
                $timestamp_gmt = intval($timestamp_gmt+$offset);
            } else {
                $timestamp = intval($timestamp-$offset);
                $timestamp_gmt = intval($timestamp_gmt-$offset);
            }
        }

        $duplicate['post_date'] = date('Y-m-d H:i:s', $timestamp);
        $duplicate['post_date_gmt'] = date('Y-m-d H:i:s', $timestamp_gmt);
        $duplicate['post_modified'] = date('Y-m-d H:i:s', current_time('timestamp',0));
        $duplicate['post_modified_gmt'] = date('Y-m-d H:i:s', current_time('timestamp',1));

        // Remove os identificadores
        unset( $duplicate['ID'] );
        unset( $duplicate['guid'] );
        unset( $duplicate['comment_count'] );

        // Insere o novo post no banco de dados
	    $duplicate_id = wp_insert_post( $duplicate );

        $radioAgencia = $this->carregar_modelo($originalPost);  

        // Grava o novo post
        $this->save($duplicate_id, $radioAgencia);

        do_action( 'radio_agencia_post_duplicator_created', $original_id, $duplicate_id, $settings );

        return $duplicate_id;

    }

    private function carregar_modelo ($post) {
        return new RadioAgencia(
            $post->post_title,
            $post->post_content,
            $this->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_TIPO),
            $this->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_VISIVEL_HOME),
            $this->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_VISIVEL_BOLETIM),
            $this->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_RODAPE),
            $this->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_PORTAL_CONGRESSO),
            $this->get_tema_principal($post->ID, CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL, 'tema'),
            $this->get_temas_by_id_post($post->ID),
            $this->get_relacionadas($post->ID, CamposDB::CD_RADIO_AGENCIA_RELACIONADA),
            $this->get_tema_do_dia_by_id($post->ID, CamposDB::CD_RADIO_AGENCIA_TEMA_DO_DIA),
            $this->get_post_meta($post->ID, CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA),
            $this->get_tags_by_id_post($post->ID)
        );
    }


    public function save($post_ID, $radioAgencia) {
        $areaConteudo = $this->get_area_conteudo('radioagencia');
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_TIPO, $radioAgencia->getTipo());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_VISIVEL_HOME, $radioAgencia->getVisivelHomeBoolean());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_VISIVEL_BOLETIM, $radioAgencia->getVisivelBoletimBoolean());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_RODAPE, $radioAgencia->getRodape());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_PORTAL_CONGRESSO, $radioAgencia->getPortalCongressoBoolean());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_TIPO_MIDIA, $radioAgencia->getTipoMidia());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_RETRANCA, $radioAgencia->getRetranca());
        update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_AREA, $areaConteudo->ID);

        //$this->save_tema_do_dia($post_ID, $radioAgencia->getTemaDoDia());
        $this->save_tema_principal($post_ID, $radioAgencia->getTemaPrincipal());
        $this->save_temas($post_ID, $radioAgencia->getTemas());
        $this->save_tags($post_ID, $radioAgencia->getTags());
        $this->save_relacionadas($post_ID, $radioAgencia->getRelacionadas());
    }

    private function save_tema_do_dia ($post_ID, $temaDoDia) {
        if ($temaDoDia instanceof Tema)
            $temaDoDia = $temaDoDia->getId();
        wp_set_object_terms($post_ID, (int) $temaDoDia, 'tema_do_dia');
    }

    private function save_tema_principal ($post_ID, $temaPrincipal) {
        if ($temaPrincipal instanceof Tema)
            $temaPrincipal = $temaPrincipal->getId();
        
        if (isset($temaPrincipal))
            update_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_TEMA_PRINCIPAL, $temaPrincipal);
    }

    private function save_relacionadas ($post_ID, $idsRelacionadas) {
        delete_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_RELACIONADA);
        
        if (isset($idsRelacionadas['ids']))
            $idsRelacionadas = $idsRelacionadas['ids'];

        if($idsRelacionadas) {
            foreach($idsRelacionadas as $id) {
                if (!is_null($id))
                    add_post_meta($post_ID, CamposDB::CD_RADIO_AGENCIA_RELACIONADA,  (int) $id);
            }
        }
    }

    private function save_temas($post_ID, $idsTemas)
    {
        $temasAntigos = wp_get_object_terms($post_ID, 'tema');
        if ($temasAntigos) {
            foreach ($temasAntigos as $tema) {
                wp_remove_object_terms($post_ID, $tema->term_id, 'tema');
            }
        }
        $temasAntigos = wp_get_object_terms($post_ID, 'tema');
        if ($idsTemas) {
            foreach ($idsTemas as $idTema) {
                if ($idTema instanceof Tema)
                    $idTema = $idTema->getId();
                wp_set_object_terms($post_ID, (int) $idTema, 'tema', true);
            }
        }
    }

    private function save_tags($post_ID, $idsTags)
    {
        $tagsAntigas = wp_get_object_terms($post_ID, 'post_tag');
        if ($tagsAntigas) {
            foreach ($tagsAntigas as $tag) {
                wp_remove_object_terms($post_ID, $tag->term_id, 'post_tag');
            }
        }
        if ($idsTags) {
            foreach ($idsTags as $idTag) {
                if ($idTag instanceof Tags)
                    $idTag = $idTag->getId();
                wp_set_object_terms($post_ID, (int) $idTag, 'post_tag', true);
            }
        }
    }

    public function get_relacionadas($postId, $field)
    {
        $ids = get_post_meta($postId, $field, false);
        $posts = array('data' => array(), 'ids' => array());
        foreach ($ids as $id) {
            $post = get_post($id);
            $thumbnail_url = get_the_post_thumbnail_url($post->ID, 'thumbnail');
            $postType = get_post_type_object( $post->post_type );
            $resumo = wp_strip_all_tags(get_post_meta($post->ID, 'resumo', true));

            $obj = new Relacionada(
                $post->ID,  
                $post->post_title, 
                $post->post_date,
                $thumbnail_url,
                $resumo,
                $postType->label
            );
            array_push($posts['data'], $obj);
            array_push($posts['ids'], $obj->getId());
        }
        return $posts;
    }

    public function get_tema_principal($idPost, $field)
    {
        $idTema = $this->get_post_meta($idPost, $field);
        $term = get_term($idTema);
        return new Tema($term->term_id, $term->name);
    }

    public function get_temas_by_id_post($idPost)
    {
        $temas = array();
        $terms = wp_get_object_terms($idPost, 'tema');

        foreach ($terms as $term) {
            array_push($temas, new Tema($term->term_id, $term->name));
        }
        return $temas;

    }

    public function get_tags_by_id_post($idPost)
    {
        $tags = array();
        $terms = wp_get_object_terms($idPost, 'post_tag');

        foreach ($terms as $term) {
            array_push($tags, new Tags($term->term_id, $term->name));
        }
        return $tags;
    }

    public function get_tema_do_dia_by_id($id) {
        $term = wp_get_object_terms($id, 'tema_do_dia')[0];
        return new Tema($term->term_id, $term->name);
    }

    private function get_temas_do_dia_by_date($data) {
        $temas = array();
        $args = array(
            'taxonomy' => 'tema_do_dia',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
            'meta_key' => 'data_do_tema',
            'meta_value' => $data
        );

        $terms = get_terms($args);

        foreach ($terms as $term) {
            $temas[] = array($term->term_id, $term->name);
        }
        return $temas;
    }


    public function pesquisar_temas($term) {
        $temas = $this->get_temas_do_dia_by_date($term);
        if (sizeof($temas) <= 0) {
            $temas = array();
            $args = array(
                'taxonomy' => 'tema_do_dia',
                'hide_empty' => false,
                'orderby' => 'name',
                'order' => 'ASC',
                'search' => $term
            );

            $terms = get_terms($args);

            foreach ($terms as $term) {
                $temas[] = array($term->term_id, $term->name);
            }
        }
        return $temas;
    }

    public function pesquisar_tags($term) {
        $tags = array();
        $args = array(
                'taxonomy' => 'post_tag',
                'hide_empty' => false,
                'orderby' => 'name',
                'order' => 'ASC',
                'search' => $term
        );

        $terms = get_terms($args);

        foreach ($terms as $term) {
            array_push($tags, array($term->term_id, $term->name));
        }
        return $tags;
    }

    public function get_posts($term) {
        $return = array();
        $search_results = new WP_Query(array(
            's' => $term,
            'post_status' => 'publish',
            'ignore_sticky_posts' => 1,
            'posts_per_page' => 50
        ));
        if ($search_results->have_posts()) :
            while ($search_results->have_posts()) : $search_results->the_post();
                $id_area = get_post_meta($search_results->post->ID, 'area', true);
                $area = get_post($id_area);
                $title = $area->post_title . ' - ' . $search_results->post->post_title;
                $return[] = array($search_results->post->ID, $title);
            endwhile;
        endif;
        return $return;
    }

    public function get_temas()
    {
        $temas = array();
        $args = array(
            'taxonomy' => 'tema',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC'
        );
        $terms = get_terms($args);
        foreach ($terms as $term) {
            array_push($temas, new Tema($term->term_id, $term->name));
        }

        return $temas;
    }

    public function get_tags()
    {
        $tags = array();
        $args = array(
            'taxonomy' => 'post_tag',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC'
        );
        $terms = get_terms($args);
        foreach ($terms as $term) {
            array_push($tags, new Tags($term->term_id, $term->name));
        }

        return $tags;
    }

    public function get_area_conteudo($post_name)
    {
        return get_posts(array('post_type' => 'areaconteudo', 'name' => $post_name))[0];
    }

    public function get_post_type($id)
    {
        return get_post_type($id);
    }

    public function get_post_meta_array($postId, $field)
    {
        return get_post_meta($postId, $field, false);
    }

    public function get_post_meta($postId, $field)
    {
        return get_post_meta($postId, $field, true);
    }

    public function add_post_type_support($postType, $fields)
    {
        foreach ($fields as $value) {
            add_post_type_support($postType, $value);
        }
    }

    public function get_option($name)
    {
        return get_option($name);
    }

    public function json_decode($value)
    {
        return json_decode($value);
    }

    public function json_encode($value)
    {
        return json_encode($value);
    }

    public function update_option($name, $autoload)
    {
        return update_option($name, $autoload);
    }

    public function get_permalink()
    {
        return get_permalink(get_the_ID());
    }

}
?>