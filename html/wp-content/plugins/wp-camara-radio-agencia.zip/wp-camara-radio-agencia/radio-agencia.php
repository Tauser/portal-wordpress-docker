<?php
/**
 * Plugin Name: Câmara do Deputados | Rádio Agência
 * Plugin URI:  https://git.camara.gov.br/semid/wp-camara-radio-agencia
 * Description: Plugin para registar posts de rádio agência utilizando campos customizados
 * Version: 1.0.4
 * Author: Câmara dos Deputados
 * Author URI: https://camara.leg.br/
 * License: GPL2+
 * @package radio-agencia
 */

defined( 'ABSPATH' ) or die( 'Nope, not accessing this' );

require_once(plugin_dir_path(__FILE__) . './controller/radio-agencia-controller.php');
require_once(plugin_dir_path(__FILE__) . './controller/duplicate-post-controller.php');
require_once(plugin_dir_path(__FILE__) . './config/config-service.php');
require_once(plugin_dir_path(__FILE__) . './config/config-plugin.php');

use radio\agencia\config\ConfigService as ConfigService;
use radio\agencia\controller\RadioAgenciaController as RadioAgenciaController;
use radio\agencia\controller\DuplicatePostController as DuplicatePostController;
use radio\agencia\config\ConfigPlugin as ConfigPlugin;

class Camara_Radio_Agencia
{
    private static $instance;
    
    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new self();
        }
    }

    private function __construct()
    {
        $radioAgenciaService = new ConfigService();
        $baseUrl = WP_PLUGIN_URL."/".dirname(plugin_basename( __FILE__ ));
        new RadioAgenciaController(new ConfigPlugin($baseUrl), $radioAgenciaService->radioAgenciaService());
        new DuplicatePostController(new ConfigPlugin($baseUrl), $radioAgenciaService->radioAgenciaService());
    }
}
Camara_Radio_Agencia::getInstance();
 