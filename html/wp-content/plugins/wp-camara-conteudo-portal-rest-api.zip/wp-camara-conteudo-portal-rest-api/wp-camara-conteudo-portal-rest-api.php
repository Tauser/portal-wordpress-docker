<?php

/**
 * Plugin Name: Câmara do Deputados | API Rest para o Conteúdo do Portal
 * Plugin URI:  https://git.camara.gov.br/semid/wp-camara-conteudo-portal-rest-api
 * Description: Extende a API REST do WORDPRESS. Implementa o endpoint conteudo-portal.
 * Version: 2.1.1
 * Author: Câmara dos Deputados
 * Author URI: https://camara.leg.br/
 * License: GPL2+
 * @package camara-conteudo-portal-rest-api
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once(plugin_dir_path(__FILE__) . 'controller/ConteudoController.php');
require_once(plugin_dir_path(__FILE__) . 'config/ConfigService.php');
require_once(plugin_dir_path(__FILE__) . 'preview/config-preview.php');

use conteudo\portal\api\controller\ConteudoController as ConteudoController;
use conteudo\portal\api\config\ConfigService as ConfigService;
use conteudo\portal\api\preview\ConfigPreview as ConfigPreview;

define('CAMARA_CONTEUDO_PORTAL_REST_API_PLUGIN_VERSION', '2.0.3');
define('CAMARA_CONTEUDO_PORTAL_REST_API_PLUGIN_DIR', untrailingslashit(plugin_dir_path(__FILE__)));
$baseUrl = WP_PLUGIN_URL."/".dirname(plugin_basename( __FILE__ ));

function camara_conteudo_portal_rest_init()
{
    add_action('rest_api_init', function () {
        new ConteudoController(new ConfigService());
    });

}

// Global for backwards compatibility.
$GLOBALS['camara_conteudo_portal_rest'] = camara_conteudo_portal_rest_init();
$configPreview = new ConfigPreview();
$configPreview->config($baseUrl);