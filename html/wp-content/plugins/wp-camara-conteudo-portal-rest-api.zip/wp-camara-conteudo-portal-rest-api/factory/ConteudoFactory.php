<?php namespace conteudo\portal\api\factory;

require_once(plugin_dir_path(__FILE__) . '../model/Conteudo.php');
require_once(plugin_dir_path(__FILE__) . '../model/Agencia.php');
require_once(plugin_dir_path(__FILE__) . '../model/RadioAgencia.php');
require_once(plugin_dir_path(__FILE__) . '../model/Home.php');
require_once(plugin_dir_path(__FILE__) . '../model/PaginaDinamica.php');
// require_once(plugin_dir_path(__FILE__) . '../wp/WPServicePods.php');
require_once(plugin_dir_path(__FILE__) . '../model/EdicaoProgramaRadio.php');
require_once(plugin_dir_path(__FILE__) . '../model/ProgramaRadio.php');
require_once(plugin_dir_path(__FILE__) . '../model/Institucional.php');
require_once(plugin_dir_path(__FILE__) . '../model/EdicaoProgramaTv.php');
require_once(plugin_dir_path(__FILE__) . '../model/ProgramaTv.php');
require_once(plugin_dir_path(__FILE__) . '../model/MidiaDestaque.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/HomeCampos.php');

use conteudo\portal\api\mapeamento\HomeCampos as HomeCampos;
use conteudo\portal\api\mapeamento\Campos as Campos;

use conteudo\portal\api\model\Conteudo as Conteudo;
// use conteudo\portal\api\model\Agencia as Agencia;
use conteudo\portal\api\model\RadioAgencia as RadioAgencia;
use conteudo\portal\api\model\Home as Home;
// use conteudo\portal\api\model\PaginaDinamica as PaginaDinamica;
use conteudo\portal\api\model\EdicaoProgramaRadio as EdicaoProgramaRadio;
use conteudo\portal\api\model\ProgramaRadio as ProgramaRadio;
use conteudo\portal\api\model\Agencia as Agencia;
use conteudo\portal\api\model\Institucional as Institucional;
// use conteudo\portal\api\model\MidiaDestaque as MidiaDestaque;
use conteudo\portal\api\model\EdicaoProgramaTv as EdicaoProgramaTv;
use conteudo\portal\api\model\ProgramaTv as ProgramaTv;
// use conteudo\portal\api\service\WPServicePods as WPServicePods;

/**
 * Fabrica de conteudos do wordpress
 */
class ConteudoFactory
{
    private $service;
    private $fields;
    private $objeto_wp;
    private $tipo_objeto;
    private $menu;
    private $area_conteudo;
    private $breadCrumbs;
    private $midiaDestaque;
    private $tags_conteudo;

    public function __construct(
        $service,
        $fields,
        $objeto_wp,
        $tipo_objeto,
        $menu,
        $area_conteudo,
        $breadCrumbs,
        $midiaDestaque,
        $tags_conteudo
    ) {
        $this->service = $service;
        $this->fields = $fields;
        $this->objeto_wp = $objeto_wp;
        $this->tipo_objeto = $tipo_objeto;
        $this->menu = $menu;
        $this->area_conteudo = $area_conteudo;
        $this->breadCrumbs = $breadCrumbs;
        $this->midiaDestaque = $midiaDestaque;
        $this->tags_conteudo = $tags_conteudo;
    }

    public function criar(
    ) {
        switch ($this->tipo_objeto) {
            case "institucional":
                return $this->criarInstitucional();
            case "agencia":
                return $this->criarAgencia();
            case "programa_tv":
                return $this->criarProgramaTv();
            case "radioagencia":
                return $this->criarRadioAgencia();
            case "edicao_programa_tv":
                return $this->criarEdicaoProgramaTv();
            case "edicao_programa_radi":
                return $this->criarEdicaoProgramaRadio();
            case "programa_radio":
                return $this->criarProgramaRadio();
            case "area_conteudo":
                return $this->criarHome();
            case "criarConteudo2":
                return $this->criarConteudo2();
            default:
                return $this->criarConteudo();
        }
    }

    /**
     * Objeto Institucional (Assessoria de Imprensa)
     */
    private function criarInstitucional()
    {
        $tema_principal = $this->service->get_tema_principal($this->fields['id'], Campos::CD_TEMA_PRINCIPAL);
        $pagina_tematica = $this->service->get_pagina_tematica($tema_principal);
        return new Institucional(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                'pagina_tematica' => $pagina_tematica,
                Campos::CD_TEMA_PRINCIPAL => $tema_principal,
                Campos::CD_TEMAS => $this->service->get_taxonomy_by_id_post($this->fields['id'], 'tema_institucional'),
                Campos::CD_TEMA_DO_DIA => $this->service->get_taxonomy_by_id($this->fields['id'], 'tema_do_dia'),
                Campos::CD_RELACIONADAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_RELACIONADAS)
            ),
            $this->service->obter_proposicao_principal($this->fields['id']),
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    /**
     * Objeto Agencia
     */
    private function criarAgencia()
    {
        $tema_principal = $this->service->get_tema_principal($this->fields['id'], Campos::CD_TEMA_PRINCIPAL);
        $pagina_tematica = $this->service->get_pagina_tematica($tema_principal);
        $tema_do_dia = $this->service->get_taxonomy_by_id($this->fields['id'], 'tema_do_dia');
        $tempo_real = $this->service->get_noticias_tempo_real($this->fields['id'], $this->fields['date'], $tema_do_dia);

        return new Agencia(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                'tempo_real' => $tempo_real,
                'pagina_tematica' => $pagina_tematica,
                Campos::CD_TEMA_PRINCIPAL => $tema_principal,
                Campos::CD_TEMAS => $this->service->get_taxonomy_by_id_post($this->fields['id'], 'tema'),
                Campos::CD_TEMA_DO_DIA => $tema_do_dia,
                Campos::CD_RELACIONADAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_RELACIONADAS),
                Campos::CD_CONTINUACAO => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_CONTINUACAO)
            ),
            $this->service->obter_proposicao_principal($this->fields['id']),
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    /**
     * Objeto 2 para conteudo
     */
    private function criarConteudo2()
    {
        $tema_principal = $this->service->get_tema_principal($this->fields['id'], Campos::CD_TEMA_PRINCIPAL);
        $pagina_tematica = $this->service->get_pagina_tematica($tema_principal);
        $tema_do_dia = $this->service->get_taxonomy_by_id($this->fields['id'], 'tema_do_dia');
        $tempo_real = $this->service->get_noticias_tempo_real($this->fields['id'], $this->fields['date'], $tema_do_dia);

        $objeto_noticia_deputado = array(
            'id' => $this->fields['id'],
            'data' => strtotime($this->fields['date']),
            'titulo' => $this->fields['title'],
            'textoHTML' => wpautop($this->fields['post_content']),
            'texto' => $this->service->removeHtml($this->fields['post_content']),
            'resumo' => $this->fields['resumo'],
            'link' => $this->fields['permalink'],
            'urlImagem' => $this->midiaDestaque->getImagens(),
            'urlVideo' => $this->midiaDestaque->getVideos(),
            'urlAudio' => $this->midiaDestaque->getAudios(),
            'tema' => $tema_principal->titulo,
            'creditos' => null,
            'programa' => $this->service->get_programa_principal($this->fields['id'], Campos::CD_PROGRAMA_PRINCIPAL),
            'dataFormatada' => date('d/m/Y',strtotime($this->fields['date'])),
            'dataHoraFormatada' => date('d/m/Y H:i',strtotime($this->fields['date'])),
            'veiculo' => $this->fields['post_type']
        );

        return $objeto_noticia_deputado;
    }

    private function criarProgramaTv() {
        return new ProgramaTv(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                // 'destaque' => $this->service->buscar_destaque_program_tv($fields['id']),
                Campos::CD_CATEGORIA => $this->service->get_taxonomy_by_id($this->fields['id'], 'categoria_programa'),
                'ultimas' => $this->service->buscar_ultimas('edicao_programa_tv', Campos::CD_PROGRAMA_PRINCIPAL, $this->fields['id'])
            ),
            null,
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    private function criarRadioAgencia() {
        $tema_principal = $this->service->get_tema_principal($this->fields['id'], Campos::CD_TEMA_PRINCIPAL);
        $pagina_tematica = $this->service->get_pagina_tematica($tema_principal);

        return new RadioAgencia(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                'pagina_tematica' => $pagina_tematica,
                Campos::CD_TEMA_PRINCIPAL => $tema_principal,
                Campos::CD_TEMAS => $this->service->get_taxonomy_by_id_post($this->fields['id'], 'tema'),
                Campos::CD_TEMA_DO_DIA => $this->service->get_taxonomy_by_id($this->fields['id'], 'tema_do_dia'),
                Campos::CD_RELACIONADAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_RELACIONADAS)
            ),
            $this->service->obter_proposicao_principal($this->fields['id']),
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    /**
     * Objeto Edicao Programa de Tv
     */
    private function criarEdicaoProgramaTv()
    {
        $programa_principal = $this->service->get_post_meta_relacionada($this->fields['id'], Campos::CD_PROGRAMA_PRINCIPAL);
        $tema_principal = $this->service->get_tema_principal($this->fields['id'], Campos::CD_TEMA_PRINCIPAL);
        $pagina_tematica = $this->service->get_pagina_tematica($tema_principal);

        return new EdicaoProgramaTv(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                'pagina_tematica' => $pagina_tematica,
                Campos::CD_TEMA_PRINCIPAL => $tema_principal,
                Campos::CD_TEMAS => $this->service->get_taxonomy_by_id_post($this->fields['id'], 'tema'),
                Campos::CD_PROGRAMA_PRINCIPAL => $this->service->get_post_meta_relacionada($this->fields['id'], Campos::CD_PROGRAMA_PRINCIPAL),
                Campos::CD_PROGRAMAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_PROGRAMAS),
                Campos::CD_RELACIONADAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_RELACIONADAS),
                'ultimas' => $this->service->buscar_ultimas('edicao_programa_tv', Campos::CD_PROGRAMA_PRINCIPAL, $programa_principal['id'])
            ),
            $this->service->obter_proposicao_principal($this->fields['id']),
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    /**
     * Objeto Edicao Programa de Radio
     */
    private function criarEdicaoProgramaRadio()
    {   
        $programa_principal = $this->service->get_post_meta_relacionada($this->fields['id'], Campos::CD_PROGRAMA_PRINCIPAL);
        $tema_principal = $this->service->get_tema_principal($this->fields['id'], Campos::CD_TEMA_PRINCIPAL);
        $pagina_tematica = $this->service->get_pagina_tematica($tema_principal);
        return new EdicaoProgramaRadio(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                Campos::CD_TEMA_PRINCIPAL => $tema_principal,
                Campos::CD_TEMAS => $this->service->get_taxonomy_by_id_post($this->fields['id'], 'tema'),
                Campos::CD_PROGRAMA_PRINCIPAL => $this->service->get_post_meta_relacionada($this->fields['id'], Campos::CD_PROGRAMA_PRINCIPAL),
                Campos::CD_PROGRAMAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_PROGRAMAS),
                Campos::CD_RELACIONADAS => $this->service->get_post_meta_relacionadas($this->fields['id'], Campos::CD_RELACIONADAS),
                'ultimas' => $this->service->buscar_ultimas('edicao_programa_radi', Campos::CD_PROGRAMA_PRINCIPAL, $programa_principal['id'])
            ),
            $this->service->obter_proposicao_principal($this->fields['id']),
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    private function criarProgramaRadio() {
        return new ProgramaRadio(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo,
            array(
                // 'destaque' => $this->service->buscar_destaque_program_tv($fields['id']),
                Campos::CD_CATEGORIA => $this->service->get_taxonomy_by_id($this->fields['id'], 'categoria_programa'),
                'ultimas' => $this->service->buscar_ultimas('edicao_programa_radi', Campos::CD_PROGRAMA_PRINCIPAL, $this->fields['id'])
            ),
            null,
            $this->service->obter_comentarios($this->fields['id'])
        );
    }

    private function criarHome() {
        return new Home($this->fields, $this->tipo_objeto, $this->objeto_wp,
                    $this->service->obter_destaque_topo($this->fields[HomeCampos::CD_AREA_CONTEUDO_ID_HOME_PUBLICADA]),
                    $this->service->obter_estreia($this->fields[HomeCampos::CD_AREA_CONTEUDO_ID_HOME_PUBLICADA]));
    }

    private function criarConteudo() {
        return new Conteudo(
            $this->fields,
            $this->objeto_wp,
            $this->tipo_objeto,
            $this->menu,
            $this->area_conteudo,
            $this->breadCrumbs,
            $this->midiaDestaque,
            $this->tags_conteudo
        );
    }
}
?>