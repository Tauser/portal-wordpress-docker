<?php namespace conteudo\portal\api\controller;

require_once(plugin_dir_path(__FILE__) . '../service/WPService.php');

use conteudo\portal\api\service\WPService as WPService;

/**
 * Classe principal do plugin Camara Conteudo Portal Rest Api
 * @link              http://camara.leg.br
 * @package camara_conteudo_portal_rest_api
 */
class ConteudoController extends \WP_REST_Controller
{

    private $wpService;

    //
    // Construtor
    //
    public function __construct($configService)
    {
        $this->wpService = new WPService($configService->wpServiceBreadCrumbs(), 
                                         $configService->wpServiceMenu(),
                                         $configService->wpServiceMidia(),
                                         $configService->wpServiceDinamico(),
                                         $configService->wpServiceTematica(),
                                         $configService->wpServiceBoletim());
        $this->namespace = '/conteudo-portal';    // WP_REST_Controller
        $this->register_routes();
    }
    
    //
	// Registra as rotas
	// 
    public function register_routes()
    {
       $this->boletim();
       $this->noticia_deputado();
       $this->programas();
       $this->buscar_tema();
       $this->dinamicas_midia();
       $this->listar_homes_router();
       $this->busca_noticia_explicativa_proposicao();
       $this->buscar_home_princiapal();
       $this->buscar_home_router();
       $this->paginas_dinamicas_router();
       $this->paginas_estaticas_agencia_router();
       $this->paginas_estaticas_radio_router();
       $this->paginas_estaticas_tv_router();
       $this->paginas_estaticas_assessoria_imprensa_router();
       $this->imagens_router();
       $this->buscar_por_id_router();
    }

    /**
     * /wp-json/conteudo-portal/boletim/<query-param> - listar as meidias
     * 
     */
    private function boletim() {
        $this->register_router_get('/boletim', function ($request) {
            $params = array(
                "data" => $request['data'],
                "tipo" => $request['tipo']
            );
            return $this->wpService->busca_boletim($params);
        });
    }

    /**
     * /wp-json/conteudo-portal/noticias/deputados/<query-param> - Noticias referente há um deputado.
     * 
     */
    private function noticia_deputado() {
        $this->register_router_get('/noticias/deputados/(?P<id_deputado>\S+)', function ($request) {
            $params = array(
                "id_deputado" => $request['id_deputado'],
                "qtde" => $request['qtde'],
                "offset" => $request['offset']
            );
            return $this->wpService->busca_noticia_deputado($params);
        });
    }

    /**
     * /wp-json/conteudo-portal/programas_radio/<query-param> - listar de programas radio
     * /wp-json/conteudo-portal/programas_tv/<query-param> - listar de programas tv
     * 
     */
    private function programas() {
        $this->register_router_get('/programas-radio', function ($request) {
            $params = array(
                "pesquisa" => $request['pesquisa'],
                "data_inicio" => $request['data_inicio'],
                "data_final" => $request['data_final'],
                "qtde" => $request['qtde'],
                "offset" => $request['offset']
            );
            return $this->wpService->busca_programa_radio($params);
        });

        $this->register_router_get('/programas-tv', function ($request) {
            $params = array(
                "pesquisa" => $request['pesquisa'],
                "data_inicio" => $request['data_inicio'],
                "data_final" => $request['data_final'],
                "qtde" => $request['qtde'],
                "offset" => $request['offset']
            );
            return $this->wpService->busca_programa_tv($params);
        });
    }

     /**
     * /wp-json/conteudo-portal/midia-dinamica/<query-param> - listar as meidias
     * 
     */
    private function dinamicas_midia() {
        $this->register_router_get('/dinamica-midia', function ($request) {
            $params = array(
                "tipo" => $request['tipo'],
                "total" => $request['total'],
                "area-conteudo" => $request['area-conteudo']
            );
            return $this->wpService->busca_dinamica_midia($params);
        });
    }

    private function imagens_router() {
        $this->register_router_get('/imagens', function () {
            return $this->wpService->listar_paginas('area_conteudo');
        });
        $this->register_router_get('/imagens/(?P<nomeareaconteudo>\S+)', function ($request) {
            $nome_area_conteudo = $request['nomeareaconteudo'];
            return $this->wpService->buscar_imagens($nome_area_conteudo, 5);
        });
    }

    /**
     * /wp-json/conteudo-portal/home - listar as homes de primeiro nível
     */
    private function listar_homes_router() {
        $this->register_router_get('/home', function () {
            return $this->wpService->listar_homes();
        });
    }

    /**
     * /wp-json/conteudo-portal/home/noticias - buscar a home com identificador hierarquico igual a noticias
     */
    private function buscar_home_router() {
        $this->register_router_get('/home/(?P<nomehome>\S+)', function ($request) {
            return $this->wpService->buscar_home($request['nomehome']);
        });
    }    
    
    /**
     * /wp-json/conteudo-portal/home-principal - agregação de notícias, assessoria de impresa e notícias da agêmcia
     */
    private function buscar_home_princiapal() {
        $this->register_router_get('/home-principal', function () {
            return $this->wpService->home_principal();
        });
    }

    /**
     * /wp-json/conteudo-portal/tema?tema=seguranca&ultimas=3 - pesquisa notícias destaques por tema do portal
     */
    private function buscar_tema() {
        $this->register_router_get('/tema', function ($request) {
            $params = array(
                "tema" => $request['tema'],
                "tipo" => $request['tipo'],
                "ultimas" => $request['ultimas']
            );
            return $this->wpService->busca_home_por_tema($params);
        });
    }

    /**
     * /wp-json/conteudo-portal/noticia-explicativa-proposicao/<numero da proposição>
     */
    private function busca_noticia_explicativa_proposicao() {
        $this->register_router_get('/noticia-explicativa-proposicao/(?P<preposicao>\S+)', function ($request) {
            return $this->wpService->noticia_explicativa_proposicao($request['preposicao']);
        });
    }

    /**
     * /wp-json/conteudo-portal/1925 - buscar conteúdo do portal por ID
     */
    private function buscar_por_id_router() {
        $this->register_router_get('/(?P<id>\S+)', function ($request) {
            $request_id = $request['id'];
                $array_id = explode('-', $request_id);
                $id = $array_id[0];
                return $this->wpService->obter_objeto_por_id($id);
        });
    }

    /**
     * /wp-json/conteudo-portal/dinamica/ - listar as páginas dinâmicas
     * 
     */
    private function paginas_dinamicas_router() {
        $this->register_router_get('/dinamica', function ($request) {
            $params = array(
                "tipo" => $request['tipo'],
                "total" => $request['total'],
                "pagina" => $request['pagina'],
                "q" => $request['q'],
                "categorias" => $request['categorias'],
                "temas" => $request['temas'],
                "tema_principal" => $request['tema_principal'],
                "tags" => $request['tags'],
                "boletim" => $request['boletim'],
                "data" => $request['data'],
                "id_deputado" => $request['id_deputado'],
                "proposicao" => $request['proposicao'],
                "data_inicio" => $request['data_inicio'],
                "data_final" => $request['data_final'],
                "visivel_home" => $request['visivel_home']
            );
            return $this->wpService->buscar_posts($params);
        });
    }

    /**
     * /wp-json/conteudo-portal/conteudo/agencia/ - listar as paginas estaticas
     * /wp-json/conteudo-portal/conteudo/agencia/expediente 
     */
    private function paginas_estaticas_agencia_router () {
        $this->register_router_get('/conteudo/agencia', function () {
            return $this->wpService->listar_paginas('pagina_agencia');
        });
        $this->register_router_get('/conteudo/agencia/(?P<nomepagina>\S+)', function ($request) {
            $nomepagina = $request['nomepagina'];
            return $this->wpService->buscar_objeto_pagina('pagina_agencia', $nomepagina);
        });
    }

    /**
     * /wp-json/conteudo-portal/conteudo/radio - listar as paginas estaticas
     * /wp-json/conteudo-portal/conteudo/radio/programacao 
     */
    private function paginas_estaticas_radio_router () {
        $this->register_router_get('conteudo/radio', function () {
            return $this->wpService->listar_paginas('pagina_radio');
        });
        $this->register_router_get('conteudo/radio/(?P<nomepagina>\S+)', function ($request) {
            $nomepagina = $request['nomepagina'];
            return $this->wpService->buscar_objeto_pagina('pagina_radio', $nomepagina);
        });
    }

    /**
     * /wp-json/conteudo-portal/conteudo/tv - listar as paginas estaticas
     * /wp-json/conteudo-portal/conteudo/tv/expediente 
     */
    private function paginas_estaticas_tv_router () {
        $this->register_router_get('conteudo/tv', function () {
            return $this->wpService->listar_paginas('pagina_tv');
        });
        $this->register_router_get('conteudo/tv/(?P<nomepagina>\S+)', function ($request) {
            $nomepagina = $request['nomepagina'];
            return $this->wpService->buscar_objeto_pagina('pagina_tv', $nomepagina);
        });
    }

    
    /**
     * /wp-json/conteudo-portal/conteudo/assessoria-imprensa - listar as paginas estaticas
     * /wp-json/conteudo-portal/conteudo/assessoria-imprensa/expediente
     */
    private function paginas_estaticas_assessoria_imprensa_router () {
        $this->register_router_get('conteudo/assessoria-imprensa', function () {
            return $this->wpService->listar_paginas('pagina_institucional');
        });
        $this->register_router_get('conteudo/assessoria-imprensa/(?P<nomepagina>\S+)', function ($request) {
            $nomepagina = $request['nomepagina'];
            return $this->wpService->buscar_objeto_pagina('pagina_institucional', $nomepagina);
        });
    }

    private function register_router_get($url, $callback) {
        register_rest_route($this->namespace, $url, array(
            'methods' =>  \WP_REST_Server::READABLE,
            'callback' => $callback
        ));
    }

}
