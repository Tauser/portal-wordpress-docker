<?php namespace conteudo\portal\api\service;

class WPServiceMenu
{

    public function criar($area_conteudo)
    {
        return $this->gerar_menu_local($area_conteudo);
    }

    //
    // Obter area pai por id
    //
    private function get_top_level_parent_id($areaID, $level)
    {

        // obtem os pais da área do conteúdo
        $id_areas_pai = get_post_ancestors($areaID);

        if (count($id_areas_pai) == 0 || ($level > 0) && $level - count($id_areas_pai) <= 0)
            return $areaID;

        // Reverte a ordem: de pai para filho
        $id_areas_pai = array_reverse($id_areas_pai);

        return $id_areas_pai[$level];

    }

    private function gerar_menu_local($area_conteudo)
    {

        $top_level_parent_id = self::get_top_level_parent_id($area_conteudo['id'], 0);
        $menu_all_itens = get_pages(array('post_type' => 'areaconteudo', 'child_of' => $top_level_parent_id, 'sort_column' => 'menu_order', 'sort_order' => 'asc'));
        $menu_local = array();
        // Substituir $prefix = '/portal/' por '/' quando configurar proxy corretamente
        $prefix = '/';
        if (!$menu_all_itens) {
            return '';
        }
        if (count($menu_all_itens) == 0) {
            $page = get_page($top_level_parent_id);
            $menu_item = array(
                'ID' => $page->ID,
                'label' => $page->post_title,
                'slug' => $page->post_name,
                'link' => $prefix . $page->ID . '-' . $page->post_name,
            );
            array_push($menu_local, $menu_item);
        } else {
            foreach ($menu_all_itens as $menu) {
                $i = count($menu_local);
                if ($i > 0 && $menu->post_parent == $menu_local[$i - 1]['ID']) { // Adiciona submenu no menu-item anterior
                    $menu_item = array(
                        'ID' => $menu->ID,
                        'label' => $menu->post_title,
                        'slug' => $menu->post_name,
                        'link' => $prefix . $menu_local[$i - 1]['slug'] . '/' . $menu->ID . '-' . $menu->post_name,

                    );
                    array_push($menu_local[$i - 1]['submenu'], $menu_item);
                } else {
                    $menu_item = array(
                        'ID' => $menu->ID,
                        'label' => $menu->post_title,
                        'slug' => $menu->post_name,
                        'link' => $prefix . $menu->ID . '-' . $menu->post_name,
                        'submenu' => array()
                    );
                    array_push($menu_local, $menu_item);
                }
            }
        }
        return $menu_local;
    }
}
?>