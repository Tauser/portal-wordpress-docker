<?php namespace conteudo\portal\api\service;

require_once(plugin_dir_path(__FILE__) . '../model/Midia.php');
require_once(plugin_dir_path(__FILE__) . '../model/MidiaDestaque.php');
require_once(plugin_dir_path(__FILE__) . '../model/ReplaceUrlMidias.php');

use conteudo\portal\api\model\ReplaceUrlMidias as ReplaceUrlMidias;
use conteudo\portal\api\model\Midia as Midia;
use conteudo\portal\api\model\MidiaDestaque as MidiaDestaque;

class WPServiceMidia
{

    public function criarMidiaDestaque($id)
    {
        $imagens = $this->obter_imagens_post($id);
        $videos = $this->obter_videos_post($id);
        $audios = $this->obter_audios_post($id);
        $arquivos = $this->obter_arquivos_post($id);

        return new MidiaDestaque($imagens, $videos, $audios, $arquivos);
    }


    public function obter_imagens($idAreaConteudo, $total)
    {

        $args = array(
            'orderby' => 'date',
            'order' => 'DESC',
            'post_type' => 'attachment',
            'numberposts' => $total,
            'meta_key' => 'cd_areaConteudo',
            'meta_value' => $idAreaConteudo,
            'post_mime_type' => array('image/jpeg', 'image/jpg', 'image/png')
        );
        $attachments = get_posts($args);
        $imagens = array();
        if ($attachments) {
            foreach ($attachments as $attachment) {
                $metas = get_post_meta($attachment->ID);
                $dados = $this->recuperar_dados_basicos($attachment->ID, $metas, $attachment);
                $dados = $this->recuperar_thumbnails_imagens($attachment->ID, '', $dados);
                array_push($imagens, new Midia(
                    $attachment->ID,
                    $dados['nome'],
                    $dados['descricao'],
                    $dados['legenda'],
                    $dados['texto_alternativo'],
                    $dados['autor'],
                    $dados['local'],
                    $dados['tema'],
                    $dados['data'],
                    $dados['institucional'],
                    $dados['sizes'],
                    $dados['url'],
                    null,
                    null
                ));
            }
        }

        return $imagens;
    }

    public function obter_midia_dinamica($params)
    {
        // id area de conteúdo selecionada
        $args_simple = array(
            'orderby' => 'date',
            'order' => 'DESC',
            'post_type' => 'area_conteudo',
            'name' => $params['area-conteudo'],
            'post_status' => 'publish'               
        );
        
        // Veficando a existência do area de conteúdo
        if($params['area-conteudo']){
            $id_area_conteudo = get_posts($args_simple)[0]->ID;
            if($id_area_conteudo == null)
                $id_area_conteudo = 'null';    
        }
        
        //Tipo de midia selecionada
        $tipo_midia = $this->tipo_midia($params['tipo']);

        $args = array(
            'orderby' => 'date',
            'order' => 'DESC',
            'post_type' => 'attachment',
            'numberposts' => $params['total'],
            'meta_key' => 'cd_areaConteudo',
            'meta_value' => $id_area_conteudo,
            'post_mime_type' => $tipo_midia
        );
        $attachments = get_posts($args);
        
        $midia = array();
        $tipo_imagem = array('image/jpeg', 'image/jpg', 'image/png');
        if ($attachments) {
            
            foreach ($attachments as $attachment) {
                $metas = get_post_meta($attachment->ID);
                $dados = $this->recuperar_dados_basicos($attachment->ID, $metas, $attachment);
                if(in_array($attachment->post_mime_type, $tipo_imagem))
                    $dados = $this->recuperar_thumbnails_imagens($attachment->ID, '', $dados);
                
                $urlExterna = get_post_meta($attachment->ID, 'cd_midia_urlExterna' , true);
                if ($urlExterna) {
                    $dados['url'] = $urlExterna;
                }    
                array_push($midia, new Midia(
                    $attachment->ID,
                    $dados['nome'],
                    $dados['descricao'],
                    $dados['legenda'],
                    $dados['texto_alternativo'],
                    $dados['autor'],
                    $dados['local'],
                    $dados['tema'],
                    $dados['data'],
                    $dados['institucional'],
                    $dados['sizes'],
                    $dados['url'],
                    $metas['cd_midia_urlInfografico'][0],
                    $metas['cd_midia_urlThumbInfografico'][0]
                ));
            }
        }

        return $midia;
    }

    // Devolve string com valor do tipo de midia para pesquisa
    private function tipo_midia($valor){
        switch ($valor){
            case "infografico":
                return array('application/infografico');
            case "pdf":
                return array('application/pdf');
            case "imagem":
                return array('image/jpeg', 'image/jpg', 'image/png');
            case "video":
                return array('video/youtube', 'video/mp4');
            case "audio":
                return array('audio/mpeg', 'audio/mp3', 'audio/wma');
            default:
                return '';
        }
    }

    public function obter_arquivos_post($id)
    {
        return $this->obter_medias($id, 'cd_postArquivo', 'arquivo');
    }

    public function obter_audios_post($id)
    {

        return $this->obter_medias($id, 'cd_postAudio', 'audio');
    }

    public function obter_videos_post($id)
    {

        return $this->obter_medias($id, 'cd_postVideo', 'video');
    }

    public function obter_imagens_post($id)
    {

        return $this->obter_medias($id, 'cd_postImagem', 'imagem');
    }

    private function obter_medias($id, $meta_key, $tipo_media)
    {
        $ids = get_post_meta($id, $meta_key, false);
        $medias = array();
        if ($ids && sizeof($ids) > 0) {
            foreach ($ids as $id) {
                $media = $this->buscar_detail((int)$id, $tipo_media);
                $urlExterna = get_post_meta( $id, 'cd_midia_urlExterna' , true);
                if ($urlExterna) {
                    $media['url'] = $urlExterna;
                }
                array_push($medias, new Midia(
                    (int)$id,
                    $media['nome'],
                    $media['descricao'],
                    $media['legenda'],
                    $media['texto_alternativo'],
                    $media['autor'],
                    $media['local'],
                    $media['tema'],
                    $media['data'],
                    $media['institucional'],
                    $media['sizes'],
                    ReplaceUrlMidias::replace_conteudo($media['url']),
                    null,
                    null
                ));
            }
        }

        return $medias;
    }

    //
    // Obter detalhes da mídia
    //
    private function buscar_detail($id, $tipomidia)
    {
        global $uploadUrl;
        $dados = array();
        // Busca dados mídia
        $mediapost = get_post($id);

        if (!isset($mediapost)) {
            return null;
        }

        $dados = $this->recuperar_dados_basicos($id, $dados, $mediapost);

        if ($tipomidia == 'imagem') {
            $dados = $this->recuperar_thumbnails_imagens($id, $uploadUrl, $dados);
        }
        return $dados;
    }

    private function recuperar_dados_basicos($id, $dados, $mediapost)
    {
        $dados['nome'] = $mediapost->post_title;
        $dados['descricao'] = $mediapost->post_content;
        $dados['legenda'] = $mediapost->post_excerpt;
        $meta_dados = get_post_meta($id);
        $idYoutube = $meta_dados['cd_videoYoutubeId'][0];
        $dados['data'] = $meta_dados['cd_midia_dataTirada'][0];
        $dados['texto_alternativo'] = $meta_dados['_wp_attachment_image_alt'][0];
        $dados['institucional'] = $meta_dados['cd_midia_institucional'][0];
        $dados['url'] = $idYoutube != null ? 'https://www.youtube.com/watch?v=' . $idYoutube : $mediapost->guid;
        $dados['autor'] = $meta_dados['cd_midia_autor'][0];
        $dados['local'] = $meta_dados['cd_midia_local'][0];
        $term = $term = get_term((int)$meta_dados['cd_midia_album'][0], 'album');
        $dados['tema'] = $term->name;
        return $dados;
    }

    private function recuperar_thumbnails_imagens($id, $uploadUrl, $dat)
    {
        $postmeta = get_post_meta($id, '_wp_attached_file', true);
        $urldir = $uploadUrl . $postmeta;
        $urldir = substr($urldir, 0, strrpos($urldir, "/") + 1);
        $meta = wp_get_attachment_metadata($id);
        $image_sizes = array();
        foreach ($meta['sizes'] as $key => $value) {
            $result = array(
                'tipo' => $key,
                'url' => ReplaceUrlMidias::replace_conteudo($urldir . $value['file']),
                'width' => $value['width'],
                'height' => $value['height']
            );
            array_push($image_sizes, $result);
        }
        $dat['sizes'] = $image_sizes;
        return $dat;
    }
}
