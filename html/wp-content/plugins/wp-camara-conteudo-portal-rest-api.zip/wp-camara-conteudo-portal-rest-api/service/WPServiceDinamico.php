<?php namespace conteudo\portal\api\service;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;

/**
 * Classe para consultas dinâmicas utilizando parâmetros.
 */
class WPServiceDinamico
{

    public function obter_dados($params)
    {
        try {
            $tax_query = $this->tax_query($params);
            $meta_query = $this->meta_query($params);
            $data_query = $this->data_query($params);
            $args = array(
                'orderby' => 'date',
                'order' => 'DESC',
                'post_type' => $params['tipo'],
                'post_status' => 'publish',
                'posts_per_page' => $params['total'],
                'paged' => $params['pagina'],
                's' => $params['q'],
                'tax_query' => $tax_query,
                'date_query' => array(
                    $data_query['periodo'],
                    $data_query['periodo-padrao']
                ),
                'meta_query' => array(
                    $meta_query['tema_principal'],
                    $meta_query['proposicao'],
                    $meta_query['deputado'],
                    $meta_query['boletim'], 
                    $meta_query['visivel_home']
                )
            );
            
           $query = new \WP_Query($args);
            return $query->have_posts() ? $query->posts : null;
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    private function meta_query($params)
    {
        $tema_principal = $this->criar_query_meta_tema_principal($params);
        $deputado = $this->cria_query_meta_deputado($params);
        $proposicao = $this->cria_query_meta_proposicao($params);
        $boletim = $this->cria_query_meta_boletim($params);
        $visivel_home = $this->cria_query_meta_visivel_home($params);
        return array_merge($tema_principal,$deputado,$proposicao,$boletim,$visivel_home);
    }

    private function data_query($params){
        $periodo_padrao = null;
        if(!$params['data_inicio'] && !$params['data_final']) {
            $periodo_padrao = array(
                'periodo-padrao' => array(
                    'column' => 'post_date',
                    'after' => '- 30 days'
                ));
        } 
        $periodo = $this->criar_data_query_periodo($params);
        return array_merge($periodo, $periodo_padrao);
    }

    private function criar_data_query_periodo($params){
        // parametros de dados para filtro de data nos args do WP-Query
        $query_data = array();
        if($params['data_inicio'] && $params['data_final']){
            $query_data = array(
                'periodo' => array(
                    'relation' => 'AND',
                    array(
                        'after' => array(
                            'day' => date('d', strtotime($params['data_inicio'])),
                            'month' => date('m', strtotime($params['data_inicio'])),
                            'year' => date('Y', strtotime($params['data_inicio'])), 
                        ),
                        'inclusive' => true
                    ),
                    array(
                        'before' => array(
                            'day' => date('d', strtotime($params['data_final'])),
                            'month' => date('m', strtotime($params['data_final'])),
                            'year' => date('Y', strtotime($params['data_final'])), 
                        ),
                        'inclusive' => true
                    )
                )
            );
        }else if($params['data']) {   
            $query_data = array(
                'periodo' => array(
                    'day' => date('d', strtotime($params['data'])),
                    'month' => date('m', strtotime($params['data'])),
                    'year' => date('Y', strtotime($params['data'])), 
                )
            );
        }
        return $query_data;        
    }

    private function criar_query_meta_tema_principal($params) {
        $tema_principal = array();
        if ($params['tema_principal'] != null) {
            if ($params['tipo'] == 'programa_tv' || $params['tipo'] == 'programa_radio') {
                throw new \Exception('O parâmetro tema_principal somente é utilizado para os tipos: institucional, edicao_programa_radi, edicao_programa_tv, agencia e radioagencia');
            }
            $ids = array();
            $slugs = explode(',', $params['tema_principal']);
            foreach ($slugs as $slug) {
                $term = get_term_by('slug', $slug, 'tema');
                if(!$term) {
                    $term = get_term_by('slug', $slug, 'tema_institucional');
                }
                array_push($ids, (int)$term->term_id);
            }
            $tema_principal = array(
                'tema_principal' => 
                    array(
                        'key'    => Campos::CD_TEMA_PRINCIPAL,
                        'value'  => $ids,
                        'compare' => 'IN'
                    )
            );
        }
        return $tema_principal;
    }

    private function cria_query_meta_proposicao($params) {
        $proposicao = array();
        if ($params['proposicao'] != null) {
            $proposicao = array(
                'proposicao' => 
                    array(
                        'key'    => Campos::CD_PROPOSICOES,
                        'value' => $params['proposicao'],
                        'compare' => '=',
                        'type' => 'VARCHAR'
                    )
            );
        }
        return $proposicao;
    }

    private function cria_query_meta_deputado($params) {
        $deputado = array();
        if ($params['id_deputado'] != null) {
            $deputado = array(
                'deputado' => 
                    array(
                        'key'    => Campos::CD_DEPUTADOS,
                        'value' => $params['id_deputado'],
                        'compare' => '=',
                        'type' => 'VARCHAR'
                    )
            );
        }
        return $deputado;
    }

    private function cria_query_meta_boletim($params) {
        $boletim = array();
        if ($params['boletim'] != null) {
            $boletim = array(
                'boletim' => 
                    array(
                        'key' => Campos::CD_VISIVEL_BOLETIM,
                        'value' => '1',
                        'compare' => '=',
                        'type' => 'VARCHAR'
                    )
            );
        }
        return $boletim;
    }

    private function cria_query_meta_visivel_home($params) {
        $visivel_home = array();
        if ($params['visivel_home'] != null) {
            $visivel_home = array(
                'visivel_home' => 
                    array(
                        'key' => Campos::CD_VISIVEL_HOME,
                        'value' => '1',
                        'compare' => '=',
                        'type' => 'VARCHAR'
                    )
            );
        }
        return $visivel_home;
    }


    private function tax_query($params)
    {
        $categorias = $this->criar_query_taxonomia_categoria($params);
        $temas = $this->criar_query_taxonomia_temas($params, 'tema');
        $temas_institucional = $this->criar_query_taxonomia_temas($params, 'tema_institucional');
        $tags = $this->criar_query_taxonomia_tags($params);

        return array('relation' => 'OR', $categorias, $temas, $temas_institucional, $tags);
    }

    private function criar_query_taxonomia_categoria($params) {
        $categorias = null;
        if ($params['categorias'] != null) {
            if ($params['tipo'] != 'programa_tv' && $params['tipo'] != 'programa_radio') {
                throw new \Exception('O parâmetro categorias somente é utilizado para os tipos: programa_tv e programa_radio');
            }
            $categorias =
                array(
                    'taxonomy' => 'categoria_programa',
                    'field' => 'slug',
                    'terms'    => explode(',', $params['categorias'])
                );
        }

        return  $categorias;
    }

    private function criar_query_taxonomia_temas($params, $taxonomy) {
        $temas = null;
        if ($params['temas'] != null) {
            if ($params['tipo'] == 'programa_tv' || $params['tipo'] == 'programa_radio') {
                throw new \Exception('O parâmetro temas somente é utilizado para os tipos: institucional, edicao_programa_radi, edicao_programa_tv, agencia e radioagencia');
            }
            $temas = array(
                'taxonomy' => $taxonomy,
                'field' => 'slug',
                'terms'    => explode(',', $params['temas'])
            );
        }

        return $temas;
    }

    private function criar_query_taxonomia_tags($params) {
        $temas = null;
        if ($params['tags'] != null) {
            $temas = array(
                'taxonomy' => 'post_tag',
                'field' => 'slug',
                'terms'    => explode(',', $params['tags'])
            );
        }

        return $temas;
    }

}
