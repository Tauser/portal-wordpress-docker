<?php namespace conteudo\portal\api\service;

class WPServiceBreadCrumbs
{

    public function __constructor()
    {
    }

    public function criar($area)
    {
        $areas_pai = $this->obter_areas_pai($area);
        return $this->criarArray($areas_pai);
    }

    private function obter_areas_pai($area)
    {
        // obtem os pais da área do conteúdo
        $id_areas_pai = get_post_ancestors($area->id);
    
        // Reverte a ordem: de pai para filho
        $id_areas_pai = array_reverse($id_areas_pai);

        $areas_pai = array();
    
        // Obtem os objetos area a partir dos ids
        for ($i = 0; $i < count($id_areas_pai); $i++) {

            $area_page = get_page($id_areas_pai[$i]);

            $areaTemp = array(
                'nivel' => $i,
                'name' => $area_page->post_title,
                'slug' => $area_page->post_name,
                'id' => $id_areas_pai[$i]
            );

            array_push($areas_pai, $areaTemp);

        }
    
        // Adiciona o nível da área do conteúdo
        $areaTemp = array(
            'nivel' => $i++,
            'name' => $area['name'],
            'slug' => $area['slug'],
            'id' => $area['id'],
        );

        array_push($areas_pai, $areaTemp);

        return $areas_pai;
    }

    private function criarArray($areas_pai)
    {
        // Cria o array de breadcrumbs
        $breadcrumbs = array();

        for ($z = 0; $z < count($areas_pai); $z++) {

            $temp = $areas_pai[$z];

            $link = '';   //Retirar quando configurar o proxy corretamente

            for ($i = 0; $i < $areas_pai[$z]['nivel']; $i++) {

                $link .= '/' . $areas_pai[$i]['slug'];
            }

            $link .= '/' . $areas_pai[$z]['id'] . '-' . $areas_pai[$z]['slug'];

            $temp['link'] = $link;

            array_push($breadcrumbs, $temp);

        }
        return $breadcrumbs;
    }
}
?>