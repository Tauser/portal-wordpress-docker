<?php namespace conteudo\portal\api\service;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');
require_once(plugin_dir_path(__FILE__) . '../model/Taxonomy.php');

use conteudo\portal\api\mapeamento\Campos as Campos;
use conteudo\portal\api\model\Taxonomy as Taxonomy;

/**
 * Classe para consultas de tematica.
 */
class WPServiceTematica
{

    public function obter_dados($params)
    {
        try {
            // var ....
            $noticias_ultimas = array();
            $noticias_destaque = array();
            $id_noticias_detalhes = array();            
            $resultado = array();
            $possui_destaque = false;
            $prefixo = 'cd_dht_';
            $tematica_option = $prefixo . $params['tema'];
            $post_type = 'agencia';
            $tema_para_pesquisa = $this->get_tema_wordpress($params['tema']);// Fazer relacão com tematica para pegar temas do wp$id_noticias_detalhes = array();

            // busca noticias destaques
            $option = get_option($tematica_option);
            if($option){
                $possui_destaque = true;
                foreach ($option as $result) {
                    array_push($id_noticias_detalhes, $result['id']);
                }
                $args_ids_destaques = array(
                    'post_type' => 'agencia',
                    'post__in' => $id_noticias_detalhes
                );
    
                $query = new \WP_Query($args_ids_destaques);
                // Tratar dados noticias detalhes
                foreach ($query->posts as $result) {
                    $tema_atual = $this->get_tema_principal($result->ID, Campos::CD_TEMA_PRINCIPAL);
                    $datadopost = $result->post_date;
                    $temp = array(
                        'id' => $result->ID,
                        'titulo' => $result->post_title,
                        'link' => get_permalink($result->ID),
                        'data' => $datadopost,
                        'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                        'hora_formatada' => date('H:i', strtotime($datadopost)),
                        'resumo' => wp_strip_all_tags($result->post_excerpt),
                        'tema_principal' => $tema_atual,
                        'area' => get_post_meta($result->ID, 'area', true),
                        'conteudo' => apply_filters('the_content', $result->post_content),
                        'horario' => get_post_meta($result->ID, 'horario', true)
                    );
                    $midias_array = get_post_meta($result->ID, 'cd_postImagem', false);
                    if(sizeof($midias_array) > 0 ) {
                        // busca detalhes da mídia
                        $midia_id = $midias_array[0];
                        $imageDetail = bm_get_midia_detail(intval($midia_id), 'imagem');
                        if ($imageDetail->getId() && $imageDetail->getThumbnail()) {
                            $temp['imagemMateria'] = $imageDetail;
                        }
                    }
                    array_push($noticias_destaque, $temp);
                }
            }
            
            // Meta de temas principais do wp
            $meta_query = $this->criar_query_meta_tema_principal($tema_para_pesquisa['tema_wp']);

            // Últimas 
            $args = array(
                'orderby' => 'date',
                'order' => 'DESC',
                'post_status' => 'publish',
                'post_type' => $post_type,
                'posts_per_page' => $params['ultimas'],
                'meta_query' => $meta_query
            );
            
            $query = new \WP_Query($args);
            foreach ($query->posts as $result) {
                $tema_atual = $this->get_tema_principal($result->ID, Campos::CD_TEMA_PRINCIPAL);
                $datadopost = $result->post_date;
                $temp = array(
                    'id' => $result->ID,
                    'titulo' => $result->post_title,
                    'link' => get_permalink($result->ID),
                    'data' => $datadopost,
                    'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                    'hora_formatada' => date('H:i', strtotime($datadopost)),
                    'resumo' => wp_strip_all_tags($result->post_excerpt),
                    'tema_principal' => $tema_atual,
                    'area' => get_post_meta($result->ID, 'area', true),
                    'conteudo' => apply_filters('the_content', $result->post_content),
                    'horario' => get_post_meta($result->ID, 'horario', true)
                );

                $midias_array = get_post_meta($result->ID, 'cd_postImagem', false);
                if(sizeof($midias_array) > 0 ) {
                    // busca detalhes da mídia
                    $midia_id = $midias_array[0];
                    $imageDetail = bm_get_midia_detail(intval($midia_id), 'imagem');
                    if ($imageDetail->getId() && $imageDetail->getThumbnail()) {
                        $temp['imagemMateria'] = $imageDetail;
                    }
                }
                array_push($noticias_ultimas, $temp);
            }

            // Remove as noticias duplicadas
            foreach ($noticias_ultimas as $key => $noticia) { 
                if($this->existsInArray($noticia, $noticias_destaque) || 
                    in_array($noticia, $noticias_destaque)) {
                    
                    unset($noticias_ultimas[$key]);
                    //normalize index
                    $noticias_ultimas = array_values($noticias_ultimas);
                }
            }

            $noticias_ultimas = array(
                'ultimas' => $noticias_ultimas
            );

            $noticias_destaque = array(
                'destaques' => $noticias_destaque
            );

            if (count($noticias_ultimas['ultimas']) > 0)
                array_push($resultado, $noticias_ultimas);

            if (count($noticias_destaque['destaques']) > 0 || count($noticias_ultimas['ultimas']) > 0)
                array_push($resultado, $noticias_destaque);

            return $resultado;

        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    private function existsInArray($entry, $array) {
        foreach ($array as $compare) {
            if ($compare->id == $entry->id) {
                return true;
            }
        }
        return false;
    }

    private function criar_query_meta_tema_principal($temas) {
        $tema_principal = array();
        $ids = array();
        $slugs = explode(',', trim($temas));
        foreach ($slugs as $slug) {
            $term = get_term_by('slug', $slug, 'tema');
            if(!$term) {
                $term = get_term_by('slug', $slug, 'tema_institucional');
            }
            array_push($ids, (int)$term->term_id);
        }
        $tema_principal = array(
            'tema_principal' => 
                array(
                    'key'    => Campos::CD_TEMA_PRINCIPAL,
                    'value'  => $ids,
                    'compare' => 'IN'
                )
        );
        return $tema_principal;
    }

    private function get_tema_principal($idPost, $field)
    {
        $idTema = get_post_meta($idPost, $field);
        $term = get_term($idTema[0]);
        return new Taxonomy($term->term_id, $term->name);
    }

    //
    // Retorna o tema do wordpress a partir do tema do portal. Se alterar o de/para do node, tem que alterar esse aqui também
    //
    public function get_tema_wordpress($tema_portal) {

        $retorno = array();

        $relacao_temas_tema_portal = array(

            array('tema_portal' => 'agropecuaria', 
                    'tema_wp' => 'agropecuaria,consumidor'),
            
            array('tema_portal' => 'cidades-e-transportes', 
                    'tema_wp' => 'cidades,transportes'),

            array('tema_portal' => 'ciencia-tecnologia-e-comunicacoes', 
                    'tema_wp' => 'comunicacao,ciencia-e-tecnologia'),
            
            array('tema_portal' => 'consumidor', 
                    'tema_wp' => 'consumidor'),
            
            array('tema_portal' => 'direitos-humanos', 
                    'tema_wp' => 'direitos-humanos'),

            array('tema_portal' => 'economia', 
                    'tema_wp' => 'economia'),
            
            array('tema_portal' => 'educacao-cultura-e-esportes', 
                    'tema_wp' => 'esportes,educacao,cultura'),
            
            array('tema_portal' => 'meio-ambiente-e-energia', 
                    'tema_wp' => 'energia,meio-ambiente'),

            array('tema_portal' => 'politica-e-administracao-publica', 
                    'tema_wp' => 'politica,administracao-publica'),
            
            array('tema_portal' => 'relacoes-exteriores', 
                    'tema_wp' => 'relacoes-exteriores'),

            array('tema_portal' => 'saude', 
                    'tema_wp' => 'saude'),

            array('tema_portal' => 'seguranca', 
                    'tema_wp' => 'seguranca'),
            
            array('tema_portal' => 'trabalho', 
                'tema_wp' => 'trabalho,trabalho-previdencia-e-assistencia, trabalho-e-previdência'),

            array('tema_portal' => 'trabalho-previdencia-e-assistencia', 
                    'tema_wp' => 'assistencia-social,trabalho,trabalho-previdencia-e-assistencia, trabalho-e-previdência'),
        );
        
        $index = array_search( $tema_portal, array_column($relacao_temas_tema_portal, 'tema_portal'));

        if($index === false )
        return null;

        return $relacao_temas_tema_portal[$index];   
    }

}
