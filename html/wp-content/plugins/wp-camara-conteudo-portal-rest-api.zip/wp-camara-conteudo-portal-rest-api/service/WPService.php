<?php namespace conteudo\portal\api\service;

require_once(plugin_dir_path(__FILE__) . '../factory/ConteudoFactory.php');
require_once(plugin_dir_path(__FILE__) . '../model/AreaConteudo.php');
require_once(plugin_dir_path(__FILE__) . '../model/Pagina.php');
require_once(plugin_dir_path(__FILE__) . '../model/AreaConteudoDestaqueTopo.php');
require_once(plugin_dir_path(__FILE__) . '../model/AreaConteudoEstreia.php');
require_once(plugin_dir_path(__FILE__) . '../mapper/FieldsMapper.php');
require_once(plugin_dir_path(__FILE__) . '../model/Taxonomy.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/HomeCampos.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');
require_once(plugin_dir_path(__FILE__) . '../model/ReplaceUrlMidias.php');

use conteudo\portal\api\model\ReplaceUrlMidias as ReplaceUrlMidias;
use conteudo\portal\api\mapeamento\Campos as Campos;
use conteudo\portal\api\mapeamento\HomeCampos as HomeCampos;
use conteudo\portal\api\factory\ConteudoFactory as ConteudoFactory;
use conteudo\portal\api\model\AreaConteudo as AreaConteudo;
use conteudo\portal\api\model\Pagina as Pagina;
use conteudo\portal\api\model\AreaConteudoDestaqueTopo as AreaConteudoDestaqueTopo;
use conteudo\portal\api\model\AreaConteudoEstreia as AreaConteudoEstreia;
use conteudo\portal\api\model\mapper\FieldsMapper as FieldsMapper;
use conteudo\portal\api\model\Taxonomy as Taxonomy;


/**
 * Classe de servico que possui funcoes especificas para trazer informacoes do wordpress
 */
class WPService
{

    public function __construct($wpServiceBreadCrumbs, $wPServiceMenu, $wpServiceMidia, $wpServiceDinamico,$wpServiceTematica, $wpServiceBoletim)
    {
        $this->wpServiceBreadCrumbs = $wpServiceBreadCrumbs;
        $this->wpServiceMenu = $wPServiceMenu;
        $this->wpServiceMidia = $wpServiceMidia;
        $this->wpServiceDinamico = $wpServiceDinamico;
        $this->wpServiceTematica = $wpServiceTematica;
        $this->wpServiceBoletim = $wpServiceBoletim;
    }

    public function busca_home_por_tema($params)
    {
        try {
            $posts = $this->wpServiceTematica->obter_dados($params);
            if (count($posts) == 0) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }
            return $posts;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function busca_programa_radio($params)
    {
        $noticia_deputado = 'criarConteudo2';
        $args = array(
            's' => $params['pesquisa'],
            'post_type' => 'edicao_programa_radi',
            'post_status' => 'publish',
            'posts_per_page' => $params['qtde'],
            'order' => 'desc',
            'offset' => $params['offset'],
        );

        $dateQuery = array(
            'date_query' => array(
                'relation' => 'AND',
            )
        );

        if (!is_null($params['data_inicio'])) {
            array_push($dateQuery['date_query'], array(
                'after' => array(
                    'day' => date('d', strtotime($params['data_inicio'])),
                    'month' => date('m', strtotime($params['data_inicio'])),
                    'year' => date('Y', strtotime($params['data_inicio'])),
                ),
                'inclusive' => true
            ));
        }

        if (!is_null($params['data_final'])) {
            array_push($dateQuery['date_query'],   array(
                'before' => array(
                    'day' => date('d', strtotime($params['data_final'])),
                    'month' => date('m', strtotime($params['data_final'])),
                    'year' => date('Y', strtotime($params['data_final'])),
                ),
                'inclusive' => true
            ));
        }

        if (!is_null($params['data_inicio']) || !is_null($params['data_final']))
            $args['date_query'] = $dateQuery['date_query'];

        try {
            $result_query = new \WP_Query($args);
            if ($result_query->posts == null) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }
            $resultado = array();
            foreach ($result_query->posts as $post) {
                $tipo_objeto = $noticia_deputado;
                $objeto_wp = FieldsMapper::map($post, get_post_meta($post->ID));
                array_push($resultado, $this->retornar_conteudo($objeto_wp, $tipo_objeto, null));
            }
            return $resultado;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function busca_programa_tv($params)
    {
        $noticia_deputado = 'criarConteudo2';
        $args = array(
            's' => $params['pesquisa'],
            'post_type' => 'edicao_programa_tv',
            'post_status' => 'publish',
            'posts_per_page' => $params['qtde'],
            'order' => 'desc',
            'offset' => $params['offset']
        );

        $dateQuery = array(
            'date_query' => array(
                'relation' => 'AND',
            )
        );

        if (!is_null($params['data_inicio'])) {
            array_push($dateQuery['date_query'], array(
                'after' => array(
                    'day' => date('d', strtotime($params['data_inicio'])),
                    'month' => date('m', strtotime($params['data_inicio'])),
                    'year' => date('Y', strtotime($params['data_inicio'])),
                ),
                'inclusive' => true
            ));
        }

        if (!is_null($params['data_final'])) {
            array_push($dateQuery['date_query'],   array(
                'before' => array(
                    'day' => date('d', strtotime($params['data_final'])),
                    'month' => date('m', strtotime($params['data_final'])),
                    'year' => date('Y', strtotime($params['data_final'])),
                ),
                'inclusive' => true
            ));
        }

        if (!is_null($params['data_inicio']) || !is_null($params['data_final']))
            $args['date_query'] = $dateQuery['date_query'];

        try {
            $result_query = new \WP_Query($args);
            if ($result_query->posts == null) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }
            $resultado = array();
            foreach ($result_query->posts as $post) {
                $tipo_objeto = $noticia_deputado;
                $objeto_wp = FieldsMapper::map($post, get_post_meta($post->ID));
                array_push($resultado, $this->retornar_conteudo($objeto_wp, $tipo_objeto, null));
            }
            return $resultado;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function busca_noticia_deputado($params)
    {
        $noticia_deputado = 'criarConteudo2';
        $args = array(
            'post_type' => 'agencia',
            'post_status' => 'publish',
            'posts_per_page' => $params['qtde'],
            'order' => 'desc',
            'offset' => $params['offset'],
            'meta_query' => array(
                array(
                    'key'    => Campos::CD_DEPUTADOS,
                    'value' => $params['id_deputado'],
                    'compare' => '=',
                    'type' => 'VARCHAR'
                )
            )
        );
        try {
            $result_query = new \WP_Query($args);
            if ($result_query->posts == null) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }
            $resultado = array();
            foreach ($result_query->posts as $post) {
                $tipo_objeto = $noticia_deputado;
                $objeto_wp = FieldsMapper::map($post, get_post_meta($post->ID));
                array_push($resultado, $this->retornar_conteudo($objeto_wp, $tipo_objeto, null));
            }
            return $resultado;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function buscar_posts($params)
    {
        // $tes = wpconfiguracoes_obter_dados_pagina_tematica($this->get_tema_principal(924,Campos::CD_TEMA_PRINCIPAL));
        // var_dump(get_term_by('slug', 'comunicacao', 'tema')->term_id);
        try {
            $posts = $this->wpServiceDinamico->obter_dados($params);
            if ($posts == null) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }

            $resultado = array();
            foreach ($posts as $post) {
                $tipo_objeto = $post->post_type;
                $objeto_wp = FieldsMapper::map($post, get_post_meta($post->ID));
                array_push($resultado, $this->retornar_conteudo($objeto_wp, $tipo_objeto, null));
            }
            return $resultado;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function busca_dinamica_midia($params)
    {
        try {
            $resultado = $this->wpServiceMidia->obter_midia_dinamica($params);
            if ($resultado == null) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }
            return $resultado;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function get_post_meta_array($postId, $field)
    {
        return get_post_meta($postId, $field, false);
    }

    public function get_post_meta_relacionada($postId, $field)
    {
        $id = get_post_meta($postId, $field, true);
        $post = get_post($id);
        return $this->get_relacionadas($post);
    }

    public function get_post_meta_relacionadas($postId, $field)
    {
        $relacionadas = array();
        $ids = get_post_meta($postId, $field, false);
        foreach ($ids as $id) {
            $post = get_post($id);
            array_push($relacionadas, $this->get_relacionadas($post));
        }
        return $relacionadas;
    }

    private function get_relacionadas($post)
    {
        $imagems = $this->wpServiceMidia->obter_imagens_post($post->ID);
        $tema_principal = get_post_meta($post->ID, 'tema_principal', true);
        $horario = get_post_meta($post->ID, 'horario', true);

        $relacionadas = array(
            'id' => $post->ID,
            'data' => strtotime($post->post_date),
            'data_formatada' => date('d/m/Y', strtotime($post->post_date)),
            'titulo' => $post->post_title,
            'conteudo' => $post->post_content,
            'hora_formatada' => date('H:i', strtotime($post->post_date)),
            'tema_principal' => $tema_principal ? $post->post_title : "",
            'link' => get_permalink($post->ID),
            'horario' => $horario,
            'resumo' => $post->post_excerpt,
            'imagens' => $imagems
        );

        return $relacionadas;
    }

    public function removeHtml($conteudo){
        //removendo html do texto
        $conteudoSemHTML = strip_tags($conteudo);
        // Removendo quebra de linhas
        $conteudoSemHTML = str_replace("\n"," ",$conteudoSemHTML);
        return $conteudoSemHTML;
    }

    public function get_tema_principal($idPost, $field)
    {
        $idTema = get_post_meta($idPost, $field);
        $term = get_term($idTema[0]);
        return new Taxonomy($term->term_id, $term->name);
    }

    public function get_taxonomy_by_id_post($idPost, $tipo)
    {
        $taxonomys = array();
        $terms = wp_get_object_terms($idPost, $tipo);

        foreach ($terms as $term) {
            array_push($taxonomys, new Taxonomy($term->term_id, $term->name));
        }
        return $taxonomys;
    }

    public function get_taxonomy_by_id($id, $tipo)
    {
        $term = wp_get_object_terms($id, $tipo)[0];

        return new Taxonomy($term->term_id, $term->name);
    }

    public function buscar_imagens($nome_area_conteudo, $total)
    {
        $area_conteudo = $this->get_area_conteudo($nome_area_conteudo);
        return $this->wpServiceMidia->obter_imagens($area_conteudo->ID, $total);
    }

    private function get_area_conteudo($nome_area_conteudo)
    {
        return get_posts(array('post_type' => 'area_conteudo', 'name' => $nome_area_conteudo))[0];
    }

    public function obter_destaque_topo($id)
    {
        $metas = get_post_meta($id);

        return new AreaConteudoDestaqueTopo(
            $metas[HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_ID][0],
            $metas[HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_TITULO][0],
            $metas[HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_LINK][0]
        );
    }

    public function obter_estreia($id)
    {
        $metas = get_post_meta($id);

        return new AreaConteudoEstreia(
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_ID][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_TITULO][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_LINK][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_TEMA][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_RESUMO][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_POSTER][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_VIDEO][0],
            $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_AUDIO][0]
        );
    }

    public function buscar_conteudo_externo($objeto_conteudo_externo, $id_conteudo_externo)
    {

        //TODO Sem pods
        // $conteudo_externo = $this->wpServicePods::obter_objeto_wp_por_id_via_pods($objeto_conteudo_externo, $id_conteudo_externo);
        $conteudo_externo = null;
        if ($objeto_wp != null && sizeof($objeto_wp) > 0) {

            return array(
                'titulo' => $conteudo_externo['title'],
                'data' => strtotime($conteudo_externo['date']),
                'data_formatada' => date('d/m/Y', strtotime($conteudo_externo['date'])),
                'hora_formatada' => date('H:i', strtotime($conteudo_externo['date'])),
                'data_atualizacao' => strtotime($conteudo_externo['modified']),
                'data_atualizacao_formatada' => date('d/m/Y', strtotime($conteudo_externo['modified'])),
                'hora_atualizacao_formatada' => date('H:i', strtotime($conteudo_externo['modified'])),
                'conteudo' => wpautop($conteudo_externo['post_content']),
                'resumo' => $conteudo_externo['resumo']
            );
        } else {
            return null;
        }
    }

    public function obter_comentarios($id)
    {

        $comentarios = array();

        if ($id != null) {
            $wpcomentarios = get_comments(array('status' => 'approve', 'order' => 'ASC', 'post_id' => $id));

            if (is_array($wpcomentarios)) {

                foreach ($wpcomentarios as $wpcoment) {

                    $comentario = array(
                        'id' => $wpcoment->comment_ID,
                        'data' => $wpcoment->comment_date,
                        'autor' => $wpcoment->comment_author,
                        'email' => $wpcoment->comment_author_email,
                        'conteudo' => $wpcoment->comment_content,
                        'pai' => $wpcoment->comment_parent
                    );

                    array_push($comentarios, $comentario);
                }
            }
        }

        return $comentarios;
    }

    public function obter_proposicao_principal($id)
    {
        return get_post_meta($id, 'proposicao_principal');
    }

    // public function obter_dados_post_relacionado($relacionados)
    // {

    //     $posts_relacionados = array();
    //     if ($relacionados['ID']) {
    //         return $this->get_relacionadas($relacionados);
    //     }

    //     if (is_array($relacionados)) {
    //         foreach ($relacionados as $post) {
    //             $relacionada = $this->get_relacionadas($post);
    //             array_push($posts_relacionados, $relacionada);
    //         }

    //     }

    //     return $posts_relacionados;
    // }


    public function obter_dados_tags_relacionadas($id)
    {
        $_tags = wp_get_post_tags($id);
        $_tags_relacionadas = array();
        if (is_array($_tags)) {
            foreach ($_tags as $tag) {
                $relacionada = array(
                    'id' => $tag->term_id,
                    'nome' => $tag->name,
                    'slug' => $tag->slug
                );
                array_push($_tags_relacionadas, $relacionada);
            }
        }

        return $_tags_relacionadas;
    }

    public function obter_objeto_por_id($id)
    {

        if (!is_numeric($id)) {
            return new \WP_Error('bad_request', __('Requisição inválida.', 'conteudo-portal-rest-api'), array('status' => 400,));
        }
        $post = get_post($id);
        $tipo_objeto = $post->post_type;
        $objeto_wp = FieldsMapper::map($post, get_post_meta($id));
        if ($objeto_wp == null || sizeof($objeto_wp) == 0) {
            return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
        }
        $itemdata = $this->retornar_conteudo($objeto_wp, $tipo_objeto, null);

        return $itemdata;
    }

    public function obter_dados_area_conteudo($tipo_objeto)
    {

          // Função global do plugin wp-configuracoes
          $posts_area = wpconfiguracoes_tabela_posts_area();

          // Filtra o post_type
          $area = array_filter($posts_area, function ($item) use ($tipo_objeto) {
              return $item['tipo'] == $tipo_objeto ? true : false;
          });
  
          // Se encontrada area de conteudo
          if (sizeof($area) == 1) {
              //$area = array_values($area);
              $area = array_shift(array_slice($area, 0, 1)); 
              $args = array(
                  'post_type' => 'area_conteudo',
                  'meta_query' => array(
                      array(
                          'key' => 'cd_slugHierarquico',
                          'value' => $area['area_slug'],
                          'compare' => '=',
                      )
                  )
               );
               $query = new \WP_Query($args);
               if ($query->post_count > 0)
                  return array('id' => $query->post->ID, 'name' => $query->post->post_title, 'slug' => $area['area_slug']);
          }
          return array('id' => 0, 'name' => null, 'slug' =>null);
    }

    public function obter_objeto_wp($tipo_conteudo)
    {
        $pwptype = get_post_type_object($tipo_conteudo);
        $retorno = array();
        if (isset($pwptype)) {
            $retorno = array(
                'label' => $pwptype->label,
                'capability' => $pwptype->capability_type
            );
        }
        return $retorno;
    }

    public function listar_homes()
    {
        $args = array('post_type' => 'area_conteudo', 'post_parent' => 0, 'orderby' => 'title', 'order' => 'ASC',);
        $homes = get_posts($args);

        $result = array();
        foreach ($homes as $home) {
            if ('servicos-portal' != $home->post_name && 'servicos-do-portal' != $home->post_name) {
                $home_slug = get_post_meta($home->ID, 'cd_slugHierarquico', true);
                array_push($result, (array)new AreaConteudo($home->ID, $home->post_title, $home_slug));
            }
        }

        return $result;
    }

    public function buscar_home($nome)
    {
        $args = array(
            'post_type' => 'area_conteudo',
            'post_parent' => 0,
            'post_status' => 'publish',
            'meta_key' => 'cd_slugHierarquico',
            'meta_value' => $nome
        );
        $home = get_posts($args)[0];
        $tipo_objeto = $home->post_type;
        $objeto_wp = FieldsMapper::map($home, get_post_meta($home->ID));
        return $this->retornar_conteudo($objeto_wp, $tipo_objeto, null);
    }

    //
    //  listar as paginas
    //
    public function listar_paginas($post_type)
    {

        $args = array('post_type' => $post_type, 'orderby' => 'title', 'order' => 'ASC',);
        $query = new \WP_Query($args);
        $result = array();
        foreach ($query->posts as $post) {
            array_push($result, (array)new Pagina($post->ID, $post->post_title, $post->post_name));
        }
        return $result;
    }

    public function buscar_objeto_pagina($post_type, $nome_pagina)
    {
        $id = 0;

        $args = array('post_type' => $post_type, 'name' => $nome_pagina);
        $query = new \WP_Query($args);
        if ($query->have_posts() && $query->post_count == 1) {
            $id = $query->posts[0]->ID;
        } else {
            return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
        }
        $post = get_post($id);
        $tipo_objeto = $post->post_type;
        $objeto_wp = FieldsMapper::map($post, get_post_meta($id));

        return $this->retornar_conteudo($objeto_wp, $tipo_objeto, null);
    }


    public function retornar_posts($fields, $post_type, $query_result)
    {
        $posts = array();
        foreach ($query_result->posts as $result) {

            if ($post_type == 'attachment') {
                $url = $result->guid;
                $urldir = substr($url, 0, strrpos($url, "/") + 1);
                $datadopost = get_post_meta($result->ID, 'data', true);
                $meta = wp_get_attachment_metadata($result->ID);
                $image_sizes = array();

                foreach ($meta['sizes'] as $key => $value) {

                    $temp = array(
                        'tipo' => $key,
                        'url' => $urldir . $value['file'],
                        'width' => $value['width'],
                        'height' => $value['height']
                    );

                    array_push($image_sizes, $temp);
                }

                $post = array(
                    'id' => $result->ID,
                    'titulo' => $result->post_title,
                    'data' => strtotime($datadopost),
                    'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                    'hora_formatada' => date('H:i', strtotime($datadopost)),
                    'descricao' => $result->post_content,
                    'area' => get_post_meta($result->ID, 'area', true),
                    'url' => $url,
                    'legenda' => $result->post_excerpt,
                    'texto_alternativo' => get_post_meta($result->ID, '_wp_attachment_image_alt', true),
                    'credito' => get_post_meta($result->ID, 'credito', true),
                    'tema' => get_post_meta($result->ID, 'tema', true),
                    'sizes' => $image_sizes
                );
            } else {

                $datadopost = $result->post_date;
                $imagem_destaque = $this->wpServiceMidia->obter_imagens_post($result->ID);
                $video = $this->wpServiceMidia->obter_videos_post($result->ID);
                $audio = $this->wpServiceMidia->obter_audios_post($result->ID);
                $tema_principal = get_post_meta($result->ID, 'tema_principal', true);

                $post = array(
                    'id' => $result->ID,
                    'titulo' => $result->post_title,
                    'link' => get_permalink($result->ID),
                    'data' => $datadopost,
                    'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                    'hora_formatada' => date('H:i', strtotime($datadopost)),
                    'resumo' => wp_strip_all_tags(get_post_meta($result->ID, 'resumo', true)),
                    //'tema_principal' => $tema_principal['post_title'],
                    'area' => get_post_meta($result->ID, 'area', true),
                    'imagem_destaque' => $imagem_destaque,
                    'video' => $video,
                    'audio' => $audio
                );
            }

            array_push($posts, $post);
        }

        return array(
            'total_posts' => $query_result->found_posts,
            'posts' => $posts
        );
    }

    public function recuperar_dados_pagina_dinamica($fields, $area_conteudo, $params)
    {
        $page = 1;
        if ($params['page'] > 0) {
            $page = $params['page'];
        }
        $objeto_query = $params['objeto_query'] == null ? $fields['tipo_conteudo_pagina_dinamica'] : $params['objeto_query'];
        $valor_tipo_objeto = $params['valor_objeto_query'];
        $objeto_relacionado = $params['objeto_filtro'];
        $valor_objeto_relacionado = $params['id_objeto_filtro'];
        $taxonomia = $params['taxonomia_filtro'];
        $slug_taxonomia = $params['slug_taxonomia_filtro'];
        if (is_numeric($valor_objeto_relacionado)) {
            $relacionamento = get_post($valor_objeto_relacionado);
        }


        $perpage = $fields['quantidade_por_pagina'];
        $usar_area_pagina = $fields['usar_area_pagina'];

        if ($usar_area_pagina == '1') {
            $area_query = $area_conteudo->id;
        } else {
            $area_query = $fields['area_conteudo_pagina_dinamica'];
        }

        $offset = ($page - 1) * $perpage;

        $status = 'publish';

        if ($fields['tipo_conteudo_pagina_dinamica'] == 'attachment') {  // Attachment tem um status diferente
            $status = 'published';
        }

        $objeto_query_params = array(
            'post_type' => $objeto_query,
            'post_status' => $status,
            'posts_per_page' => $perpage,
            'offset' => $offset,
            'orderby' => $fields['ordenar_por'],
            'order' => $fields['ordem']
        );

        $objeto_query_params['meta_query'] = array();

        if ($usar_area_pagina == '1' || $area_selecionada) {
            array_push($objeto_query_params['meta_query'], array('key' => 'area', 'value' => $area_query));
        }

        if ($param_from_url && $objeto_relacionado && $valor_objeto_relacionado) {
            array_push($objeto_query_params['meta_query'], array('key' => $objeto_relacionado, 'value' => $valor_objeto_relacionado));
        }

        // Adiciona taxonomia selecionada na quary
        $objeto_query_params['tax_query'] = array();

        if ($taxonomia_selecionada && $slug_taxonomia_selecionada) {
            $tax_sel = array('taxonomy' => $taxonomia_selecionada, 'field' => 'slug', 'terms' => $slug_taxonomia_selecionada);
            array_push($objeto_query_params['tax_query'], $tax_sel);
        }
        // Adiciona taxonomia parametro na url na quary
        // executa a query
        $query_result = new \WP_Query($objeto_query_params);

        $dados_posts = $this->retornar_posts($fields, $objeto_query, $query_result);

        $fields['objeto_query'] = $objeto_query;
        $fields['total_posts'] = $dados_posts['total_posts'];
        $fields['posts'] = $dados_posts['posts'];

        return $fields;
    }

    public function get_pagina_tematica ($tema) {
        // Função global para busca em array com paginas tematicas no plugin wp-configuracoes
        return wpconfiguracoes_obter_dados_pagina_tematica($tema);
    }

    public function buscar_destaque_program_tv($id)
    {
        // Destaque
        $objeto_query_params = array(
            'post_type' => 'edicao_programa_tv',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'orderby' => 'date',
            'order' => 'desc'
        );

        $objeto_query_params['meta_query'] = array();

        array_push($objeto_query_params['meta_query'], array('key' => 'destaque_home_programa_tv', 'value' => 1));
        array_push($objeto_query_params['meta_query'], array('key' => 'programa_tv', 'value' => $id));

        // executa a query
        $query_result = new \WP_Query($objeto_query_params);

        $destaque = array();

        foreach ($query_result->posts as $result) {

            $datadopost = $result->post_date;

            $imagem_destaque = $this->wpServiceMidia->obter_imagens_post($result->ID);

            $video = $this->wpServiceMidia->obter_videos_post($result->ID);

            $tema_principal = get_post_meta($result->ID, 'tema_principal', true);

            $temp = array(
                'id' => $result->ID,
                'titulo' => $result->post_title,
                'link' => get_permalink($result->ID),
                'data' => $datadopost,
                'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                'hora_formatada' => date('H:i', strtotime($datadopost)),
                'resumo' => wp_strip_all_tags(get_post_meta($result->ID, 'resumo', true)),
                'tema_principal' => $tema_principal['post_title'],
                'area' => get_post_meta($result->ID, 'area', true),
                'destaque' => get_post_meta($result->ID, 'destaque_home_programa_tv', true),
                'imagem_destaque' => $imagem_destaque,
                'video' => $video
            );

            array_push($destaque, $temp);
        }
        return $destaque;
    }

    public function buscar_ultimas($post_type, $meta_programa_principal, $id_principal)
    {
        // Ultimas
        $objeto_query_params = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => 6,
            'orderby' => 'date',
            'order' => 'desc',
            'data_query' => array(
                array(
                    'column' => 'post_date',
                    'after' => '- 30 days'
                )
            ),
            'meta_query' => array(
                array(
                    'key' => $meta_programa_principal,
                    'value' => $id_principal,
                    'compare' => '='
                ),
                array(
                    'key' => Campos::CD_VISIVEL_HOME,
                    'value' => '1',
                    'compare' => '=',
                )

            )
        );

        $query_result = new \WP_Query($objeto_query_params);

        $ultimas = array();

        foreach ($query_result->posts as $result) {

            $datadopost = $result->post_date;

            $imagens = $this->wpServiceMidia->obter_imagens_post($result->ID);
            $tema_principal = get_post_meta($result->ID, 'tema_principal', true);
            $videos = $this->wpServiceMidia->obter_videos_post($result->ID);
            $audios = $this->wpServiceMidia->obter_audios_post($result->ID);

            $temp = array(
                'id' => $result->ID,
                'titulo' => $result->post_title,
                'link' => get_permalink($result->ID),
                'data' => $datadopost,
                'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                'hora_formatada' => date('H:i', strtotime($datadopost)),
                'resumo' => wp_strip_all_tags(get_post_meta($result->ID, 'resumo', true)),
                'tema_principal' => $tema_principal ? $tema_principal['post_title'] : '',
                'area' => get_post_meta($result->ID, 'area', true),
                'conteudo' => apply_filters('the_content', $result->post_content),
                'imagens' => $imagens,
                'videos' => $videos,
                'audios' => $audios,
                'horario' => get_post_meta($result->ID, 'horario', true)
            );

            array_push($ultimas, $temp);
        }

        return $ultimas;
    }

    private function busca_wp_query($args_param, $post_type, $quantidade_por_pagina, $filtroDataUltimas){
        $args = $args_param;
        $data_query = $filtroDataUltimas ? array(array('column' => 'post_date', 'after' => '- 10 days')) : null;
        if($args == null){
            $args = array(
                'post_type' => $post_type,
                'post_status' => 'publish',
                'posts_per_page' => $quantidade_por_pagina,
                'orderby' => 'date',
                'order' => 'desc',
                'meta_query' => array(
                    array(
                        'key' => Campos::CD_VISIVEL_HOME,
                        'value' => '1',
                        'compare' => '=',
                    )
                ),
                'date_query' => $data_query,
                'order' => 'desc'
            ); 
        }
        $query_result = new \WP_Query($args);
        return $query_result;
    }

    public function home_principal()
    {
        $noticias = 'agencia';
        // args
        $args_area_conteudo_noticia = array(
            'post_type' => 'area_conteudo',
            'meta_query' => array(
                array(
                    'key' => HomeCampos::CD_AREA_CONTEUDO_TIPO_CONTEUDO,
                    'value' => 'agencia',
                    'compare' => '=',
                )
            )
         );
         $args_area_conteudo_intitucional= array(
            'post_type' => 'area_conteudo',
            'meta_query' => array(
                array(
                    'key' => HomeCampos::CD_AREA_CONTEUDO_TIPO_CONTEUDO,
                    'value' => 'institucional',
                    'compare' => '=',
                )
            )
         );
        
        // Results wp-query
        $query_result_noticias = $this->busca_wp_query($args_area_conteudo_noticia, null, null, false);
        $query_result_institucional = $this->busca_wp_query($args_area_conteudo_intitucional, null, null, false);
        $query_result_noticia_ultimas = $this->busca_wp_query(null, $noticias, 4, true);

        // Get value post_meta - home de noticia
        $home_noticia = get_post_meta($query_result_noticias->posts[0]->ID, HomeCampos::CD_AREA_CONTEUDO_JSON_HOME_PUBLICADA, true);
        $home_institucional = get_post_meta($query_result_institucional->posts[0]->ID, HomeCampos::CD_AREA_CONTEUDO_JSON_HOME_PUBLICADA, true);

        $noticias = array();
        foreach(json_decode($home_noticia, TRUE) as $valor){
            if($valor['imagem']){
                $valor['imagem'] = ReplaceUrlMidias::replace_conteudo($valor['imagem']);
                $valor['thumbnail'] = ReplaceUrlMidias::replace_conteudo($valor['thumbnail']);
                array_push($noticias, $valor);
            }
        }

        // Retirando posts que não possuim imagem
        $institucinal_com_imagens = array();
        foreach(json_decode($home_institucional, TRUE) as $valor){
            if($valor['imagem']){
                $valor['imagem'] = ReplaceUrlMidias::replace_conteudo($valor['imagem']);
                $valor['thumbnail'] = ReplaceUrlMidias::replace_conteudo($valor['thumbnail']);
                array_push($institucinal_com_imagens, $valor);
            }
        }

        //Tratar dados de ultimas
        $ultimas_tratados = array();
        foreach($query_result_noticia_ultimas->posts as $valor){
            $data_hora = date('d', strtotime($valor->post_date)).'/'.date('m', strtotime($valor->post_date)).' - '.date("H", strtotime($valor->post_date)).'h'.date("i", strtotime($valor->post_date));
            $temp = array(
                'ID' => $valor->ID,
                'post_author' => $valor->post_author,
                'post_content' => ReplaceUrlMidias::replace_conteudo($valor->post_content),
                'post_title' => $valor->post_title,
                'post_excerpt' => $valor->post_excerpt,
                'post_status' => $valor->post_status,
                'comment_status' => $valor->comment_status,
                'guid' => $valor->guid,
                'post_name' => $valor->post_name,
                'dataHora' => $data_hora
            );
            array_push($ultimas_tratados, $temp);
        }
        
        $agregacao_resultado = array(
            'noticias' => array_slice($noticias, 0, 5),
            'assessoria_impressa' => array_slice($institucinal_com_imagens, 0, 4),
            'noticia_ultimas' => $ultimas_tratados
        );
        return $agregacao_resultado;
    }

    public function busca_boletim($params)
    {  
        try {
            if($params['tipo'] == 'radio'){
                $posts =  $this->wpServiceBoletim->busca_boletim_radio($params);
            }else{
                $posts = $this->wpServiceBoletim->busca_boletim($params);
            }
            
            if ($posts == null) {
                return new \WP_Error('not_found', __('Objeto Wordpress não encontrado.', 'conteudo-portal-rest-api'), array('status' => 404,));
            }
            return $posts;
        } catch (\Exception $e) {
            return new \WP_Error('not_found', __($e->getMessage(), 'conteudo-portal-rest-api'), array('status' => 404,));
        }
    }

    public function noticia_explicativa_proposicao($param)
    {
        // Pesquisa de notica por proposição
        $objeto_query_params = array(
            'post_type' => 'agencia',
            'post_status' => 'publish',
            'posts_per_page' => 6,
            'orderby' => 'date',
            'order' => 'desc',
            'meta_query' => array(
                array(
                    'key' => 'cd_proposicoes',
                    'value' => $param,
                    'compare' => '=',
                    'type' => 'VARCHAR'
                )
            )
        );
        $query_result = new \WP_Query($objeto_query_params);

        $datadopost = $query_result->posts[0]->post_date;

        $imagens = $this->wpServiceMidia->obter_imagens_post($query_result->posts[0]->ID);
        // Get tema principal - terms e postmeta
        //$tema_principal = get_term(get_post_meta($query_result->posts[0]->ID, Campos::CD_TEMA_PRINCIPAL, true));
        $tema_principal = $this->get_tema_principal($query_result->posts[0]->ID,Campos::CD_TEMA_PRINCIPAL);
        $rodape = wp_strip_all_tags(get_post_meta($query_result->posts[0]->ID, Campos::CD_RODAPE, true));

        $conteudoSemHTML = $this->removeHtml($query_result->posts[0]->post_content);
        // Cont palavras para exibir - função wordpress
        $conteudo45palavras = wp_trim_words( $conteudoSemHTML, 45, ' (...)' );
        $conteudo50palavras = wp_trim_words( $conteudoSemHTML, 50, ' (...)' );

        $post = array(
            'ideNoticia' => $query_result->posts[0]->ID,
            'texTitulo' => $query_result->posts[0]->post_title,
            'texResumo' => $query_result->posts[0]->post_excerpt,
            'texMateria' => $conteudoSemHTML,
            'texRetranca' => $tema_principal->titulo,
            'datMateria' => date('d/m/Y', strtotime($datadopost)),
            'texRodape' => $rodape,
            'datUltimaAlteracao' => null,
            'datPublicacao' => null,
            'datAtualizacao' => null,
            'urlCompleta' => get_permalink($query_result->posts[0]->ID),
            'imagemMateria' => $imagens,
            'texResumoDestaque' => $conteudo50palavras,
            'texExplicacaoProjeto' => $conteudo45palavras
        );
        return $post;
    }

    public function get_noticias_tempo_real($id, $data_materia, $temaDoDia) {
        /* Obtém todos os posts da mesma data da materia 
        *  e que possuem o mesmo tema do dia e o mesmo tipo.
        */
        $materias = get_posts(array(
            'post_type'  => 'agencia',
            'date_query' => array(
                'year' => date("Y", strtotime($data_materia)),
                'month' => date("m", strtotime($data_materia)),
                'day' => date("d", strtotime($data_materia))
            ),
            'tax_query' => array(
                array(
                    'taxonomy' => 'tema_do_dia',
                    'field' => 'id',
                    'terms' => $temaDoDia->getId(),
                    'include_children' => false
                )
            ),
            'meta_query' => array(
                array(
                    'key'     => 'cd_tipo',
                    'value'   => 'TEMPO_REAL',
                ),
            )
        ));
        $result = array();
        foreach ($materias as $key => $post) {
            if (intval($post->ID) != intval($id)) {
                $link = '/noticias/'.$post->ID.'-'.$post->post_name;
                array_push($result, array(
                    'id' => $post->ID,
                    'hora' => date("H:i:s", strtotime($post->post_date)),
                    'titulo' => $post->post_title,
                    'link' => $link
                ));
            }
        }
        return $result;
    }

    public function retornar_conteudo($fields, $tipo_objeto, $params)
    {
        $id = $fields['id'];
        $area_conteudo = $this->obter_dados_area_conteudo($tipo_objeto);
        $conteudoFactory = new ConteudoFactory(
            $this,
            $fields,
            $this->obter_objeto_wp($tipo_objeto),
            $tipo_objeto,
            $this->wpServiceMenu->criar($area_conteudo),
            $area_conteudo,
            $this->wpServiceBreadCrumbs->criar($area_conteudo),
            $this->wpServiceMidia->criarMidiaDestaque($id),
            $this->obter_dados_tags_relacionadas($id)
        );
        return $conteudoFactory->criar();
    }

    public function get_programa_principal($idPost, $field)
    {
        $idTema = get_post_meta($idPost, $field);
        $programa_principal = get_post($idTema[0]);
        return array('id'=> $programa_principal->ID, 'titulo' => $programa_principal->post_title);
    }

}
