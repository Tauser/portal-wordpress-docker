<?php namespace conteudo\portal\api\service;

require_once(plugin_dir_path(__FILE__) . '../factory/ConteudoFactory.php');
require_once(plugin_dir_path(__FILE__) . '../model/AreaConteudo.php');
require_once(plugin_dir_path(__FILE__) . '../model/Pagina.php');
require_once(plugin_dir_path(__FILE__) . '../model/AreaConteudoDestaqueTopo.php');
require_once(plugin_dir_path(__FILE__) . '../model/AreaConteudoEstreia.php');
require_once(plugin_dir_path(__FILE__) . '../mapper/FieldsMapper.php');
require_once(plugin_dir_path(__FILE__) . '../model/Taxonomy.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/HomeCampos.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;
use conteudo\portal\api\mapeamento\HomeCampos as HomeCampos;
use conteudo\portal\api\factory\ConteudoFactory as ConteudoFactory;
use conteudo\portal\api\model\AreaConteudo as AreaConteudo;
use conteudo\portal\api\model\Pagina as Pagina;
use conteudo\portal\api\model\AreaConteudoDestaqueTopo as AreaConteudoDestaqueTopo;
use conteudo\portal\api\model\AreaConteudoEstreia as AreaConteudoEstreia;
use conteudo\portal\api\model\mapper\FieldsMapper as FieldsMapper;
use conteudo\portal\api\model\Taxonomy as Taxonomy;


/**
 * Classe de servico que possui funcoes especificas para trazer informacoes do wordpress
 */
class WPServiceBoletim
{


    public function buscar_ultimas($post_type, $meta_programa_principal, $id_principal)
    {
        // Ultimas
        $objeto_query_params = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => 6,
            'orderby' => 'date',
            'order' => 'desc',
            'meta_query' => array(
                array(
                    'key' => $meta_programa_principal,
                    'value' => $id_principal,
                    'compare' => '=',
                )
            )
        );

        $query_result = new \WP_Query($objeto_query_params);

        $ultimas = array();

        foreach ($query_result->posts as $result) {

            $datadopost = $result->post_date;

            $imagens = $this->wpServiceMidia->obter_imagens_post($result->ID);
            $tema_principal = get_post_meta($result->ID, 'tema_principal', true);
            $videos = $this->wpServiceMidia->obter_videos_post($result->ID);
            $audios = $this->wpServiceMidia->obter_audios_post($result->ID);

            $temp = array(
                'id' => $result->ID,
                'titulo' => $result->post_title,
                'link' => get_permalink($result->ID),
                'data' => $datadopost,
                'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                'hora_formatada' => date('H:i', strtotime($datadopost)),
                'resumo' => wp_strip_all_tags(get_post_meta($result->ID, 'resumo', true)),
                'tema_principal' => $tema_principal ? $tema_principal['post_title'] : '',
                'area' => get_post_meta($result->ID, 'area', true),
                'conteudo' => apply_filters('the_content', $result->post_content),
                'imagens' => $imagens,
                'videos' => $videos,
                'audios' => $audios,
                'horario' => get_post_meta($result->ID, 'horario', true)
            );

            array_push($ultimas, $temp);
        }

        return $ultimas;
    }

    public function busca_boletim($params)
    {
        // args
         $args = array(
            'post_type' => $params['tipo'],
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'date_query' => array(
                'day' => date('d', strtotime($params['data'])),
                'month' => date('m', strtotime($params['data'])),
                'year' => date('Y', strtotime($params['data'])), 
            ),
            'meta_query' => array(
                array(
                    'key' => Campos::CD_VISIVEL_BOLETIM,
                    'value' => '1',
                    'compare' => '=',
                    'type' => 'VARCHAR'
                ),
            ),
            'meta_key' => Campos::CD_TEMA_PRINCIPAL,
            'orderby' => 'meta_value',
            'order' => 'ASC'
        );
        // Results wp-query
        $query_result = new \WP_Query($args);

        $temas_retornados = array();
        // Pegas temas dos posts
        foreach ($query_result->posts as $result) {
            array_push($temas_retornados, $this->get_tema_principal($result->ID, Campos::CD_TEMA_PRINCIPAL));  
        }
        $temas_retornados = array_unique($temas_retornados, SORT_REGULAR);

        // var agrupamento
        $posts_tema = array();
        $tema_agrupado = array();

        foreach ($temas_retornados as $tema) {
            foreach ($query_result->posts as $result) {
                $tema_atual = $this->get_tema_principal($result->ID, Campos::CD_TEMA_PRINCIPAL);                

                if ($tema->titulo == $tema_atual->titulo){
                    $datadopost = $result->post_date;
                    
                    $temp = array(
                        'id' => $result->ID,
                        'titulo' => $result->post_title,
                        'link' => get_permalink($result->ID),
                        'data' => $datadopost,
                        'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                        'hora_formatada' => date('H:i', strtotime($datadopost)),
                        'resumo' => wp_strip_all_tags(get_post_meta($result->ID, 'resumo', true)),
                        'tema_principal' => $tema_atual,
                        'area' => get_post_meta($result->ID, 'area', true),
                        'conteudo' => apply_filters('the_content', $result->post_content),
                        'horario' => get_post_meta($result->ID, 'horario', true)
                    );
                    array_push($posts_tema, $temp);
                    $temp = null;
                }
            }
            $path = wpconfiguracoes_obter_dados_pagina_tematica($tema);
            $temp_tema = array(
                'tema' => $tema->titulo,
                'link' => wpconfiguracoes_obter_dados_pagina_tematica($tema)['link'],
                'noticias'  => $posts_tema
            );
            
            // agrupagar temas
            array_push($tema_agrupado, $temp_tema);
        }
        return $tema_agrupado;
    }

    public function busca_boletim_radio($params)
    {
        // var ...
        $boletim_radio =  array();
        $boletim_programas = array();
        $nome_programas = array();

        // Por padrão para o boletim de radio deve retorna dia anterior da data pesquisada 
        $dia_anterior = date('d-m-Y', strtotime('-1 days', strtotime($params['data'])));
        $radio_agencia = $this->busca_post_boletim('radioagencia', $dia_anterior);

        $edicao_programa_radi = $this->busca_post_boletim('edicao_programa_radi', $params['data']);
        
        // Pega nome dos programas
        foreach ($edicao_programa_radi as $result) {
            array_push($nome_programas, $this->get_programa_principal($result['id'],Campos::CD_PROGRAMA_PRINCIPAL));  
        }
        $nome_programas = array_unique($nome_programas, SORT_REGULAR);

        foreach ($nome_programas as $programa) {
            $posts = array();
            foreach ($edicao_programa_radi as $result) {
                // echo $programa['id'].' e '.$result['programa_principal']['id']."\n";
                if($programa['id'] == $result['programa_principal']['id']){
                    array_push($posts, $result);
                }
            }
            $programa = array(
                'nome' => $programa['titulo'],
                'posts' => $posts
            );
            array_push($boletim_programas, $programa);
        }

        $temp_boletim_radio = array(
            'radio_agencia' => $radio_agencia,
            'programas' => $boletim_programas
        );
        
        // agrupagar temas
        array_push($boletim_radio, $temp_boletim_radio);

        return $boletim_radio;
    }

    public function busca_post_boletim($post_type, $data)
    {   
        // retorna notícias do dia anterior informado
        $args_radio_agencia = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'date_query' => array(
                'day' => date('d', strtotime($data)),
                'month' => date('m', strtotime($data)),
                'year' => date('Y', strtotime($data)), 
            ),
            'meta_query' => array(
                array(
                    'key' => Campos::CD_VISIVEL_BOLETIM,
                    'value' => '1',
                    'compare' => '=',
                    'type' => ''
                ),
            ),
            'orderby' => 'date',
            'order' => 'desc'
        );
        // Results wp-query
        $query_result = new \WP_Query($args_radio_agencia);
        $radio_agencia = array();
        foreach ($query_result->posts as $result) {
            $programa_principal = $this->get_programa_principal($result->ID,Campos::CD_PROGRAMA_PRINCIPAL);
            $datadopost = $result->post_date;
            $temp = array(
                'id' => $result->ID,
                'titulo' => $result->post_title,
                'link' => get_permalink($result->ID),
                'data_formatada' => date('d/m/Y', strtotime($datadopost)),
                'hora_formatada' => date('H:i', strtotime($datadopost)),
                'programa_principal' => $programa_principal
            );
            array_push($radio_agencia, $temp);
        }
        return $radio_agencia;
    }

    public function get_programa_principal($idPost, $field)
    {
        $idTema = get_post_meta($idPost, $field);
        $programa_principal = get_post($idTema[0]);
        return array('id'=> $programa_principal->ID, 'titulo' => $programa_principal->post_title,);
    }

    public function get_tema_principal($idPost, $field)
    {
        $idTema = get_post_meta($idPost, $field);
        $term = get_term($idTema[0]);
        return new Taxonomy($term->term_id, $term->name);
    }
    

}
