# PLUGIN API REST DO WORDPRESS

> **BaseUrl:** /wp-json/conteudo-portal/ - **Tipos de Posts:** institucional, programa_radio, programa_tv, edicao_programa_radi, edicao_programa_tv, agencia e radioagencia.

## Alteração do botão Preview

* Para todos os tipos de posts listados acima incluindo os das páginas estáticas

## POR ID

* Retorna o objeto de acordo com o tipo de post
* /wp-json/conteudo-portal/{id}
    * Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/427

## LISTA DAS HOMES

* Retorna todas as homes publicadas
* /wp-json/conteudo-portal/home
    * Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/home

## POR HOME

* Retorna a home pelo nome
* /wp-json/conteudo-portal/home/{nome-da-home}
    * Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/home/noticias

## HOME PRINCIPAL

* Retorna post selecionados agência, institucional e últimas de agência
* /wp-json/conteudo-portal/home-principal/
    * Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/home-principal/


## CONSULTA DINÂMICA

* Parâmetros:
    * **tipo** (Tipo de Post)
    * **total** (Total do resultado. Default: 10)
    * **pagina** (Resultados de uma determinada página. Default: 1)
    * **q** (Consulta Geral)
    * **categorias** (Por Categorias. Somente para os tipos: programa_radio e programa_tv)
    * **temas** (Taxonomia: tema, tema_institucional. Somente para os tipos: institucional, edicao_programa_radi, edicao_programa_tv, agencia e radioagencia),
    * **tema_principal** (Somente para os tipos: institucional, edicao_programa_radi, edicao_programa_tv, agencia e radioagencia)
    * **tags** (Taxonomia: post_tag)
    * **boletim** (Boolean: true) "Filtra conteúdo que esteje marcado visível no boletim. Ex: &boletim=true"
    * **data** (Data do post) "Busca conteúdo por data, formato data deve ser dd-MM-YYYY"
    * **proposicao** (Número da proposição) "Busca conteúdo por proposição"
    * **id_deputado** (Id do deputado) "Busca conteúdo por deputado"
    * **Busca período**
        *  **data_inicio** (Data do post) "Busca período inicial, formato data deve ser dd-MM-YYYY"
        *  **data_final** (Data do post) "Busca período final, formato data deve ser dd-MM-YYYY"
    
Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/dinamica?tipo=programa_tv&categorias=acervo,cultura,documentarios         
Ex: Boletim - https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/dinamica?tipo=agencia&total=20&boletim=true&data=21-05-2019        
Ex: Proposição - https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/dinamica?tipo=agencia&proposicao=2193490        
Ex: Deputado - https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/dinamica?tipo=agencia&id_deputado=204414

## EXPLICATIVA POR PROPOSIÇÃO

* Retorna noticia associada a uma proposição
* /wp-json/conteudo-portal/noticia-explicativa-proposicao/{proposicao}
    * Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/noticia-explicativa-proposicao/2118960

## CONSULTA DINÂMICA DE MíDIA

* Parâmetros:
    * **tipo** (Tipo de Post)
    * **total** (Total do resultado. Default: 10)
    * **area-conteudo** (Área de conteúdo) "Busca midia por área de conteúdo"
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/dinamica-midia?area-conteudo=noticias&total=9&tipo=infografico

## CONSULTA DE BOLETIM

* Parâmetros:
    * **tipo** (Tipo de Post)
    * **data** (Data do post) "Busca por data, formato data deve ser dd-MM-YYYY"
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/boletim?tipo=agencia&data=11-06-2019
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/boletim?tipo=radio&data=11-06-2019

## CONSULTA POR TEMA

* Pesquisa por tema - Retorna notícias destaques por tema e últimas notícias sobre tema pesquisado.
* Parâmetros:
    * **tipo** (Tipo de Post) - Não implementado, pois ainda não se aplica aos outros tipos
    * **tema** (Tema do portal) Tema a ser pesquisado - deve colocar o slug do tema do portal
    * **ultimas** (Quantidade de últimas) Quantidade a ser exibida das últimas notícias referente ao tema pesquisado.
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/tema?tema=politica-e-administracao-publica&ultimas=5

## CONSULTA DE AGENCIA-DEPUTADO

* Pesquisa de notícia agencia para um deputado. Retorna notícias que tenhan associado um deputado.
* Parâmetros:
    * **id deputado** (id do deputado) - Id do deputado é obrigatório
    * **qtde** (Quantidade de posts) Quantidade de post retornado
    * **offset** Seleciona apartir do indice para exibição
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/noticias/deputados/204569?qtde=30&offset=0


## CONSULTA DE RADIO E TV

* Pesquisa edições de radio e tv.
* Parâmetros:
    * **pesquisa** (Texto para pesquisa) - Pesquia tudo com referência a esse parametro
    * **qtde** (Quantidade de posts) Quantidade de post retornado
    * **offset** Seleciona apartir do indice para exibição
    * **Busca período**
        *  **data_inicio** (Data do post) "Busca período inicial, formato data deve ser dd-MM-YYYY"
        *  **data_final** (Data do post) "Busca período final, formato data deve ser dd-MM-YYYY"
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/programas-tv/?pesquisa=Heitor%20Schuch&data_inicio=10-06-2019&data_final=02-07-2019&qtde=30&offset=0
* Ex: https://socithom.camara.gov.br/portal/portal-backend-wordpress/wp-json/conteudo-portal/programas-radio/?pesquisa=rodrigo%20maia&data_inicio=10-06-2019&data_final=02-07-2019&qtde=30&offset=0