<?php namespace conteudo\portal\api\preview;

require_once(plugin_dir_path(__FILE__) . '../mapper/FieldsMapper.php');
require_once(plugin_dir_path(__FILE__) . '../service/WPService.php');
require_once(plugin_dir_path(__FILE__) . '../config/ConfigService.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;
use conteudo\portal\api\model\mapper\FieldsMapper as FieldsMapper;
use conteudo\portal\api\service\WPService as WPService;
use conteudo\portal\api\config\ConfigService as ConfigService;

class ConfigPreview
{

    private const URL_PREVIEW_DEV = 'http://localhost:3000/visualiza';
    private const URL_PREVIEW = '/visualiza';

    public function config($baseUrl)
    {
        global $pagenow;
        if ($pagenow != 'edit.php' && 
            ($_GET['post_type'] || $_GET['post'] || $_POST['post_type'] ||  $_POST['action'])) {
            $post_type = $_GET['post_type'] ? $_GET['post_type'] : get_post_type($_GET['post']);
            wp_register_style('custom-preview-css', $baseUrl . '/view/css/custom-preview.css');
            wp_enqueue_style('custom-preview-css');
            if ($_POST['action'] == 'custom_preview' || in_array($post_type, $this->get_posts_types())) {
                $configService = new ConfigService();
                $this->wpService = new WPService(
                    $configService->wpServiceBreadCrumbs(),
                    $configService->wpServiceMenu(),
                    $configService->wpServiceMidia(),
                    $configService->wpServiceDinamico(),
                    $configService->wpServiceTematica(),
                    $configService->wpServiceBoletim()
                );
                wp_enqueue_script('custom_preview', $baseUrl . '/view/js/preview.js');
                add_action('post_submitbox_misc_actions', array($this, 'button_preview'));
                add_action('all_admin_notices', array($this, 'form'));
                $this->add_ajax_action();
            }
        }
    }

    public function form()
    {
        include(plugin_dir_path(__FILE__) . '../view/custom-form-preview.php');
    }

    public function button_preview()
    {
        include(plugin_dir_path(__FILE__) . '../view/submitbox-custom-fields.php');
    }

    public function get_tipo_post()
    {
        return get_post_type(get_the_ID());
    }

    public function action_post()
    {
        $url = urlencode(get_the_title(get_the_ID()));
        switch (getenv("WP_AMBIENTE")) {
            case "dev":
                return self::URL_PREVIEW_DEV . '/' . $url;
            case "prod":
                return 'https://www.camara.leg.br' . self::URL_PREVIEW . '/' . $url;
            default:
                return self::URL_PREVIEW . '/' . $url;
        }
    }

    public function add_ajax_action()
    {
        add_action('wp_ajax_custom_preview', array($this, 'ajax_preview'));
        add_action('wp_ajax_nopriv_custom_preview', array($this, 'ajax_preview'));
    }

    public function ajax_preview()
    {
        $response = array();
        $post = new Post($_POST['ID'], $_POST['post_title'], $_POST['post_excerpt'], $_POST['post_content'], get_the_date('Y-m-d H:i', (int) $_POST['ID']), get_post_modified_time('Y-m-d H:i', false, (int) $_POST['ID']));
        $metas = array(Campos::CD_DATA_ATUALIZACAO => get_post_meta($_POST['ID'], Campos::CD_DATA_ATUALIZACAO));
        $fields = FieldsMapper::map($post, $metas);
        $objeto = $this->wpService->retornar_conteudo($fields, $_POST['cd_post_type'], null);
        array_push($response, $objeto);
        $response[0]->conteudo = $this->replaceTagsQueSaoBloqueadasPeloBrowser($response[0]->conteudo);
        echo  json_encode($response, JSON_UNESCAPED_UNICODE);
        exit;
    }

    private function replaceTagsQueSaoBloqueadasPeloBrowser($conteudo) {
        $conteudo = str_replace('iframe', 'tag-dinamica', $conteudo);
        return $conteudo;
    }

    private function get_posts_types() {
        return array('agencia', 
                     'institucional', 
                     'edicao_programa_radi', 
                     'edicao_programa_tv', 
                     'radioagencia',
                     'pagina_agencia',
                     'pagina_tv',
                     'pagina_radio',
                     'pagina_institucional');
    }
}

final class Post
{

    public function __construct($id, $post_title, $post_excerpt, $post_content, $date, $modified)
    {
        $this->ID = $id;
        $this->post_title = $post_title;
        $this->post_excerpt = $post_excerpt;
        $this->post_content = str_replace('\\' ,'', $post_content);
        $this->post_date = $date;
        $this->post_modified = $modified;
    }
}
