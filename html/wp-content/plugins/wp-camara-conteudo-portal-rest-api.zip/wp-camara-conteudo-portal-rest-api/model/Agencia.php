<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;

/**
 * Formata resposta específicos da Agencia
 * @link              http://camara.leg.br
 * @package           @package camara_conteudo_portal_rest_api
 */

class Agencia extends Conteudo
{

    public function __construct(
        $fields,
        $objeto_wp,
        $tipo,
        $menu,
        $area_conteudo,
        $breadCrumbs,
        $midiaDestaque,
        $tags_conteudo,
        $conteudos_relacionados,
        $proposicao_principal,
        $comentarios
    ) {
        parent::__construct($fields, $objeto_wp, $tipo, $menu, $area_conteudo, $breadCrumbs, $midiaDestaque, $tags_conteudo);
        
        $this->data_atualizacao = $fields[Campos::CD_DATA_ATUALIZACAO] ? strtotime($fields[Campos::CD_DATA_ATUALIZACAO]) : null;
        $this->data_atualizacao_formatada = $fields[Campos::CD_DATA_ATUALIZACAO] ? date('d/m/Y',strtotime($fields[Campos::CD_DATA_ATUALIZACAO])) : null;
        $this->hora_atualizacao_formatada = $fields[Campos::CD_DATA_ATUALIZACAO] ? date('H:i',strtotime($fields[Campos::CD_DATA_ATUALIZACAO])) : null;
        $this->tema_principal = $conteudos_relacionados[Campos::CD_TEMA_PRINCIPAL];
        $this->outros_temas = $conteudos_relacionados[Campos::CD_TEMAS];
        $this->tema_do_dia = $conteudos_relacionados[Campos::CD_TEMA_DO_DIA];
        $this->rodape = $fields[Campos::CD_RODAPE];
        $this->tipo_midia = $fields[Campos::CD_TIPO_MIDIA];
        $this->tipo_noticia = $fields[Campos::CD_TIPO];
        $this->continuacao =$conteudos_relacionados[Campos::CD_CONTINUACAO];
        $this->deputados = $fields[Campos::CD_DEPUTADOS];
        $this->proposicoes = $fields[Campos::CD_PROPOSICOES];
        $this->leis = $fields[Campos::CD_LEGISLACOES];
        $this->materias_relacionadas = $conteudos_relacionados[Campos::CD_RELACIONADAS];
        $this->visivel_boletim = $fields[Campos::CD_VISIVEL_BOLETIM] == 1 ? "sim" : "não";
        $this->visivel_home = $fields[Campos::CD_VISIVEL_HOME]  == 1 ? "sim" : "não";
        $this->portal_congresso = $fields[Campos::CD_VISIVEL_PORTAL_CONGRESSO] == 1 ? "sim" : "não";
        $this->comentarios_sisnews = $comentarios;
        $this->total_comentarios_sisnews = sizeof($comentarios);
        $this->pagina_tematica = $conteudos_relacionados['pagina_tematica'];
        $this->tempo_real = $conteudos_relacionados['tempo_real'];
        
    }
}

?>