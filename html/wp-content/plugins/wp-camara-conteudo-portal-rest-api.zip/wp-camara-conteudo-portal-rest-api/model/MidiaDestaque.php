<?php namespace conteudo\portal\api\model;

class MidiaDestaque
{

    public function __construct($imagens, $videos, $audios, $arquivos) {
        $this->imagens = $imagens;
        $this->videos = $videos;
        $this->audios = $audios;
        $this->arquivos = $arquivos;
    }

    public function getImagens() {
        return $this->imagens;
    }

    public function getVideos() {
        return $this->videos;
    }

    public function getAudios() {
        return $this->audios;
    }

    public function getArquivos() {
        return $this->arquivos;
    }

}

?>