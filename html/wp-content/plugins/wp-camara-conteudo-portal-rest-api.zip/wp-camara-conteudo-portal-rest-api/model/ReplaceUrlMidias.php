<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;

/**
 * 
 */
class ReplaceUrlMidias {

    const REGEX_URL = '/(http:\/\/|https:\/\/)(.*?)(wp-content\/uploads\/midias)(.*?)(\.jpg|\.jpeg|\.png|\.mp4|\.mp3|\.wma|\.wmv|\.avi|\.pdf|\.doc|\.docx)/';
    const REGEX_MIDIAS_URL = '/(midias)(.*?)(\.jpg|\.jpeg|\.png|\.mp4|\.mp3|\.wma|\.wmv|\.avi|\.pdf|\.doc|\.docx)/';
    private const URL_DEV = 'http://localhost:3001/';
    private const URL_TES = 'https://socittes.camara.gov.br/';
    private const URL_HOM = 'https://socithom.camara.gov.br/';
    private const URL_PROD = 'https://www.camara.leg.br/';

    static function replace_conteudo($html) {
        $urls = array();
        preg_match_all(self::REGEX_URL, $html, $urls);
        foreach ($urls[0] as $url) {
            $url_midia = array();
            preg_match_all(self::REGEX_MIDIAS_URL, $url, $url_midia);
            $html = str_replace($url, self::get_url_base() . $url_midia[0][0], $html);
        }

        return $html;
    }

    static function get_url_base() {
        switch (getenv("WP_AMBIENTE")) {
            case "dev":
                return self::URL_DEV;
            case "tes":
                return self::URL_TES;
            case "hom":
                return self::URL_HOM;
            case "prod":
                return self::URL_PROD;
            default:
                return self::URL_DEV;
        } 
    }

}

?>