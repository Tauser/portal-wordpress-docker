<?php namespace conteudo\portal\api\model;

class PaginaDinamica extends Conteudo
{

    public function __construct(
        $fields,
        $tipo,
        $menu,
        $objeto_wp,
        $area_conteudo,
        $breadCrumbs,
        $imagem_destaque,
        $video_destaque,
        $audio_destaque,
        $arquivo_anexo,
        $tags_conteudo
    ) {
        parent::__construct($fields, $tipo, $menu, $objeto_wp, $area_conteudo, $breadCrumbs, $imagem_destaque, $video_destaque, $audio_destaque, $arquivo_anexo, $tags_conteudo);
        $this->id = $fields['id'];
        $this->nome = $fields['nome'];
        $this->area_conteudo = $area_conteudo;
        $this->objeto_query = $fields['objeto_query'];
        $this->ordenar_por = $fields['ordenar_por'];
        $this->ordem = $fields['ordem'];
        $this->quantidade_por_pagina = $fields['quantidade_por_pagina'];
        $this->usar_area_pagina = $fields['usar_area_pagina'];
        $this->area_conteudo_pagina_dinamica = $fields['area_conteudo_pagina_dinamica'];
        $this->filtro_por_taxonomia = $fields['filtro_por_taxonomia'];
        $this->slug_taxonomia = $fields['slug_taxonomia'];
        $this->total_posts = $fields['total_posts'];
        $this->posts = $fields['posts'];
        
    }
}

?>