<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . './ReplaceUrlMidias.php');

use conteudo\portal\api\model\ReplaceUrlMidias as ReplaceUrlMidias;


/**
 * Formata resposta padrão do endpoint conteudo-portal
 * 
 * @link              http://camara.leg.br
 * @package           @package camara_conteudo_portal_rest_api
 * 
 */
class Conteudo {

    public function __construct($fields, $objeto_wp, $tipo, $menu, $area_conteudo, $breadCrumbs, $midiaDestaque, $tags_conteudo) {
        $this->id = $fields['id'];
        $this->tipo_conteudo = $tipo;
        $this->objeto_wp = $objeto_wp;
        $this->link = $fields['permalink'];
        $this->area_conteudo = $area_conteudo;
        $this->path_separado = $this->gerar_path();
        $this->breadcrumbs = $breadCrumbs;
        $this->menu_local = $menu;
        $this->titulo = $fields['title'];
        $this->data = strtotime($fields['date']);
        $this->data_formatada = date('d/m/Y',strtotime($fields['date']));
        $this->hora_formatada = date('H:i',strtotime($fields['date']));
        $this->conteudo = wpautop(ReplaceUrlMidias::replace_conteudo($fields['post_content']));       
        $this->resumo = $fields['resumo'];
        $this->imagens = $midiaDestaque->getImagens();
        $this->videos = $midiaDestaque->getVideos();
        $this->audios = $midiaDestaque->getAudios();
        $this->arquivos = $midiaDestaque->getArquivos();
        $this->tags_conteudo = $tags_conteudo;
    }

    // public function __construct($fields, 
    //                             $tipo, 
    //                             $menu, 
    //                             $objeto_wp, 
    //                             $area_conteudo, 
    //                             $breadCrumbs, 
    //                             $imagem_destaque, 
    //                             $video_destaque, 
    //                             $audio_destaque, 
    //                             $arquivo_anexo, 
    //                             $tags_conteudo) {

    //     $this->id = $fields['id'];
    //     $this->tipo_conteudo = $tipo;
    //     $this->objeto_wp = $objeto_wp;
    //     $this->area_conteudo = $area_conteudo;
    //     $this->link = $fields['permalink'];
    //     $this->path_separado = $this->gerar_path();
    //     $this->breadcrumbs = $breadCrumbs;
    //     $this->menu_local = $menu;
    //     $this->titulo = $fields['title'];
    //     $this->data = strtotime($fields['date']);
    //     $this->data_formatada = date('d/m/Y',strtotime($fields['date']));
    //     $this->hora_formatada = date('H:i',strtotime($fields['date']));
    //     $this->data_atualizacao = strtotime($fields['modified']);
    //     $this->data_atualizacao_formatada = date('d/m/Y',strtotime($fields['modified']));
    //     $this->hora_atualizacao_formatada = date('H:i',strtotime($fields['modified']));
    //     $this->conteudo = wpautop($fields['post_content']);        
    //     $this->resumo = $fields['resumo'];
    //     $this->imagem_destaque = $imagem_destaque;
    //     $this->videos = $video_destaque;
    //     $this->imagem_poster = null;
    //     $this->audios = $audio_destaque;
    //     $this->arquivo_anexo = $arquivo_anexo;
    //     $this->tags = $tags_conteudo;
    
    // }

    public function getId() {
        return $this->id;
    }

    //
    // Gera a string do path
    //
    private function gerar_path() {
        $the_path = explode ("/", $this->link );
        array_pop($the_path); 
        array_shift($the_path);
        return $the_path;
    }

    //
    // Buscar deputados relacionados
    //
    protected function obter_dados_deputados_relacionados($deputados) {
        $deputados_relacionados  = array();
        if( is_array($deputados)) {
            foreach($deputados as $dep ) {
                $nome_formatado = explode('|', $dep['description']);
                $relacionada = array(
                'id' => (int)$dep['term_id'],
                'nome' => ucwords(strtolower($dep['name'])),
                'idecadastro' => $dep['slug'],
                'nome_formatado' => ucwords(strtolower($nome_formatado[0])) . ' ('.  $nome_formatado[1]  . ')'
                );
                array_push( $deputados_relacionados, $relacionada);
            }
        }
        return $deputados_relacionados;
    }

    //
    // Buscar proposições relacionadas
    //
    protected function obter_dados_proposicoes_relacionadas($proposicoes) {
        $proposicoes_relacionadas  = array();
        if( is_array($proposicoes) ) {
            foreach($proposicoes as $prop ) {
                $relacionada = array(
                'id' => (int)$prop['term_id'],
                'nome' => $prop['name'],
                'idecadastro' => $prop['slug']
                );
                array_push( $proposicoes_relacionadas , $relacionada);
            }
        }
        return $proposicoes_relacionadas;
    }  
}