<?php namespace conteudo\portal\api\model;
require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;
/**
 * Formata resposta específicos da Agencia
 * @link              http://camara.leg.br
 * @package           @package camara_conteudo_portal_rest_api
 */

class Institucional extends Conteudo
{

    public function __construct(
        $fields,
        $objeto_wp,
        $tipo,
        $menu,
        $area_conteudo,
        $breadCrumbs,
        $midiaDestaque,
        $tags_conteudo,
        $conteudos_relacionados,
        $proposicao_principal,
        $comentarios
    ) {

        parent::__construct($fields, $objeto_wp, $tipo, $menu, $area_conteudo, $breadCrumbs, $midiaDestaque, $tags_conteudo);
        $this->tema_principal = $conteudos_relacionados[Campos::CD_TEMA_PRINCIPAL];
        $this->outros_temas = $conteudos_relacionados[Campos::CD_TEMAS];
        $this->tema_do_dia = $conteudos_relacionados[Campos::CD_TEMA_DO_DIA];
        $this->rodape = $fields[Campos::CD_RODAPE];
        $this->tipo_midia = $fields[Campos::CD_TIPO_MIDIA];
        $this->tipo_noticia = $fields[Campos::CD_TIPO];
        $this->deputados = $this->obter_dados_deputados_relacionados($fields['deputados']);
        $this->projetos_de_lei = $this->obter_dados_proposicoes_relacionadas($fields['proposicoes']);
        $this->projeto_lei_principal = $proposicao_principal;
        // $this->continuacao_noticia = $conteudos_relacionados['continuacao_noticia'];
        $this->materias_relacionadas = $conteudos_relacionados[Campos::CD_RELACIONADAS];
        $this->visivel_boletim = $fields[Campos::CD_VISIVEL_BOLETIM] == 1 ? "sim" : "não";
        $this->visivel_home = $fields[Campos::CD_VISIVEL_HOME]  == 1 ? "sim" : "não";
        $this->portal_congresso = $fields[Campos::CD_VISIVEL_PORTAL_CONGRESSO] == 1 ? "sim" : "não";
        $this->comentarios_sisnews = $comentarios;
        $this->total_comentarios_sisnews = sizeof($comentarios);
    }
}