<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . '/AreaConteudo.php');

use conteudo\portal\api\model\AreaConteudo as AreaConteudo;

class AreaConteudoDestaqueTopo extends AreaConteudo
{

    public function __construct($id, $titulo, $link) {
        parent::__construct($id, $titulo, '');
        $this->link = $link;
    }

}
?>