<?php namespace conteudo\portal\api\model;

class Midia {

    public function __construct($id, $nome, $descricao, $legenda, $texto_alternativo, $autor, $local, $tema, $data, $institucional, $sizes, $url, $url_midia, $url_thumb_midia) {
        $this->id = $id;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->legenda = $legenda;
        $this->texto_alternativo = $texto_alternativo;
        $this->autor = $autor;
        $this->local = $local;
        $this->tema = $tema;
        $this->data = $data;
        $this->institucional = $institucional == "1" ? 'Sim' : 'Não';
        $this->sizes = $sizes;
        $this->url = $url;
        $this->url_midia = $url_midia;
        $this->url_thumb_midia = $url_thumb_midia;
    }
}

?>