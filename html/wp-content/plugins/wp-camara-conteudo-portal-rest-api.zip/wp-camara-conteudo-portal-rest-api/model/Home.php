<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/HomeCampos.php');
require_once(plugin_dir_path(__FILE__) . './ReplaceUrlMidias.php');

use conteudo\portal\api\mapeamento\HomeCampos as HomeCampos;
use conteudo\portal\api\model\ReplaceUrlMidias as ReplaceUrlMidias;

/**
 * Formata resposta para conteúdo tipo Area de conteudo do endpoint conteudo-portal
 * 
 * @link              http://camara.leg.br
 * @package           @package camara_conteudo_portal_rest_api
 * 
 */

class Home
{

    public function __construct($fields, $tipo, $objeto_wp, $destaqueTopo, $estreia)
    {
        $this->id = $fields['id'];
        $this->name = $fields['post_title'];
        $this->slug = $fields['post_name'];
        $this->tipo_conteudo = $tipo;
        $this->objeto_wp = $objeto_wp;
        $this->link = $fields['permalink'];
        $this->path_separado = $fields['permalink'];
        $this->breadcrumbs = array();
        $this->menu = array();
        $this->titulo = $fields['title'];
        $this->home_conteudo_html = ReplaceUrlMidias::replace_conteudo($fields[HomeCampos::CD_AREA_CONTEUDO_HTML_HOME_PUBLICADA]);
        $this->home_conteudo_json = json_decode(ReplaceUrlMidias::replace_conteudo($fields[HomeCampos::CD_AREA_CONTEUDO_JSON_HOME_PUBLICADA]));
        // $this->objeto_conteudo_externo = $fields['conteudo_externo'];
        // $this->id_conteudo_externo = (int)$fields['id_conteudo_externo'];
        // $this->conteudo_externo = $conteudo_externo;
        $this->destaqueTopo = $destaqueTopo;
        $this->estreia = $estreia;
    }

}