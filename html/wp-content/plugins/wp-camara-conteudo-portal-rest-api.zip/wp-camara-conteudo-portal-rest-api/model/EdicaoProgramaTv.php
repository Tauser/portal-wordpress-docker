<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;

/**
 * Formata resposta específicos da Agencia
 * @link              http://camara.leg.br
 * @package           @package camara_conteudo_portal_rest_api
 */

class EdicaoProgramaTv extends Conteudo
{

    public function __construct(
        $fields,
        $objeto_wp,
        $tipo,
        $menu,
        $area_conteudo,
        $breadCrumbs,
        $midiaDestaque,
        $tags_conteudo,
        $conteudos_relacionados,
        $proposicao_principal,
        $comentarios
    ) {

        parent::__construct($fields, $objeto_wp, $tipo, $menu, $area_conteudo, $breadCrumbs, $midiaDestaque, $tags_conteudo);

        $this->horario = $fields['horario'];

        $this->tema_principal = $conteudos_relacionados[Campos::CD_TEMA_PRINCIPAL];
        $this->outros_temas = $conteudos_relacionados[Campos::CD_TEMAS];
        $this->rodape = $fields[Campos::CD_RODAPE];
        $this->tipo_midia = $fields[Campos::CD_TIPO_MIDIA];
        $this->tipo_noticia = $fields[Campos::CD_TIPO];
        $this->materias_relacionadas = $conteudos_relacionados[Campos::CD_RELACIONADAS];
        $this->visivel_boletim = $fields[Campos::CD_VISIVEL_BOLETIM] == 1 ? "sim" : "não";
        $this->visivel_home = $fields[Campos::CD_VISIVEL_HOME]  == 1 ? "sim" : "não";
        $this->portal_congresso = $fields[Campos::CD_VISIVEL_PORTAL_CONGRESSO] == 1 ? "sim" : "não";
        $this->programa_principal = $conteudos_relacionados[Campos::CD_PROGRAMA_PRINCIPAL];
        $this->outros_programas = $conteudos_relacionados[Campos::CD_PROGRAMAS];
        $this->data_estreia = $fields[Campos::CD_DATA_ESTREIA];
        $this->hora_estreia = $fields[Campos::CD_HORA_ESTREIA];
        $this->destaque_home_programa = $fields[Campos::CD_DESTAQUE_HOME_PROGRAMA] == 1 ? "sim" : "não";
        $this->destaque_home_tematica = $fields[Campos::CD_DESTAQUE_HOME_TEMATICA] == 1 ? "sim" : "não";

        $this->deputados = $this->obter_dados_deputados_relacionados($fields['deputados']);
        $this->projetos_de_lei = $this->obter_dados_proposicoes_relacionadas($fields['proposicoes']);
        $this->projeto_lei_principal = $proposicao_principal;
        $this->comentarios_sisnews = $comentarios;
        $this->total_comentarios_sisnews = sizeof($comentarios);
        $this->ultimas = $conteudos_relacionados['ultimas'];
        $this->pagina_tematica = $conteudos_relacionados['pagina_tematica'];
    }
}