<?php namespace conteudo\portal\api\model;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');

use conteudo\portal\api\mapeamento\Campos as Campos;


/**
 * Formata resposta específicos da ProgramaTv
 * @link              http://camara.leg.br
 * @package           @package camara_conteudo_portal_rest_api
 */

class ProgramaTv extends Conteudo
{

    public function __construct(
        $fields,
        $objeto_wp,
        $tipo,
        $menu,
        $area_conteudo,
        $breadCrumbs,
        $midiaDestaque,
        $tags_conteudo,
        $conteudos_relacionados,
        $proposicao_principal,
        $comentarios
    ) {

        parent::__construct($fields, $objeto_wp, $tipo, $menu, $area_conteudo, $breadCrumbs, $midiaDestaque, $tags_conteudo);
        $this->categoria = $conteudos_relacionados[Campos::CD_CATEGORIA];
        $this->horario = $fields[Campos::CD_HORARIO];
        $this->downloads = $fields[Campos::CD_PERMITIR_DOWNLOAD] == 1 ? 'sim' : 'não';
        $this->desativado = $fields[Campos::CD_DESATIVADO] == 1 ? 'sim' : 'não';
        $this->quantidade_destaques = $fields[Campos::CD_QTD_DESTAQUES];
        $this->ordem = $fields[Campos::CD_ORDEM];
        // $this->destaque = $conteudos_relacionados['destaque'];
        $this->ultimas = $conteudos_relacionados['ultimas'];
        // $this->categorias_selecionadas = $fields['categoria_de_programa_de_tv'];
        $this->comentarios_sisnews = $comentarios;
        $this->total_comentarios_sisnews = sizeof($comentarios);
    }
}