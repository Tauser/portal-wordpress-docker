<?php namespace conteudo\portal\api\model;

class AreaConteudoEstreia extends AreaConteudo
{

    public function __construct($id, $titulo, $link, $tema, $resumo, $poster, $video, $audio) {
        parent::__construct($id,$titulo, '');
        $this->link = $link;
        $this->tema = $tema;
        $this->resumo  = $resumo;
        $this->poster = $poster;
        $this->video = $video;
        $this->audio = $audio;
    }

}
?>