<?php namespace conteudo\portal\api\model;

class AreaConteudo {

    public function __construct($id, $titulo, $nome) {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->nome = $nome;
    }
}

?>