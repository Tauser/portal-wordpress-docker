<?php namespace conteudo\portal\api\model\mapper;

// require_once(plugin_dir_path(__FILE__) . '../mapeamento/AssessoriaImprensaCampos.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/Campos.php');
// require_once(plugin_dir_path(__FILE__) . '../mapeamento/ProgramaTvCampos.php');
// require_once(plugin_dir_path(__FILE__) . '../mapeamento/ProgramaRadioCampos.php');
// require_once(plugin_dir_path(__FILE__) . '../mapeamento/RadioAgenciaCampos.php');
// require_once(plugin_dir_path(__FILE__) . '../mapeamento/EdicaoProgramaTvCampos.php');
// require_once(plugin_dir_path(__FILE__) . '../mapeamento/EdicaoProgramaRadioCampos.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/HomeCampos.php');

// use conteudo\portal\api\mapeamento\AssessoriaImprensaCampos as AssessoriaImprensaCampos;
use conteudo\portal\api\mapeamento\Campos as Campos;
// use conteudo\portal\api\mapeamento\ProgramaTvCampos as ProgramaTvCampos;
// use conteudo\portal\api\mapeamento\RadioAgenciaCampos as RadioAgenciaCampos;
// use conteudo\portal\api\mapeamento\EdicaoProgramaTvCampos as EdicaoProgramaTvCampos;
// use conteudo\portal\api\mapeamento\EdicaoProgramaRadioCampos as EdicaoProgramaRadioCampos;
// use conteudo\portal\api\mapeamento\ProgramaRadioCampos as ProgramaRadioCampos;
use conteudo\portal\api\mapeamento\HomeCampos as HomeCampos;

class FieldsMapper {
    public static function map($post, $metas) {
        return array(
            "id" => $post->ID,
            "title" => $post->post_title,
            "post_type" => $post->post_type,
            "date" =>  $post->post_date,
            "modified" =>  $post->post_modified,
            "post_content" =>  $post->post_content,
            "resumo" => $post->post_excerpt,
            "permalink" => get_permalink($post->ID),

            Campos::CD_DATA_ATUALIZACAO => $metas[Campos::CD_DATA_ATUALIZACAO][0],
            Campos::CD_TIPO => $metas[Campos::CD_TIPO][0],
            Campos::CD_VISIVEL_HOME => $metas[Campos::CD_VISIVEL_HOME][0],
            Campos::CD_VISIVEL_BOLETIM => $metas[Campos::CD_VISIVEL_BOLETIM][0],
            Campos::CD_RODAPE => $metas[Campos::CD_RODAPE][0],
            Campos::CD_VISIVEL_PORTAL_CONGRESSO => $metas[Campos::CD_VISIVEL_PORTAL_CONGRESSO][0],
            Campos::CD_TEMA_PRINCIPAL => $metas[Campos::CD_TEMA_PRINCIPAL][0],
            Campos::CD_TEMAS => $metas[Campos::CD_TEMAS][0],
            Campos::CD_RELACIONADAS => $metas[Campos::CD_RELACIONADAS][0],
            Campos::CD_TEMA_DO_DIA => $metas[Campos::CD_TEMA_DO_DIA][0],
            Campos::CD_AREA => $metas[Campos::CD_AREA][0],
            Campos::CD_TIPO_MIDIA => $metas[Campos::CD_TIPO_MIDIA][0],
            Campos::CD_DATA_ESTREIA => $metas[Campos::CD_DATA_ESTREIA][0],
            Campos::CD_HORA_ESTREIA => $metas[Campos::CD_HORA_ESTREIA][0],
            Campos::CD_PROGRAMA_PRINCIPAL => $metas[Campos::CD_PROGRAMA_PRINCIPAL][0],
            Campos::CD_PROGRAMAS => $metas[Campos::CD_PROGRAMAS][0],
            Campos::CD_DESTAQUE_HOME_PROGRAMA => $metas[Campos::CD_DESTAQUE_HOME_PROGRAMA][0],
            Campos::CD_DESTAQUE_HOME_TEMATICA => $metas[Campos::CD_DESTAQUE_HOME_TEMATICA][0],
            Campos::CD_CATEGORIA => $metas[Campos::CD_CATEGORIA][0],
            Campos::CD_ORDEM => $metas[Campos::CD_ORDEM][0],
            Campos::CD_QTD_DESTAQUES => $metas[Campos::CD_QTD_DESTAQUES][0],
            Campos::CD_HORARIO => $metas[Campos::CD_HORARIO][0],
            Campos::CD_ACERVO => $metas[Campos::CD_ACERVO][0],
            Campos::CD_PERMITIR_DOWNLOAD => $metas[Campos::CD_PERMITIR_DOWNLOAD][0],
            Campos::CD_DESATIVADO => $metas[Campos::CD_DESATIVADO][0],
            Campos::CD_DEPUTADOS => $metas[Campos::CD_DEPUTADOS],
            Campos::CD_PROPOSICOES => $metas[Campos::CD_PROPOSICOES],
            Campos::CD_LEGISLACOES => $metas[Campos::CD_LEGISLACOES],

            HomeCampos::CD_AREA_CONTEUDO_ID_HOME_PUBLICADA => $metas[HomeCampos::CD_AREA_CONTEUDO_ID_HOME_PUBLICADA][0],
            HomeCampos::CD_AREA_CONTEUDO_HTML_HOME_PUBLICADA => $metas[HomeCampos::CD_AREA_CONTEUDO_HTML_HOME_PUBLICADA][0],
            HomeCampos::CD_AREA_CONTEUDO_JSON_HOME_PUBLICADA => $metas[HomeCampos::CD_AREA_CONTEUDO_JSON_HOME_PUBLICADA][0],
            HomeCampos::CD_AREA_CONTEUDO_TIPO_CONTEUDO => $metas[HomeCampos::CD_AREA_CONTEUDO_TIPO_CONTEUDO][0],
            HomeCampos::CD_AREA_CONTEUDO_WP_ROLE => $metas[HomeCampos::CD_AREA_CONTEUDO_WP_ROLE][0],

            HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_ID => $metas[HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_ID][0],
            HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_LINK => $metas[HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_LINK][0],
            HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_TITULO => $metas[HomeCampos::CD_HOME_PAGE_DESTAQUE_TOPO_TITULO][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_ID => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_ID][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_LINK => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_LINK][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_TEMA => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_TEMA][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_TITULO => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_TITULO][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_RESUMO => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_RESUMO][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_POSTER => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_POSTER][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_VIDEO => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_VIDEO][0],
            HomeCampos::CD_HOME_PAGE_ESTREIA_AUDIO => $metas[HomeCampos::CD_HOME_PAGE_ESTREIA_AUDIO][0],

        );
    }
}
?>