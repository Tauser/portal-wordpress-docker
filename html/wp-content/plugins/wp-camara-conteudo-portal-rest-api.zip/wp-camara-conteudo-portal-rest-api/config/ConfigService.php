<?php namespace conteudo\portal\api\config;

require_once(plugin_dir_path(__FILE__) . '../service/WPServiceBreadCrumbs.php');
require_once(plugin_dir_path(__FILE__) . '../service/WPServiceMenu.php');
require_once(plugin_dir_path(__FILE__) . '../service/WPServiceMidia.php');
require_once(plugin_dir_path(__FILE__) . '../service/WPServiceDinamico.php');
require_once(plugin_dir_path(__FILE__) . '../service/WPServiceTematica.php');
require_once(plugin_dir_path(__FILE__) . '../service/WPServiceBoletim.php');

use conteudo\portal\api\service\WPServiceBreadCrumbs as WPServiceBreadCrumbs;
use conteudo\portal\api\service\WPServiceMenu as WPServiceMenu;
use conteudo\portal\api\service\WPServiceMidia as WPServiceMidia;
use conteudo\portal\api\service\WPServiceDinamico as WPServiceDinamico;
use conteudo\portal\api\service\WPServiceTematica as WPServiceTematica;
use conteudo\portal\api\service\WPServiceBoletim as WPServiceBoletim;

class ConfigService {
    
    public function wpServiceBreadCrumbs () {
        return new WPServiceBreadCrumbs();
    }

    public function wpServiceMenu() {
        return new WPServiceMenu();
    }

    public function wpServiceMidia() {
        return new WPServiceMidia();
    }

    public function wpServiceDinamico() {
        return new WPServiceDinamico();
    }

    public function wpServiceTematica() {
        return new WPServiceTematica();
    }
    
    public function wpServiceBoletim() {
        return new WPServiceBoletim();
    }
}

?>