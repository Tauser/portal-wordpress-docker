<?php namespace conteudo\portal\api\mapeamento;

abstract class Campos
{
    const CD_TIPO = "cd_tipo";
    const CD_VISIVEL_HOME = "cd_visivelHome";
    const CD_VISIVEL_BOLETIM = "cd_visivelBoletim";
    const CD_RODAPE = "cd_rodape";
    const CD_VISIVEL_PORTAL_CONGRESSO = "cd_portalDoCongresso";
    const CD_TEMA_PRINCIPAL = "cd_temaPrincipal";
    const CD_TEMAS = "cd_temas";
    const CD_RELACIONADAS = "cd_relacionadas";
    const CD_TEMA_DO_DIA = "cd_temaDoDia";
    const CD_AREA = "cd_area";
    const CD_TIPO_MIDIA = "cd_tipoMidia";
    const CD_DATA_ESTREIA = "cd_datEstreia";
    const CD_HORA_ESTREIA = "cd_horaEstreia";
    const CD_PROGRAMA_PRINCIPAL = "cd_programaPrincipal";
    const CD_PROGRAMAS = "cd_programas";
    const CD_DESTAQUE_HOME_PROGRAMA = "cd_destaquesHomePrograma";
    const CD_DESTAQUE_HOME_TEMATICA = "cd_destaquesHomeTematica";
    const CD_CATEGORIA = "cd_categoria";
    const CD_ORDEM = "cd_ordem";
    const CD_QTD_DESTAQUES = "cd_quantidadeDestaques";
    const CD_HORARIO = "cd_horario";
    const CD_ACERVO = "cd_acervo";
    const CD_PERMITIR_DOWNLOAD = "cd_permitirDownloads";
    const CD_DESATIVADO = "cd_desativado";
    const CD_CONTINUACAO = "cd_continuacoes";
    const CD_DEPUTADOS = "cd_deputados";
    const CD_PROPOSICOES = "cd_proposicoes";
    const CD_LEGISLACOES = "cd_legislacoes";
    const CD_DATA_ATUALIZACAO = "cd_dataAtualizacao";
    const CD_SLUG_HIERARQUICO = 'cd_slugHierarquico';
}
