<?php namespace conteudo\portal\api\mapeamento;

abstract class HomeCampos {
    const CD_AREA_CONTEUDO_ID_HOME_PUBLICADA = "cd_idHomePublicada";
    const CD_AREA_CONTEUDO_HTML_HOME_PUBLICADA = "cd_htmlHomePublicada";
    const CD_AREA_CONTEUDO_JSON_HOME_PUBLICADA = "cd_jsonHomePublicada";
    const CD_AREA_CONTEUDO_TIPO_CONTEUDO = "cd_tipoConteudo";
    const CD_AREA_CONTEUDO_WP_ROLE = "cd_wpRole";
    const CD_HOME_PAGE_DESTAQUE_TOPO_ID = 'cd_destaqueTopoId';
    const CD_HOME_PAGE_DESTAQUE_TOPO_LINK = 'cd_destaqueTopoLink';
    const CD_HOME_PAGE_DESTAQUE_TOPO_TITULO = 'cd_destaqueTopoTitulo';
    const CD_HOME_PAGE_ESTREIA_ID = 'cd_estreiaId';
    const CD_HOME_PAGE_ESTREIA_LINK = 'cd_estreiaLink';
    const CD_HOME_PAGE_ESTREIA_TEMA = 'cd_estreiaTema';
    const CD_HOME_PAGE_ESTREIA_TITULO = 'cd_estreiaTitulo';
    const CD_HOME_PAGE_ESTREIA_RESUMO = 'cd_estreiaResumo';
    const CD_HOME_PAGE_ESTREIA_POSTER = 'cd_estreiaPoster';
    const CD_HOME_PAGE_ESTREIA_VIDEO = 'cd_estreiaVideo';
    const CD_HOME_PAGE_ESTREIA_AUDIO = 'cd_estreiaAudio';
}

?>