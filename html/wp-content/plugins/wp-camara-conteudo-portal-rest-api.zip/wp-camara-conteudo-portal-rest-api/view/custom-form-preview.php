    <form id="custom-preview" target="_blank" action="<?= $this->action_post() ?>" method="post">
        <input type="hidden" name="data" id="data" />
    </form>