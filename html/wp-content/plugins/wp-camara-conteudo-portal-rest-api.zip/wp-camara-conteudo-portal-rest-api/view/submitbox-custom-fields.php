<div class="misc-pub-section curtime misc-pub-curtime">
    <a class="button" id="custom_preview">Visualizar<span class="screen-reader-text"> (abrir em uma nova aba)</span></a>
    <input type="hidden" name="cd_post_type" id="cd_post_type" value="<?= $this->get_tipo_post() ?>"/>
</div>