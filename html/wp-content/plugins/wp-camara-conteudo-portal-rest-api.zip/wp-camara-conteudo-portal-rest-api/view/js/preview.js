jQuery(document).ready(function ($) {
  $('#custom_preview').click(function () {
    const data = {
      action: 'custom_preview',
      ID: getSearchParams('post'),
      post_title: $('#title').val(),
      post_excerpt: $('#excerpt').val(),
      post_content: tinyMCE.activeEditor.getContent()
    };

    $.post(ajaxurl, data, function (response) {
      $("#data").val(response);
      $('#custom-preview').submit();
    });
    function getSearchParams(k) {
      var p = {};
      location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (s, k, v) { p[k] = v })
      return k ? p[k] : p;
    }
  });


});