<?php namespace noticias\domain;
/**
 * Formata resposta padrão para noticia
 * 
 * @link              http://camara.leg.br
 * @package           @package camara-noticias
 * 
 */
class Noticia {

    public function __construct($post) {
        $this->id = $post->ID;
        $this->tipo = $post->post_type;
        $this->titulo = $post->post_title;
        $this->texto = $post->post_content;
        $this->datMateria = strtotime($post->post_date);
        $this->datUltimaAtualizacao = strtotime($post->post_modified);
        $this->resumo = get_post_meta($this->id, 'resumo')[0];
        $this->retranca = get_post_meta($this->id, 'retranca')[0];
        $this->rodape = get_post_meta($this->id, 'rodape')[0];            
    }
}

?>