<?php namespace noticias\domain;

abstract class ActionsAjax
{
    const VALIDATOR_NOTICIAS = "validador_noticia";
    const TEMA_DO_DIA = "temadodia_noticia";
    const RELACIONADAS = "obter_relacionadas_noticia";
    const CONTINUACAO = "obter_continuacao_noticia";
    const DEPUTADOS_REGEX = "deputados_regex";
    const PESQUISA_DEPUTADOS = "pesquisa_deputados_noticia";
    const DEPUTADOS_ASSOCIADOS = "deputados_associados";
    const DUPLICAR_POST = "camara_agencia_duplicate_post";
    const TAGS = "tags_noticia";
    const PROPOSICOES_REGEX = "proposicoes_regex";
    const PESQUISA_PROPOSICOES = "pesquisa_proposicoes_noticia";
    const PROPOSICOES_ASSOCIADAS = "proposicoes_associadas";
    const LEGISLACOES_REGEX = "legislacoes_regex";
    const PESQUISA_LEGISLACOES = "pesquisa_legislacoes_noticia";
    const LEGISLACOES_ASSOCIADAS = "legislacoes_associadas";
    const GLOSSARIO_REGEX = "glossario_regex";
    const PESQUISA_GLOSSARIO = "pesquisa_glossario_noticia";
    const NOVA_TAG = "nova_tag_noticia";
    const ASSOCIAR_MIDIA_PAINEL_DE_NOTICIAS = "associar_midia_painel_de_noticias";
    const NOVO_TEMA_DO_DIA = "novo_tema_do_dia";

    public static function getValores()
    {
        return array(
            self::VALIDATOR_NOTICIAS,
            self::TEMA_DO_DIA,
            self::RELACIONADAS,
            self::CONTINUACAO,
            self::DEPUTADOS_REGEX,
            self::PESQUISA_DEPUTADOS,
            self::DEPUTADOS_ASSOCIADOS,
            self::TAGS,
            self::PROPOSICOES_REGEX,
            self::PESQUISA_PROPOSICOES,
            self::PROPOSICOES_ASSOCIADAS,
            self::DUPLICAR_POST,
            self::LEGISLACOES_REGEX,
            self::PESQUISA_LEGISLACOES,
            self::LEGISLACOES_ASSOCIADAS,
            self::GLOSSARIO_REGEX,
            self::PESQUISA_GLOSSARIO,
            self::NOVA_TAG,
            self::ASSOCIAR_MIDIA_PAINEL_DE_NOTICIAS,
            self::NOVO_TEMA_DO_DIA
        );
    }
}
