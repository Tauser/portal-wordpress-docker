<?php namespace noticias\domain;

require_once(plugin_dir_path(__FILE__) . './tipo-noticia.php');
require_once(plugin_dir_path(__FILE__) . './tipo-midia.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');

use noticias\mapeamento\CamposDB as CamposDB;
use noticias\domain\TipoNoticia as TipoNoticia;
use noticias\domain\TipoMidia as TipoMidia;

class NoticiaAgencia
{
    private $tipo;
    private $visivelHome;
    private $visivelBoletim;
    private $rodape;
    private $noticiaPortalCongresso;
    private $temaPrincipal;
    private $temas;
    private $relacionadas;
    private $temaDoDia;
    private $tipoMidia;
    private $continuacao;
    private $dataAtualizacao;
    private $HoraAtualizacao;
    private $tags;
    private $deputados;
    private $proposicoes;
    private $legislacoes;
    private $retranca;

   
    public function __construct($tipo, 
                                $visivelHome, 
                                $visivelBoletim, 
                                $rodape, 
                                $noticiaPortalCongresso, 
                                $temaPrincipal, 
                                $temas, 
                                $relacionadas, 
                                $temaDoDia, 
                                $tipoMidia, 
                                $continuacao, 
                                $dataAtualizacao, 
                                $HoraAtualizacao, 
                                $tags, 
                                $resumo, 
                                $deputados, 
                                $proposicoes, 
                                $legislacoes, 
                                $retranca) {

        $this->tipo = $tipo ==null ?  TipoNoticia::getKey(TipoNoticia::CONSOLIDADA) : $tipo;
        $this->visivelHome = $visivelHome !=null ? true : false;
        $this->visivelBoletim = $visivelBoletim !=null ? true : false;
        $this->rodape = sanitize_text_field($rodape);
        $this->noticiaPortalCongresso = $noticiaPortalCongresso !=null ? true : false;
        $this->temaPrincipal = $temaPrincipal;
        $this->temas = is_array($temas) ? $temas : array($temas);
        $this->temaDoDia = $temaDoDia;
        $this->tipoMidia = $tipoMidia == null ? TipoMidia::getKey(TipoMidia::TEXTO) : $tipoMidia;
        if (!is_array($relacionadas) && !empty($relacionadas) && !is_null($relacionadas)) {
            $this->relacionadas = explode(',', $relacionadas);
        } else {
            $this->relacionadas = $relacionadas;
        }
        if (!is_array($deputados) && !empty($deputados) && !is_null($deputados)) {
            $this->deputados = explode(',', $deputados);
        } else {
            $this->deputados = $deputados;
        }
        if (!is_array($proposicoes) && !empty($proposicoes) && !is_null($proposicoes)) {
            $this->proposicoes = explode(',', $proposicoes);
        } else {
            $this->proposicoes = $proposicoes;
        }
        if (!is_array($legislacoes) && !empty($legislacoes) && !is_null($legislacoes)) {
            $this->legislacoes = explode(',', $legislacoes);
        } else {
            $this->legislacoes = $legislacoes;
        }
        if (!is_array($continuacao) && !empty($continuacao) && !is_null($continuacao)) {
            $this->continuacao = explode(',', $continuacao);
        } else {
            $this->continuacao = $continuacao;
        }
        $this->dataAtualizacao = $dataAtualizacao;
        $this->HoraAtualizacao = $HoraAtualizacao;
        $this->tags = is_array($tags) ? $tags : array($tags);
        $this->resumo = $resumo;
        $this->retranca = $retranca;
    }

    public function getRetranca() {
        return $this->retranca;
    }

    public function getLegislacoes() {
        return $this->legislacoes;
    }

    public function getProposicoes() {
        return $this->proposicoes;
    }

    public function getDeputados() {
        return $this->deputados;
    }

    public function getResumo() {
        return $this->resumo;
    }

    public function getTipoMidia() {
        return $this->tipoMidia;
    }

    public function getTiposMidias() {
        return TipoMidia::getValores();
    }

    public function getTemaDoDia() {
        return $this->temaDoDia;
    }

    public function getTemaPrincipal() {
        return $this->temaPrincipal;
    }

    public function getTemas() {
        return $this->temas;
    }

    public function getRelacionadas() {
        return $this->relacionadas;
    }

    public function getContinuacao() {
        return $this->continuacao;
    }

    public function getTipos() {
        return TipoNoticia::getValores();
    }

    public static function isRequired($post_data, $values) {
        $fields = '';
        if ($post_data['post_status'] != 'trash') {
            if (empty($values[CamposDB::CD_NOTICIA_TIPO])) {
                $fields = $fields .  "Tipo de Notícia, ";
            }
            if (empty($values[CamposDB::CD_NOTICIA_TIPO_MIDIA])) {
                $fields = $fields .  "Tipo de Midia, ";
            }
            if (empty($values['post_title'])) {
                $fields = $fields . "Título, ";
            }
            if (empty($values['post_content'])) {
                $fields = $fields . "Conteúdo, ";
            }
            if (empty($values[CamposDB::CD_NOTICIA_TEMA_PRINCIPAL])) {
                $fields = $fields .  "Tema Principal, ";
            }
        }
        return substr(trim($fields), 0, -1);
    }

    public static function validarTotalCaracteres($post_data, $values) {
        $fields = '';
        if ($post_data['post_status'] != 'trash') {
            if (!empty($values[CamposDB::CD_NOTICIA_RETRANCA]) && strlen($values[CamposDB::CD_NOTICIA_RETRANCA]) > 128) {
                $fields = $fields .  "Digite somente 128 caracteres para Retranca, ";
            }
        }
        return substr(trim($fields), 0, -1);
    }

    public function getNoticiaPortalCongresso() {
        return $this->noticiaPortalCongresso == 1 ? true : false;
    }

    public function getVisivelBoletim() {
        return $this->visivelBoletim == 1 ? true : false;
    }

    public function getVisivelBoletimBoolean() {
        return $this->visivelBoletim;
    }

    public function getVisivelHome() {
        return $this->visivelHome == 1 ? true : false;
    }

    public function getVisivelHomeBoolean() {
        return $this->visivelHome;
    }

    public function getNoticiaPortalCongressoBoolean() {
        return $this->noticiaPortalCongresso;
    }

    public function getTipo() {
        return $this->tipo;
    }

    public function getRodape() {
        return sanitize_text_field($this->rodape);
    }

    public function getDataAtualizacao() {
        return $this->dataAtualizacao;
    }

    public function getHoraAtualizacao() {
        return $this->HoraAtualizacao;
    }

    public function getTags() {
        return $this->tags;
    }
}
