<?php namespace noticias\domain;

class Glossario
{

    // REGEX - [[g 'Palavra']]
    const REGEX = '(?<=\[{2})(g\s)(.*?)(?=\]{2})';

    public function __construct($id, $titulo, $descricao, $existe, $confirmado) {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->descricao = $descricao;
        $this->existe = $existe;
        $this->confirmado = $confirmado;
    }

    public function getId() {
        return $this->id;
    }

    public function getDescricao() {
        return $this->descricao;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    public function getExiste() {
        return $this->existe;
    }

    public function getConfirmado() {
        return $this->confirmado;
    }
}

?>