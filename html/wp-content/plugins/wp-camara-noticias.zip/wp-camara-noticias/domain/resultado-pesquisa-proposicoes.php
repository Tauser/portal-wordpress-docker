<?php namespace noticias\domain;

class ResultadoPesquisaProposicoes
{

    public function __construct($regex, $proposicao, $opcoes) {
        $this->proposicao = $proposicao;
        $this->opcoes = $opcoes;
        $this->regex = $regex;
    }

    public function getProposicao() {
        return $this->proposicao;
    }

    public function getOpcoes() {
        return $this->opcoes;
    }

    public function getRegex() {
        return $this->regex;
    }
}

?>