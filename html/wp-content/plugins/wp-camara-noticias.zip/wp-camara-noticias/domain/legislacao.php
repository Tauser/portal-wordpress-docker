<?php namespace noticias\domain;

class Legislacao
{

    // REGEX - palavra Lei + numero + ano
    const REGEX = '(Lei|LEI|lei)[\s|-]((\d+)(,|.)(\d+)|(\d+))(\/)(\d+)';

    public function __construct($id, $numero, $ano, $link, $existe, $confirmado) {
        $this->id = $id;
        $this->numero = $numero;
        $this->link = $link;
        $this->ano = $ano;
        $this->existe = $existe;
        $this->confirmado = $confirmado;
    }

    public function getId() {
        return $this->id;
    }

    public function getLink() {
        return $this->link;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getAno() {
        return $this->ano;
    }

    public function getExiste() {
        return $this->existe;
    }

    public function getConfirmado() {
        return $this->confirmado;
    }

}

?>