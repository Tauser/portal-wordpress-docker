<?php namespace noticias\domain;

class ResultadoPesquisaLegislacoes
{

    public function __construct($regex, $legislacao, $opcoes) {
        $this->legislacao = $legislacao;
        $this->opcoes = $opcoes;
        $this->regex = $regex;
    }

    public function getLegislacao() {
        return $this->legislacao;
    }

    public function getOpcoes() {
        return $this->opcoes;
    }

    public function getRegex() {
        return $this->regex;
    }
}

?>