<?php namespace noticias\domain;

class Deputado
{
    // REGEX - [[Nome do Deputado]]
    const REGEX = '(?<=\[{2})[^g ](.*?)(?=\]{2})';

    public function __construct($id, $nome, $siglaPartido, $siglaUf, $urlFoto, $existe, $confirmado) {
        $this->id = $id;
        $this->nome = $nome;
        $this->partido = $siglaPartido . '-' . $siglaUf;
        $this->link = 'https://www.camara.leg.br/deputados/' .  $id;
        $this->urlFoto = $urlFoto;
        $this->existe = $existe;
        $this->confirmado = $confirmado;
    }

    public function getConfirmado() {
        return $this->confirmado;
    }

    public function getId() {
        return $this->id;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getPartido() {
        return $this->partido;
    }

    public function getUrlFoto() {
        return $this->partido;
    }

    public function getLink() {
        return $this->link;
    }

    public function getExiste() {
        return $this->existe;
    }

    public function getOpcoes() {
        return $this->opcoes;
    }

}

?>