<?php namespace noticias\domain;

abstract class TipoNoticia
{
    const AGENDA = "Agenda";
    const CONSOLIDADA = "Consolidada";
    const PAUTA = "Pauta";
    const PROJETO = "Projeto";
    const TEMPO_REAL = "Tempo Real";

    public static function getKey($value) {
        $class = new \ReflectionClass(__CLASS__);
        $constants = array_flip($class->getConstants());
        return $constants[$value];
    }

    public static function getValores() {
        return array('AGENDA' => self::AGENDA, 
                    'CONSOLIDADA' => self::CONSOLIDADA, 
                    'PAUTA' => self::PAUTA, 
                    'PROJETO' => self::PROJETO, 
                    'TEMPO_REAL' => self::TEMPO_REAL);
    }
}

?>