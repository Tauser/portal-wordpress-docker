<?php namespace noticias\domain;

class ResultadoPesquisaDeputado
{

    public function __construct($regex, $deputado, $opcoes) {
        $this->deputado = $deputado;
        $this->opcoes = $opcoes;
        $this->regex = $regex;
    }

    public function getDeputado() {
        return $this->deputado;
    }

    public function getOpcoes() {
        return $this->opcoes;
    }

    public function getRegex() {
        return $this->regex;
    }
}

?>