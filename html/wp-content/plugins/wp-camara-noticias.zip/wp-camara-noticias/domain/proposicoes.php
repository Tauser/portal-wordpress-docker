<?php namespace noticias\domain;

class Proposicoes
{

    // REGEX utilizando as siglas + numero + ano. As siglas são inseridas de forma dinamica no inicio da regex
    const PARTIAL_REGEX = '[\s|-](\d+)\/(\d+)';
    const ADICIONAIS_REGEX_SIGLA = 'MP';
    const MAP_SIGLAS_EXCLUIDAS = array(
        "REQ"
    );
    const MAP_SIGLAS = array(
        "MP" => "MPV"
    );

    public function __construct($id, $sigla, $numero, $ano, $existe, $confirmado) {
        $this->id = $id;
        $keySigla = array_search($sigla, self::MAP_SIGLAS);
        $this->sigla = $keySigla != null ?  $keySigla : $sigla;
        $this->numero = $numero;
        $this->link = 'https://www.camara.leg.br/proposicoesWeb/fichadetramitacao?idProposicao=' .  $id;
        $this->ano = $ano;
        $this->existe = $existe;
        $this->confirmado = $confirmado;
    }

    public function getId() {
        return $this->id;
    }

    public function getLink() {
        return $this->link;
    }

    public function getSigla() {
        return $this->sigla;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getAno() {
        return $this->ano;
    }

    public function getExiste() {
        return $this->existe;
    }

    public function getConfirmado() {
        return $this->confirmado;
    }

}

?>