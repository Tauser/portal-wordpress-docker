<?php namespace noticias\domain;

abstract class TipoMidia
{
    
    const TEXTO = "Texto";
    const VIDEO = "Vídeo";
    const AUDIO = "Áudio";
    const INFOGRAFICO = "Infográfico";

    public static function getKey($value) {
        $class = new \ReflectionClass(__CLASS__);
        $constants = array_flip($class->getConstants());
        return $constants[$value];
    }

    public static function getValores() {
        return array('TEXTO' => self::TEXTO, 
                    'VIDEO' => self::VIDEO, 
                    'AUDIO' => self::AUDIO, 
                    'INFOGRAFICO' => self::INFOGRAFICO);
    }
}

?>