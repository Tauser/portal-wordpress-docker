<?php namespace noticias\domain;

class ResultadoPesquisaGlossario
{

    public function __construct($regex, $glossario, $opcoes) {
        $this->glossario = $glossario;
        $this->opcoes = $opcoes;
        $this->regex = $regex;
    }

    public function getGlossario() {
        return $this->glossario;
    }

    public function getOpcoes() {
        return $this->opcoes;
    }

    public function getRegex() {
        return $this->regex;
    }
}

?>