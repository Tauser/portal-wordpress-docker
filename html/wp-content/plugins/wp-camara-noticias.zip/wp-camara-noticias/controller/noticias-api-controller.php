<?php namespace noticias\controller;

require_once(plugin_dir_path(__FILE__) . '../config/config-plugin.php');

use noticias\config\ConfigPlugin as ConfigPlugin;

class NoticiasControllerRestApi {

    private $service;

    public function __construct($service)  {
        $this->service = $service;
        $this->initHooks();
    }

    public function initHooks () {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        $this->ultimas_noticias();
        $this->buscar_noticia_por_id();
    }

    /**
    * /wp-json/agencia/ultimas-noticias - listar as 30 últimas noticias
    */
    private function ultimas_noticias() {
        $this->register_router_get('/ultimas-noticias', function ($request) {
            $params = array();
            $tema = null;
            
            if (isset($_GET['offset']) && is_numeric($_GET['offset'])) {
                $params['posts_per_page'] = $_GET['offset'];
            } else {
                $params['posts_per_page'] = 30;
            }
                
            if (isset($_GET['keyword']) && !empty($_GET['keyword']))
                $params['s'] = $_GET['keyword'];

            if (isset($_GET['cat']) && !empty($_GET['cat']))
                $tema = $_GET['cat'];

            return $this->service->obter_ultimas_noticias($params, $tema);
        });
    }

    /**
    * /wp-json/agencia/noticia/1925 - buscar conteúdo do portal por ID
    */
    private function buscar_noticia_por_id() {
        $this->register_router_get('noticia/(?P<id>\S+)', function ($request) {
            $request_id = $request['id'];
                $array_id = explode('-', $request_id);
                $id = $array_id[0];
                return $this->service->obter_objeto_por_id($id);
        });
    }

    private function register_router_get($url, $callback) {
        register_rest_route(ConfigPlugin::POST_TYPE_NAME, $url, array(
            'methods' =>  \WP_REST_Server::READABLE,
            'callback' => $callback
        ));
    }
}

?>