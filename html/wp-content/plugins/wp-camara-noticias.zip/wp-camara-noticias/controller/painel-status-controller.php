<?php namespace noticias\controller;

require_once(plugin_dir_path(__FILE__) . '../config/config-plugin.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');

use noticias\config\ConfigPlugin as ConfigPlugin;
use noticias\domain\ActionsAjax as ActionsAjax;

class PainelStatusController {

    private $noticiasService;
    private $configPlugin;

    public function __construct($configPlugin, $noticiasService) {
        $this->noticiasService = $noticiasService;
        $this->configPlugin = $configPlugin;
        $this->register_painel_status();
        $this->add_scripts();
    }

    public function register_painel_status() {
        add_action('admin_menu', array($this, 'add_submenu_page_status'));
    }

    public function add_scripts() {
        $this->configPlugin->add_ajax_action(ActionsAjax::ASSOCIAR_MIDIA_PAINEL_DE_NOTICIAS, array($this, 'associar_midia'));
    }

    public function associar_midia () {
        $result = array('status' => false, 'message' => 'Em processamento');
        $id_post = $_POST['postId'];
        $id_midia = $_POST['midiaId'];
        $midia_type = $_POST['midia_type'];
        $process = $this->noticiasService->associar_midia($id_post, $id_midia, $midia_type);
        
        if (!is_null($process) && isset($process)) {
            $result['status'] = true;
            $result['message'] = 'Operação realizada com sucesso !';
        } else {
            $result['message'] = 'Não foi possível realizar a operação...';
        }
        echo json_encode($result);
        die;
    }

    public function add_submenu_page_status () {
        add_submenu_page( 
            "edit.php?post_type=".ConfigPlugin::POST_TYPE_NAME, 
            ConfigPlugin::PAINEL_STATUS_DESCRIPTION, 
            ConfigPlugin::PAINEL_STATUS_NAME,
            'manage_options', 
            'painel-status-materia', 
            array($this,'render_painel_status_materia')
        );
    }

    public function render_painel_status_materia () {
        include(plugin_dir_path(__FILE__) . '../view/painel-status-materia.php');
    }
}

?>