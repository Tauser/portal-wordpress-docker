<?php namespace noticias\controller;

require_once(plugin_dir_path(__FILE__) . '../config/config-duplicate.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
require_once(plugin_dir_path(__FILE__) . '../util/validator-util.php');

use noticias\config\ConfigDuplicatePost as ConfigDuplicatePost;
use noticias\domain\ActionsAjax as ActionsAjax;
use noticias\mapeamento\CamposDB as CamposDB;
use noticias\util\ValidationUtil as ValidationUtil;

class DuplicatePostController
{
    private $service;
    private $configPlugin;
    private $config;
    private $validationUtil;
    
    public function __construct($configPlugin, $service)
    {   
        $this->configPlugin = $configPlugin;
        if ($this->configPlugin->config()) {
            $this->validationUtil = new ValidationUtil();
            $this->config = new ConfigDuplicatePost($configPlugin::POST_TYPE_NAME);
            $this->service = $service;
            $this->add_scripts();
        }
    }

    private function add_scripts() {
        $this->configPlugin->add_ajax_action(ActionsAjax::DUPLICAR_POST, array($this, 'duplicar_post'));
    }

    /** Função utilizada para duplicar post */
    public function duplicar_post ($args=array(), $do_action=true) {

        check_ajax_referer( $this->config::JS_NONCE_SECURITY_NAME, 'security' );

        $original_id  = $_POST['original_id'];
        $global_settings = $this->config->get_post_duplicate_settings();

        if (!isset($original_id)) {
            die();
        }

        $duplicate_id = $this->service->duplicar_post($original_id, $global_settings);

        echo $duplicate_id;

        die;
    }
}
?>