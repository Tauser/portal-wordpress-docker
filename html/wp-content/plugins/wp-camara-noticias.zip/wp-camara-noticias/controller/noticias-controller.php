<?php namespace noticias\controller;

require_once(plugin_dir_path(__FILE__) . '../domain/noticia-agencia.php');
require_once(plugin_dir_path(__FILE__) . '../util/message-util.php');
require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');
require_once(plugin_dir_path(__FILE__) . '../util/validator-util.php');

use noticias\util\MessageUtil as MessageUtil;
use noticias\mapeamento\CamposDB as CamposDB;
use noticias\domain\NoticiaAgencia as NoticiaAgencia;
use noticias\domain\ActionsAjax as ActionsAjax;
use noticias\config\ConfigPlugin as ConfigPlugin;
use noticias\util\ValidationUtil as ValidationUtil;

class NoticiasController
{

    private $messageUtil;
    private $noticia;
    private $configPlugin;
    private $configForm;
    private $nomesCamposDB;
    private $validationUtil;
    private $noticiasService;
    private $deputadoService;
    private $proposicoesService;
    private $legislacoesService;
    private $glossarioService;

    public function __construct($configPlugin, $noticiasService, $deputadoService, $proposicoesService, $legislacoesService, $glossarioService)
    {
        $this->configPlugin = $configPlugin;
        if ($this->configPlugin->config()) {
            $this->nomesCamposDB = CamposDB::getValores();
            $this->configForm = $configPlugin->configForm();
            $this->messageUtil = new MessageUtil($noticiasService);
            $this->validationUtil = new ValidationUtil();
            $this->noticia = null;
            $this->noticiasService = $noticiasService;
            $this->deputadoService = $deputadoService;
            $this->proposicoesService = $proposicoesService;
            $this->legislacoesService = $legislacoesService;
            $this->glossarioService = $glossarioService;
            //$this->registra_status();
            $this->init_form();
            $this->add_scripts();
        }
    }

    /**
     * Metodo para validacao dos campos
     * Tem que ser public porque e acessado por um hook
     */
    public function pre_post_update($post_id, $post_data)
    {

        if( defined('DOING_AJAX') && DOING_AJAX && $_POST['action'] == "inline-save") 
            return;

        if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || $_GET['action'] == 'trash' || $_GET['action'] == 'untrash') {
            return;
        }
        $obrigatorios = NoticiaAgencia::isRequired($post_data, $_POST);
        if ($obrigatorios != '') {
            $this->messageUtil->errorFieldsRequired(false, $obrigatorios);
            return;
        }
        $totalCaracteres = NoticiaAgencia::validarTotalCaracteres($post_data, $_POST);
        if ($totalCaracteres != '') {
            $this->messageUtil->errorFields(false, $totalCaracteres);
        }
        
    }

    /**
     * Metodo para salvar os customs fields
     * Tem que ser public porque e acessado por um hook
     */
    public function save_noticias($post_ID)
    {
        $this->noticiasService->save(
            $post_ID,
            new NoticiaAgencia(
                $_POST[CamposDB::CD_NOTICIA_TIPO],
                $_POST[CamposDB::CD_NOTICIA_VISIVEL_HOME],
                $_POST[CamposDB::CD_NOTICIA_VISIVEL_BOLETIM],
                $_POST[CamposDB::CD_NOTICIA_RODAPE],
                $_POST[CamposDB::CD_NOTICIA_PORTAL_CONGRESSO],
                $_POST[CamposDB::CD_NOTICIA_TEMA_PRINCIPAL],
                $_POST[CamposDB::CD_NOTICIA_TEMAS],
                $_POST[CamposDB::CD_NOTICIA_RELACIONADA],
                $_POST[CamposDB::CD_NOTICIA_TEMA_DO_DIA],
                $_POST[CamposDB::CD_NOTICIA_TIPO_MIDIA],
                $_POST[CamposDB::CD_NOTICIA_CONTINUACAO],
                $_POST[CamposDB::CD_NOTICIA_DATA_ATUALIZACAO],
                $_POST[CamposDB::CD_NOTICIA_HORA_ATUALIZACAO],
                $_POST[CamposDB::CD_NOTICIA_TAGS],
                null,
                $_POST[CamposDB::CD_DEPUTADOS],
                $_POST[CamposDB::CD_PROPOSICOES],
                $_POST[CamposDB::CD_LEGISLACOES],
                $_POST[CamposDB::CD_NOTICIA_RETRANCA]
            )
        );
    }

    /**
     * Metodo para registar os customs fields
     * Tem que ser public porque e acessado por um hook
     */
    public function form_top_custom_field($post)
    {
        $this->noticia = new NoticiaAgencia(
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_TIPO),
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_VISIVEL_HOME),
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_VISIVEL_BOLETIM),
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_RODAPE),
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_PORTAL_CONGRESSO),
            $this->noticiasService->get_tema_principal($post->ID, CamposDB::CD_NOTICIA_TEMA_PRINCIPAL, 'tema'),
            $this->noticiasService->get_temas_by_id_post($post->ID),
            $this->noticiasService->get_relacionadas($post->ID, CamposDB::CD_NOTICIA_RELACIONADA),
            $this->noticiasService->get_tema_do_dia_by_id($post->ID, CamposDB::CD_NOTICIA_TEMA_DO_DIA),
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_TIPO_MIDIA),
            $this->noticiasService->get_continuacao($post->ID, CamposDB::CD_NOTICIA_CONTINUACAO),
            $this->validationUtil->extrairData($this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_DATA_ATUALIZACAO)),
            $this->validationUtil->extrairHora($this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_DATA_ATUALIZACAO)),
            $this->noticiasService->get_tags_by_id_post($post->ID),
            $post->post_excerpt,
            $this->noticiasService->get_deputados($post->ID, CamposDB::CD_DEPUTADOS),
            $this->noticiasService->get_proposicoes($post->ID, CamposDB::CD_PROPOSICOES),
            $this->noticiasService->get_legislacoes($post->ID, CamposDB::CD_LEGISLACOES),
            $this->noticiasService->get_post_meta($post->ID, CamposDB::CD_NOTICIA_RETRANCA)
        );
        include(plugin_dir_path(__FILE__) . '../view/top-custom-fields.php');
    }

    public function bottom_custom_fields($post)
    {
        include(plugin_dir_path(__FILE__) . '../view/bottom-custom-fields.php');
    }

    public function form_after_title_custom_field($post)
    {  
        include(plugin_dir_path(__FILE__) . '../view/form-after-title-custom-fields.php');
    }

    public function submitbox_custom_fields($post)
    {
        include(plugin_dir_path(__FILE__) . '../view/submitbox-custom-fields.php');
    }

    public function getTemas()
    {
        return $this->noticiasService->get_temas();
    }

    public function getTags()
    {
        return $this->noticiasService->get_tags();
    }

    private function init_form()
    {   
        $this->configForm->config_edit_form_top(array($this, 'form_top_custom_field'));
        $this->configForm->config_edit_form_after_title(array($this, 'form_after_title_custom_field'));
        $this->configForm->config_edit_form_after_editor(array($this, 'bottom_custom_fields'));
        $this->configForm->config_post_submitbox_misc_actions(array($this, 'submitbox_custom_fields'));
        $this->configForm->config_save_post(array($this, 'save_noticias'), 10, 3);
        $this->configForm->config_pre_post_update(array($this, 'pre_post_update'), 10, 2);
    }

    private function add_scripts()
    {
        $this->configPlugin->add_ajax_action(ActionsAjax::VALIDATOR_NOTICIAS, array($this, 'validador'));
        $this->configPlugin->add_ajax_action(ActionsAjax::TEMA_DO_DIA, array($this, 'pesquisar_tema_do_dia'));
        $this->configPlugin->add_ajax_action(ActionsAjax::RELACIONADAS, array($this, 'obter_relacionadas'));
        $this->configPlugin->add_ajax_action(ActionsAjax::CONTINUACAO, array($this, 'obter_continuacao'));
        $this->configPlugin->add_ajax_action(ActionsAjax::DEPUTADOS_REGEX, array($this, 'retornar_regex_deputados'));
        $this->configPlugin->add_ajax_action(ActionsAjax::PESQUISA_DEPUTADOS, array($this, 'pesquisar_deputados'));
        $this->configPlugin->add_ajax_action(ActionsAjax::DEPUTADOS_ASSOCIADOS, array($this, 'recuperar_deputados_associados'));
        $this->configPlugin->add_ajax_action(ActionsAjax::TAGS, array($this, 'pesquisar_tags'));
        $this->configPlugin->add_ajax_action(ActionsAjax::PROPOSICOES_REGEX, array($this, 'retornar_regex_proposicoes'));
        $this->configPlugin->add_ajax_action(ActionsAjax::PESQUISA_PROPOSICOES, array($this, 'pesquisar_proposicoes'));
        $this->configPlugin->add_ajax_action(ActionsAjax::PROPOSICOES_ASSOCIADAS, array($this, 'recuperar_proposicoes_associadas'));
        $this->configPlugin->add_ajax_action(ActionsAjax::LEGISLACOES_REGEX, array($this, 'retornar_regex_legislacoes'));
        $this->configPlugin->add_ajax_action(ActionsAjax::PESQUISA_LEGISLACOES, array($this, 'pesquisar_legislacoes'));
        $this->configPlugin->add_ajax_action(ActionsAjax::LEGISLACOES_ASSOCIADAS, array($this, 'recuperar_legislacoes_associadas'));
        $this->configPlugin->add_ajax_action(ActionsAjax::NOVA_TAG, array($this, 'save_nova_tag'));
        $this->configPlugin->add_ajax_action(ActionsAjax::GLOSSARIO_REGEX, array($this, 'retornar_regex_glossario'));
        $this->configPlugin->add_ajax_action(ActionsAjax::PESQUISA_GLOSSARIO, array($this, 'pesquisar_glossarios'));
        $this->configPlugin->add_ajax_action(ActionsAjax::NOVO_TEMA_DO_DIA, array($this, 'incluir_novo_tema_do_dia'));
       
    }

    public function pesquisar_glossarios() {
        $resultado = $this->glossarioService->pesquisar($_POST['glossarios']);
        echo json_encode($resultado);
        die;
    }

    public function retornar_regex_glossario () {
        $regex = $this->glossarioService->retornar_regex_glossario();
        echo $regex;
        die;
    }

    public function save_nova_tag()
    {
        $terms = $this->noticiasService->save_nova_tag(
            $_POST['cd_novaTag']
        );
        echo json_encode($terms);
        die;
    }

    public function incluir_novo_tema_do_dia()
    {
        $terms = $this->noticiasService->incluir_novo_tema_do_dia(
            $_POST['cd_novo_tema_do_dia']
        );
        echo json_encode($terms);
        die;
    }
    
    public function recuperar_legislacoes_associadas () {
        $legislacoes = $this->noticiasService->get_legislacoes($_POST['post_id'], CamposDB::CD_LEGISLACOES);
        echo json_encode($legislacoes);
        die;
    }

    public function pesquisar_legislacoes() {
        $resultado = $this->legislacoesService->pesquisar_legislacoes($_POST['legislacoes']);
        echo json_encode($resultado);
        die;
    }

    public function retornar_regex_legislacoes () {
        $regex = $this->legislacoesService->retornar_regex_legislacoes();
        echo $regex;
        die;
    }

    public function recuperar_proposicoes_associadas () {
        $proposicoes = $this->noticiasService->get_proposicoes($_POST['post_id'], CamposDB::CD_PROPOSICOES);
        echo json_encode($proposicoes);
        die;
    }

    public function pesquisar_proposicoes() {
        $resultado = $this->proposicoesService->pesquisar_proposicoes($_POST['proposicoes']);
        echo json_encode($resultado);
        die;
    }

    public function retornar_regex_proposicoes () {
        $regex = $this->proposicoesService->retornar_regex_proposicoes();
        echo $regex;
        die;
    }

    public function retornar_regex_deputados () {
        $regex = $this->deputadoService->retornar_regex_deputados();
        echo $regex;
        die;
    }

    public function recuperar_deputados_associados () {
        $deputados = $this->noticiasService->get_deputados($_POST['post_id'], CamposDB::CD_DEPUTADOS);
        echo json_encode($deputados);
        die;
    }

    public function obter_relacionadas () {
        $posts = $this->noticiasService->get_relacionadas($_POST['post_id'], CamposDB::CD_NOTICIA_RELACIONADA);
        echo json_encode($posts);
        die;
    }

    public function obter_continuacao () {
        $posts = $this->noticiasService->get_continuacao($_POST['post_id'], CamposDB::CD_NOTICIA_CONTINUACAO);
        echo json_encode($posts);
        die;
    }

    public function pesquisar_deputados() {
        $resultado = $this->deputadoService->pesquisar_deputados($_POST['deputados']);
        echo json_encode($resultado);
        die;
    }

    public function pesquisar_tema_do_dia()
    {
        $terms = $this->noticiasService->get_taxonomy('tema_do_dia', $_GET['q']);
        echo json_encode($terms);
        die;

    }

    public function pesquisar_noticias_relacionadas()
    {
        $posts = $this->noticiasService->get_posts($_GET['q']);
        echo json_encode($posts);
        die;
    }

    public function pesquisar_tags()
    {
        $terms = $this->noticiasService->pesquisar_tags($_GET['q']);
        echo json_encode($terms);
        die;

    }

    public function validador()
    {
        $fields = NoticiaAgencia::isRequired($_POST, $_POST);
        if ($fields != '') {
            $this->messageUtil->errorFieldsRequired(true, $fields);
        }
    }

    public function getNomesCamposDB() {
        return $this->nomesCamposDB;
    }
}
?>