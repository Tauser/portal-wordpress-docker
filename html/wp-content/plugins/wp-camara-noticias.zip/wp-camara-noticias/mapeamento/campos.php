<?php namespace noticias\mapeamento;

abstract class CamposDB
{
    const CD_NOTICIA_TIPO = "cd_tipo";
    const CD_NOTICIA_VISIVEL_HOME = "cd_visivelHome";
    const CD_NOTICIA_VISIVEL_BOLETIM = "cd_visivelBoletim";
    const CD_NOTICIA_RODAPE = "cd_rodape";
    const CD_NOTICIA_PORTAL_CONGRESSO = "cd_portalDoCongresso";
    const CD_NOTICIA_TEMA_PRINCIPAL = "cd_temaPrincipal";
    const CD_NOTICIA_TEMAS = "cd_temas";
    const CD_NOTICIA_RELACIONADA = "cd_relacionadas";
    const CD_NOTICIA_TEMA_DO_DIA = "cd_temaDoDia";
    const CD_NOTICIA_AREA = "cd_area";
    const CD_NOTICIA_TIPO_MIDIA = "cd_tipoMidia";
    const CD_NOTICIA_DATA_ATUALIZACAO = "cd_dataAtualizacao";
    const CD_NOTICIA_HORA_ATUALIZACAO = "cd_horaAtualizacao";
    const CD_NOTICIA_TAGS = "cd_tags";
    const CD_NOTICIA_CONTINUACAO = "cd_continuacoes";
    const CD_DEPUTADOS = "cd_deputados";
    const CD_PROPOSICOES = "cd_proposicoes";
    const CD_LEGISLACOES = "cd_legislacoes";
    const CD_NOVA_TAG = "cd_novaTag";
    const CD_POST_IMAGEM = "cd_postImagem";
    const CD_POST_VIDEO = "cd_postVideo";
    const CD_POST_AUDIO = "cd_postAudio";
    const CD_POST_ARQUIVO = "cd_postArquivo";
    const CD_NOTICIA_RETRANCA = "cd_retranca";
    
    public static function getValores() {
        return array('CD_NOTICIA_TIPO' => self::CD_NOTICIA_TIPO, 
                    'CD_NOTICIA_VISIVEL_HOME' => self::CD_NOTICIA_VISIVEL_HOME, 
                    'CD_NOTICIA_VISIVEL_BOLETIM' => self::CD_NOTICIA_VISIVEL_BOLETIM, 
                    'CD_NOTICIA_RODAPE' => self::CD_NOTICIA_RODAPE, 
                    'CD_NOTICIA_PORTAL_CONGRESSO' => self::CD_NOTICIA_PORTAL_CONGRESSO, 
                    'CD_NOTICIA_TEMA_PRINCIPAL' => self::CD_NOTICIA_TEMA_PRINCIPAL,
                    'CD_NOTICIA_TEMAS' => self::CD_NOTICIA_TEMAS,
                    'CD_NOTICIA_RELACIONADA' => self::CD_NOTICIA_RELACIONADA,
                    'CD_NOTICIA_TEMA_DO_DIA' => self::CD_NOTICIA_TEMA_DO_DIA, 
                    'CD_NOTICIA_AREA' => self::CD_NOTICIA_AREA,
                    'CD_NOTICIA_TIPO_MIDIA' => self::CD_NOTICIA_TIPO_MIDIA,
                    'CD_NOTICIA_CONTINUACAO' => self::CD_NOTICIA_CONTINUACAO,
                    'CD_DEPUTADOS' => self::CD_DEPUTADOS,
                    'CD_NOTICIA_DATA_ATUALIZACAO' => self::CD_NOTICIA_DATA_ATUALIZACAO,
                    'CD_NOTICIA_HORA_ATUALIZACAO' => self::CD_NOTICIA_HORA_ATUALIZACAO,
                    'CD_NOTICIA_TAGS' => self::CD_NOTICIA_TAGS,
                    'CD_PROPOSICOES' => self::CD_PROPOSICOES,
                    'CD_LEGISLACOES' => self::CD_LEGISLACOES,
                    'CD_NOVA_TAG' => self::CD_NOVA_TAG,
                    'CD_POST_IMAGEM' => self::CD_POST_IMAGEM,
                    'CD_POST_VIDEO' => self::CD_POST_VIDEO,
                    'CD_POST_AUDIO' => self::CD_POST_AUDIO,
                    'CD_POST_ARQUIVO' => self::CD_POST_ARQUIVO,
                    'CD_NOTICIA_RETRANCA' => self::CD_NOTICIA_RETRANCA
                );
    }
    
}

?>