# PLUGIN DO WORDPRESS - CÂMARA NOTÍCIAS

## CAMPOS CUSTOMIZADOS SALVOS NA TABELA POST META

```
post_type = noticia

cd_noticia_rodape [texto]
cd_noticia_tipo	[caixa de seleção (1 escolha)]
cd_noticia_relacionada [caixa de seleção (n escolhas, 1 registro meta para o ID de cada POST)]
cd_noticia_portalDoCongresso [boolean]
cd_noticia_visivelHome [boolean]
cd_noticia_visivelBoletim [boolean]
cd_noticia_temas [caixa de seleção (n escolhas, 1 registro meta para o ID de cada Taxonomia 'Tema')]
cd_noticia_temaPrincipal [caixa de seleção (1 escolha)]
cd_noticia_temaDoDia [caixa de seleção (n escolhas, 1 registro meta para o ID de cada Taxonomia 'Tema do dia')]
cd_agencia_continuacoes [caixa de seleção para outras notícias de referência]
cd_dataAtualizacaoNoticia [Data editável de possíveis atualizações da notícia, possui um comportamento diferente da post_modified do wordpress]

```

![alt text](ARQUITETURA -  PLUGIN.PNG.png)