<?php

/**
 * Plugin Name: Câmara do Deputados | Notícias
 * Plugin URI:  https://git.camara.gov.br/semid/wp-camara-noticias
 * Description: Plugin para registar posts de notícias utilizando campos customizados
 * Version: 1.0.6
 * Author: Câmara dos Deputados
 * Author URI: https://camara.leg.br/
 * License: GPL2+
 * @package camara-noticias
 */
defined('ABSPATH') or die('Nope, not accessing this');

define('WP_CAMARA_NOTICIA_PLUGIN_URL', WP_PLUGIN_URL . "/" . dirname(plugin_basename(__FILE__)));

require_once(plugin_dir_path(__FILE__) . './controller/noticias-controller.php');
require_once(plugin_dir_path(__FILE__) . './controller/noticias-api-controller.php');
require_once(plugin_dir_path(__FILE__) . './controller/duplicate-post-controller.php');
require_once(plugin_dir_path(__FILE__) . './controller/painel-status-controller.php');
require_once(plugin_dir_path(__FILE__) . './config/config-service.php');
require_once(plugin_dir_path(__FILE__) . './config/config-plugin.php');

use noticias\config\ConfigService as ConfigService;
use noticias\controller\NoticiasController as NoticiasController;
use noticias\controller\NoticiasControllerRestApi as NoticiasControllerRestApi;
use noticias\controller\DuplicatePostController as DuplicatePostController;
use noticias\controller\PainelStatusController as PainelStatusController;
use noticias\config\ConfigPlugin as ConfigPlugin;

class Camara_Noticias
{
    private static $instance;

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new self();
        }
    }

    private function __construct()
    {
        $noticiasService = new ConfigService();
        $baseUrl = WP_PLUGIN_URL . "/" . dirname(plugin_basename(__FILE__));
        new NoticiasController(
            new ConfigPlugin($baseUrl),
            $noticiasService->noticiasService(),
            $noticiasService->deputadoService(),
            $noticiasService->proposicoesService(),
            $noticiasService->legislacoesService(),
            $noticiasService->glossarioService()
        );
        new NoticiasControllerRestApi($noticiasService->noticiasService());
        
        /* 
            Funcionalidade descontinuada, será tratada somente em wp-camara-dashboard e 
            será removida deste plugin posteriormente.
        */

        // new PainelStatusController(new ConfigPlugin($baseUrl), $noticiasService->noticiasService());
        new DuplicatePostController(new ConfigPlugin($baseUrl), $noticiasService->noticiasService());
    }
}
Camara_Noticias::getInstance();
