<?php namespace noticias\util;
/**
 * TODO - Criar aqui as validacoes dos campos do dominio
 */
class ValidationUtil
{

    public function extrairHora($data)
    {
        $d = strtotime($data);
        $novoFormato = date('H:i',$d);
        return $novoFormato;
    }

    public function extrairData($data)
    {
        $novoFormato = null;
        if($data){
            $d = strtotime($data);
            $novoFormato = date('Y-m-d',$d);
            return $novoFormato;
        }
        return $novoFormato;
    }

    public function agregandoDataHoraParaString($data,$hora)
    {
        $dataAgregada = $data.'T'.$hora.':00';
        return $dataAgregada;
    }
}