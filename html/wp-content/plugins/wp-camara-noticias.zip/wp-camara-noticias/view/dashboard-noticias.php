<div class="nav-top">
    <div class="row">
        <div class="col-4"></div>
        <div class="col-4 text-center">
            <?php $current_url = "//" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>
            <form class="form-inline" role="form" method="GET" action="#">
                <div class="form-group">
                    <label for="dataPesquisa" style="color:#ffff;font-size: 13px;">
                        Selecione a data (dd/mm/aaaa):
                        <span class="glyphicon glyphicon-calendar"></span>
                    </label>
                    <input autocomplete="off" type="text" id="dataPesquisa" name="dataPesquisa"
                         class="form-control mx-sm-1" style="width: 120px;" />
                    <input id="page" type="hidden" name="page" value="<?php echo $_GET['page']; ?>" />
                    <button type="submit" class="btn-search">Buscar</button>       
                </div>
            </form>
        </div>
        <div class="col-4"></div>
    </div>          
</div>

<div class="container-fluid mt-3">
    <div class="row">
        <div class="col-4 border-bottom"></div>
        <div class="col-3 border-bottom-title">
            <h4 class="text-center">DASHBOARD DE NOTÍCIAS</h4>
        </div>
        <div class="col-5 border-bottom"></div>
    </div>
    <div class="row mt-2">

        <?php 
            $queryParams = array();
            $dtQuery = date('d/m/Y');

            // Obtem filtro de data
            if ( ! empty( $_GET ) && isset($_GET['dataPesquisa']) &&  ! empty( $_GET['dataPesquisa'] )) {
                // Filtra pela data informada
                $data = explode("/", $_GET['dataPesquisa']);
                $year = $data[2];
                $month = $data[1];
                $day = $data[0];
                $dtQuery = $day.'/'.$month.'/'.$year;
                $queryParams['date_query'] = array('year' => intval($year), 'month' => intval($month), 'day' => intval($day));
            } else {
                // Filtra as materias do dia corrente
                $queryParams['date_query'] = array('after' => 'today', 'inclusive' => true); 
            }   
            
            $materiasDoDia = $this->noticiasService->get_materias_do_dia($queryParams);
            $nameStatusArray = $this->noticiasService->get_array_status_name();

            foreach ($materiasDoDia as $key => $value) { ?>
               <div class="col-2">
                    <div class="card-noticias">
                        <div class="card-header <?php echo 'bg-'.$key; ?>">
                            <?php echo $nameStatusArray[$key].' ('.$value['count'].')' ?>
                        </div>
                        <div class="card-content">
                            <?php foreach ($materiasDoDia[$key]['posts'] as $key2 => $post) { ?>
                                <!-- CARD ITEM -->
                                <div class="card-item mt-2 mb-2">
                                    <span class="card-date"><?php echo date("d/m/Y H:i:s", strtotime($post->post_date)); ?></span>
                                    <br />
                                    <a  class="text-dark" href="<?php echo get_edit_post_link($post->ID); ?>">
                                        <span class="text-justify card-text"><?php echo $post->post_title; ?></span>
                                    </a>
                                </div>
                                <!-- END CARD ITEM -->
                            <?php } ?> 
                        </div>
                    </div>
                </div>
            <?php }
            

            if(count($materiasDoDia) == 0) {?> 
                <div class="col-11 mt-5">
                    <h6 class="text-center text-danger">Nenhuma notícia encontrada em <?php echo $dtQuery; ?>  </h6>
                </div>
            <?php }?> 

        
    </div>
</div>