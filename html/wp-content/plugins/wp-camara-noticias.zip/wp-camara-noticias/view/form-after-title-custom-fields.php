<?php require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php'); 
use noticias\mapeamento\CamposDB as CamposDB;
?>
<table id="tipo-midia-select" class="tab1">
    <tr>
    <td>
      <div style="padding-right: 10px;">
        <label class="required">Tipo:</label><br>
        <select name="<?= CamposDB::CD_NOTICIA_TIPO ?>" id="<?= CamposDB::CD_NOTICIA_TIPO ?>" style="width: 130px;"> 
            <option value="">Selecione</option>
            <?php foreach ($this->noticia->getTipos() as $key => $value) :
                if ($this->noticia->getTipo() == $key) {
                echo "<option selected='selected' value=\"$key\" >$value</option>";
            } else {
                echo "<option value=\"$key\" >$value</option>";
            }
            endforeach; ?>

        </select>
      </div>
    </td>
    <td>
        <div style="padding-right: 10px;">
            <label class="required">Midia:</label><br>
            <select name="<?= CamposDB::CD_NOTICIA_TIPO_MIDIA ?>" id="<?= CamposDB::CD_NOTICIA_TIPO_MIDIA ?>" style="width: 130px;"> 
                <option value="">Selecione</option>
                <?php foreach ($this->noticia->getTiposMidias() as $key => $value) :
                    if ($this->noticia->getTipoMidia() == $key) {
                    echo "<option selected='selected' value=\"$key\" >$value</option>";
                } else {
                    echo "<option value=\"$key\" >$value</option>";
                }
                endforeach; ?>

            </select>
        </div>
   </td >
   <td>
     <div>
        <form class="form-inline oculta" role="form" method="POST" action="#">
          <input type="hidden" name="<?php echo 'cd_novo_tema_do_dia' ?>" id="<?php echo 'cd_novo_tema_do_dia' ?>" />
        </form>
        <label for="<?= CamposDB::CD_NOTICIA_TEMA_DO_DIA ?>">Tema do dia:</label><br>
        <select name="<?= CamposDB::CD_NOTICIA_TEMA_DO_DIA ?>" id="<?= CamposDB::CD_NOTICIA_TEMA_DO_DIA ?>" style="width: 500px;">
          <option selected='selected' value="<?= $this->noticia->getTemaDoDia()->id ?>"><?= $this->noticia->getTemaDoDia()->titulo ?></option>
        </select>                
    </div>
   </td>
   <td>
     <div class="destaque-home-tematica">
        <button id="dialogo-destaque-home-tematica" class="button">Destaque Home Temática</button>
     </div>
   </td>
 </tr>
</table>
<table id="retranca" class="field-table retranca">
        <tr>
            <td>
                <div>
                    <label>Retranca:</label><br>
                    <textarea class="text-area-fields" style="resize: none;" id="<?= CamposDB::CD_NOTICIA_RETRANCA ?>" name="<?= CamposDB::CD_NOTICIA_RETRANCA ?>" rows="2" cols="40" data-label="Retranca" id="retranca"><?php echo $this->noticia->getRetranca() ?></textarea>
                    <div class="qtd-caracteres">(<span id="cd_retranca-qtd-c"></span> caracteres)</div>
                </div>
            </td>
        </tr>
    </table>