class AssociaLegislacoes {

  constructor(tabelaLegislacoes) {
    this._criarEventoAssociaLegislacoes();
    this.tabela = tabelaLegislacoes.tabela;
  }

  _criarEventoAssociaLegislacoes() {
    const associaLegislacoes = this;
    jQuery("#btnAssociaLegislacoes").on('click', function (event) {
      jQuery('#loaderAssociaLegislacoes').attr('style', 'display:inline-block;');
      AjaxPesquisa.pesquisa('POST', { action: "legislacoes_regex" }, (regex) => {
        let conteudo = tinyMCE.activeEditor.getContent();
        let linksLegislacao = $(conteudo).find('.linkLegislacao');
        linksLegislacao.map((index, link) => {
          conteudo = conteudo.replace($(link).text(), '');
        });
        conteudo = associaLegislacoes._removerTextosAtributos(conteudo, 'title', 'alt');
        let legislacoes = conteudo.match(new RegExp(regex, "g"));
        const dataFormPesquisa = {
          action: "pesquisa_legislacoes_noticia",
          legislacoes: legislacoes
        };
        AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (resultados) => {
          if (resultados) {
            resultados = JSON.parse(resultados);
            let rows = associaLegislacoes.tabela.rows().data();
            rows = associaLegislacoes._removerCamposNaoConfirmados(rows);
            for (let i in resultados) {
              if (associaLegislacoes._verificarLegislacoesNaoConfirmadas(resultados[i], rows)) {
                rows.push(resultados[i]);
              }
            }
            associaLegislacoes.tabela.rows().remove();
            associaLegislacoes.tabela.rows.add(rows).draw(false);
            jQuery('#loaderAssociaLegislacoes').attr('style', 'display:none;');
          }
        });
      });
    });
  }

  _removerCamposNaoConfirmados(rows) {
    return rows.filter(function (row) {
      return row.legislacao && row.legislacao.confirmado;
    });
  }

  _removerTextosAtributos(conteudo, ...attrs) {
    for (let i in attrs) {
      let atributos = $(conteudo).find('[' + attrs[i] + ']');
      if (atributos.map) {
        atributos.map((index, link) => {
          conteudo = conteudo.replace($(link).attr(attrs[i]), '');
        });
      }
    }
    return conteudo;
  }

  _verificarLegislacoesNaoConfirmadas(resultado, rows) {
    let legislacaoNaLista = false;
    for (let i in rows) {
      if (resultado.legislacao === null && rows[i].legislacao === null && rows[i].regex === resultado.regex) {
        legislacaoNaLista = true;
        break;
      }
      if (resultado.legislacao && !resultado.legislacao.confirmado && rows[i].legislacao
        && !rows[i].legislacao.confirmado
        && rows[i].legislacao.numero === resultado.legislacao.numero
        && rows[i].legislacao.ano === resultado.legislacao.ano
        && rows[i].regex === resultado.regex) {
        legislacaoNaLista = true;
        break;
      }
    }
    return legislacaoNaLista ? false : true;

  }
}

jQuery(document).ready(function () {
  new AssociaLegislacoes(new TabelaLegislacoes());
});