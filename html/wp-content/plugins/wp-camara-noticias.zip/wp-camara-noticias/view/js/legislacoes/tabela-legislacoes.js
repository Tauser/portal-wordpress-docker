const CD_LEGISLACOES = "cd_legislacoes";

class TabelaLegislacoes {

    constructor() {
        this._idTabela = 'legislacoes-associadas';
        this._tabela = this._criar();
        this._criarEventoAjaxTabela();
        this._criarAcoes();
    }

    get tabela() {
        return this._tabela;
    }

    _criar() {
        const dataFormPesquisa = {
            action: "legislacoes_associadas",
            post_id: this._getUrlParameter('post')
        };
        return jQuery('#' + this._idTabela).DataTable({
            "ajax": { url: ajaxurl, dataType: "json", type: 'POST', data: dataFormPesquisa, dataSrc: "" },
            paging: false,
            ordering: false,
            searching: false,
            language: {
                infoEmpty: "Nenhum resultado encontrado",
                emptyTable: "Nenhuma lei associada",
                processing: "Por favor, aguarde...",
                loadingRecords: "Por favor, aguarde...",
            },
            columns: [
                {
                    data: "informacoes", "width": "50%", render: function (data, type, row) {
                        let info = row.regex !== null ? "<span class='regex'>" + row.regex + " link: </span><br/>" : "";
                        if (row.legislacao != null) {
                            if (!row.legislacao.existe) {
                                info += "<span class='legislacaoNaoExiste'>NÃO LOCALIZADO </span><label>Digite a lei: <label><input type='text' id='legislacaoCompleta' class='legislacaoCompleta' /><label>";
                            } else {
                                info += "<span class='legislacaoCompleta'>" + 'Lei ' + row.legislacao.numero + '/' + row.legislacao.ano + '</span>';
                            }
                        } else {
                            let combo = "<select id='comboLegislacao' class='comboLegislacao' style='width: 100%'>";
                            combo += "<option value=''>Selecione</option>";
                            for (let i = 0; i < row.opcoes.length; i++) {
                                combo += "<option value='" + JSON.stringify(row.opcoes[i]) + "' >" + "<span>" + 'Lei ' + row.opcoes[i].numero + '/' + row.opcoes[i].ano + '</span>' + "</option>";
                            }
                            combo += '</select>';
                            info += combo;
                        }
                        return info;
                    }
                },
                {
                    data: "acoes", render: function (data, type, row) {
                        if (row.legislacao) {
                            if (row.legislacao.confirmado && row.regex === null) {
                                return "<input type='button' class='button btn-remover-leg' value='Remover' />";
                            }
                            if (!row.legislacao.existe) {
                                return "<input type='button' class='button btn-pesquisar-leg' value='Pesquisar' /> <span style='display:none;' id='loader' class='spinnerCustom loaderPesquisaLeg'></span><span id='campoObrigatorio' class='msgCampoObrigatorio' style='display:none;'>Campo lei é obrigatório</span>";
                            }
                            if (row.legislacao.confirmado && row.regex !== null) {
                                return "";
                            }
                        }
                        return "<input type='button' class='button btn-confirmar-leg' value='Confirmar' /> <span id='selecaoObrigatoria' class='msgSelecaoObrigatoria' style='display:none;'>Selecione uma lei</span>";
                    }
                }
            ]
        });
    }

    _criarEventoAjaxTabela() {
        const tabelaLegislacoes = this;
        this._tabela.on('xhr', function (item) {
            const rows = tabelaLegislacoes._tabela.ajax.json();
            tabelaLegislacoes._atualizarIdsParaSalvar(rows);
        });
    }

    _getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    }

    _criarAcoes() {
        const tabelaLegislacoes = this;
        this.tabela.on('draw', function () {
            tabelaLegislacoes._criarEventoPesquisarLegislacaoNaoEncontrada(this);
            tabelaLegislacoes._criarEventoRemoverLegislacao(this);
            tabelaLegislacoes._criarEventoConfirmar(this);
        });
    }

    _criarEventoRemoverLegislacao(context) {
        const tabelaLegislacoes = this;
        jQuery(context).on('click', '.btn-remover-prop', function () {
            tabelaLegislacoes._tabela.row(jQuery(this).closest('tr')).remove().draw();
            const rows = tabelaLegislacoes._tabela.rows().data();
            tabelaLegislacoes._atualizarIdsParaSalvar(rows);
        });
    }

    _criarEventoPesquisarLegislacaoNaoEncontrada(context) {
        const tabelaLegislacoes = this;
        jQuery(context).on('click', '.btn-pesquisar-leg', function () {
            const contextRow = jQuery(tabelaLegislacoes._tabela.row(jQuery(this).closest('tr')).node());
            jQuery(contextRow).find('#loader').attr('style', 'display:inline-block;');
            jQuery(contextRow).find('#campoObrigatorio').attr('style', 'display:none;');
            if (!jQuery(contextRow).find('#legislacaoCompleta').val()) {
                jQuery(contextRow).find('#loader').attr('style', 'display:none;');
                jQuery(contextRow).find('#campoObrigatorio').attr('style', 'display:inline-block;');
                return;
            }
            const row = tabelaLegislacoes._tabela.row(jQuery(contextRow)).data();
            const dataFormPesquisa = {
                action: "pesquisa_legislacoes_noticia",
                legislacoes: [jQuery(contextRow).find('#legislacaoCompleta').val() + '-' + row.regex]
            };
            AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (legislacoes) => {
                let legislacao = JSON.parse(legislacoes)[0];
                let rows = tabelaLegislacoes._tabela.rows().data();
                const index = tabelaLegislacoes._tabela.row(jQuery(contextRow)).index();
                rows[index] = legislacao;
                tabelaLegislacoes._tabela.rows().remove();
                tabelaLegislacoes._tabela.rows.add(rows).draw(false);
            });
        });
    }

    _criarEventoConfirmar(context) {
        const tabelaLegislacoes = this;
        this._tabela.on('draw', function () {
            jQuery("#comboLegislacao").select2();
            jQuery(context).on('click', '.btn-confirmar-leg', function () {
                const contextRow = jQuery(tabelaLegislacoes._tabela.row(jQuery(this).closest('tr')).node());
                let resultado = tabelaLegislacoes._tabela.row(jQuery(contextRow)).data();
                if (resultado) {
                    jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:none;');
                    if (jQuery(contextRow).find('#comboLegislacao').length > 0 && !jQuery(contextRow).find('#comboLegislacao').children("option:selected").val()) {
                        jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:inline-block;');
                        return;
                    }
                    if (resultado.opcoes) {
                        const legislacao = JSON.parse(jQuery(contextRow).find('#comboLegislacao').children("option:selected").val());
                        resultado.legislacao = legislacao;
                        resultado.opcao = null;
                    } else {
                        resultado = tabelaLegislacoes._tabela.row(jQuery(contextRow)).data();
                    }
                    let conteudo = tinyMCE.activeEditor.getContent();
                    // E necessario manter o que o usuario digitou, ou seja, a regex (parametro) informada para a pesquisa.
                    // conteudo = tabelaLegislacoes._replaceAll(conteudo, resultado.regex, "<a class='linkLegislacao' href='" + resultado.legislacao.link + "'>" + 'Lei ' + tabelaLegislacoes._maskNumero(resultado.legislacao.numero) + '/' + resultado.legislacao.ano + "</a>");
                    conteudo = tabelaLegislacoes._replaceAll(conteudo, resultado.regex, "<a class='linkLegislacao' href='" + resultado.legislacao.link + "'>" + resultado.regex + "</a>");
                    tinyMCE.activeEditor.setContent(conteudo, { format: 'html' });
                    tabelaLegislacoes._atualizarTabelaDepoisDaConfirmacao(tabelaLegislacoes, resultado);
                }
            });
        });

    }

    _escapeRegExp(str) {
        return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    }

    _replaceAll(str, find, replace) {
        return str.replace(new RegExp(this._escapeRegExp(find), 'g'), replace);
    }

    _atualizarTabelaDepoisDaConfirmacao(tabelaLegislacoes, resultado) {
        let rows = tabelaLegislacoes._tabela.rows().data();
        let legislacoesAtualizados = [];
        for (let i = 0; i <= rows.length; i++) {
            const result = rows[i];
            if (result) {
                if (result.legislacao && !result.legislacao.confirmado && result.regex === resultado.regex) {
                    result.legislacao.confirmado = true;
                }
                legislacoesAtualizados.push(result);
            }
        }
        tabelaLegislacoes._tabela.rows().remove();
        tabelaLegislacoes._tabela.rows.add(legislacoesAtualizados).draw(false);
        tabelaLegislacoes._atualizarIdsParaSalvar(legislacoesAtualizados);
    }

    _atualizarIdsParaSalvar(legislacoes) {
        let legislacoesConfirmadas = '';
        for (let i in legislacoes) {
            if (legislacoes[i].legislacao && legislacoes[i].legislacao.confirmado && legislacoes[i].legislacao.confirmado === true) {
                legislacoesConfirmadas = legislacoesConfirmadas + legislacoes[i].legislacao.id + ",";
            }
        }
        legislacoesConfirmadas = legislacoesConfirmadas.substring(0, legislacoesConfirmadas.length - 1);
        jQuery("#" + CD_LEGISLACOES).val(legislacoesConfirmadas);
    }

    _maskNumero(numero) {
        return numero.toString().replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1.");
    }

}