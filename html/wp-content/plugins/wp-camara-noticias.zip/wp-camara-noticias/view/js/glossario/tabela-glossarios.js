class TabelaGlossarios {

    constructor() {
        this._idTabela = 'glossarios-associados';
        this._tabela = this._criar();
        this._consultarGlossariosAdicionados();
        this._criarAcoes();
    }

    get tabela() {
        return this._tabela;
    }

    _criar() {
        return jQuery('#' + this._idTabela).DataTable({
            paging: false,
            ordering: false,
            searching: false,
            autoWidth: false,
            language: {
                infoEmpty: "Nenhum resultado encontrado",
                emptyTable: "Nenhum termo associado",
                processing: "Por favor, aguarde...",
                loadingRecords: "Por favor, aguarde...",
            },
            columns: [
                {
                    data: "informacoes", "width": "80%", render: function (data, type, row) {

                        let info = '';
                        
                        if (row.glossario != null) {
                            if (!row.glossario.existe) {
                                info += "<span> O termo <span style='color: red; font-weight: bold;'>" + row.regex + "</span> <span class='erro'>não foi localizado</span> no <a href='edit-tags.php?taxonomy=glossario' target='_blank'>Glossário.</a></span><br/>";
                                info += "<label>Pesquisar novo termo:</label><br/><input type='text' style='width: 70%;' id='nomeGlossario' class='nomeGlossario' value='" + row.regex + "'/>";
                            } else {
                                if (row.glossario.confirmado) {
                                    info += "<span class='nomeGlossario'><span style='color: red; font-weight: bold;'>" + row.glossario.titulo +  "</span>: <br/>" + row.glossario.descricao + " </span>";
                                } else {
                                    info += "<span class='nomeGlossario'>Termo <span style='color: red; font-weight: bold;'>" + row.regex +  "</span> : <br/> <span style='font-weight: bold;color: #000ecc'>Título: </span><span class='tituloGlossario' style='font-weight: bold;' />" + row.glossario.titulo + "</span><br/><span style='font-weight: bold;color: #000ecc'>Descrição: </span>" + row.glossario.descricao + ") </span>";
                                }
                            }
                        } else {
                            info += "<span>Selecione uma denifição de glossário para o termo <b>" + row.regex + " </b>: </span><br/>";
                            let combo = "<select id='comboNomeGlossario' class='comboNomeGlossario' style='width: 100%'>";
                            combo += "<option value=''>Selecione</option>";
                            for (let i = 0; i < row.opcoes.length; i++) {
                                combo += "<option value='" + JSON.stringify(row.opcoes[i]) + "' >" + "<span>" + row.opcoes[i].titulo + ' </span>' + "</option>";
                            }
                            combo += '</select>';
                            info += combo;
                        }
                        return info;
                    }
                },
                {
                    data: "acoes", render: function (data, type, row) {
                        if (row.glossario) {
                            if (row.glossario.confirmado && row.regex === null) {
                                return "";
                            }
                            if (!row.glossario.existe) {
                                return "<input type='button' class='button btn-pesquisar-glo' value='Pesquisar' /> <span style='display:none;' id='loader' class='spinnerCustom loaderPesquisaGlo'></span><span id='campoObrigatorio' class='msgCampoNomeObrigatorio' style='display:none;'>Campo palavra é obrigatória</span>";
                            }
                            if (row.glossario.confirmado && row.regex !== null) {
                                return "";
                            }
                        }
                        if (row.opcoes) {
                            return "<input type='button' class='button btn-selecionar-glo' value='Selecionar' /> <span id='selecaoObrigatoria' class='msgSelecaoObrigatoria' style='display:none;'>Selecione o termo</span>";
                        }
                        return "<input type='button' class='button btn-confirmar-glo' value='Confirmar' />";
                    }
                }
            ]
        });
    }

    _consultarGlossariosAdicionados() {
        const tabelaGlossarios = this;
        jQuery(document).on('tinymce-editor-init', function (event, editor) {
            let conteudo = editor.getContent();
            let rows = tabelaGlossarios._tabela.rows().data();
            jQuery(conteudo).find('.termoGlossario').each(function (index, element) {
                const termosGlossario = jQuery(element);
                rows.push(JSON.parse('{"regex": null, "glossario": {"id": 1, "titulo": "' + termosGlossario.text() + '" , "descricao": "' + termosGlossario.attr('title') + '", "existe": true, "confirmado": true}, "opcoes": null }'));
            });
            tabelaGlossarios._tabela.rows().remove();
            tabelaGlossarios._tabela.rows.add(rows).draw(false);
        });
    }

    _getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    }

    _criarAcoes() {
        const tabelaGlossarios = this;
        this._tabela.on('draw', function () {
            // tabelaGlossarios._criarEventoAtualizaTitulo(this);
            tabelaGlossarios._criarEventoSelecionar(this);
            tabelaGlossarios._criarEventoPesquisarGlossarioNaoEncontrado(this);
            tabelaGlossarios._criarEventoConfirmar(this);
            jQuery("#" + tabelaGlossarios._idTabela).tooltip();
        });
    }

    // _criarEventoAtualizaTitulo() {
    //     const tabelaGlossarios = this;
    //     jQuery('.tituloGlossario').on('change', function () {
    //         let rows = tabelaGlossarios._tabela.rows().data();
    //         const index = tabelaGlossarios._tabela.row($(this).closest('tr')).index();
    //         rows[index].glossario.titulo = jQuery('.tituloGlossario').val();
    //     });
    // }

    _criarEventoPesquisarGlossarioNaoEncontrado(context) {
        const tabelaGlossarios = this;
        jQuery(context).on('click', '.btn-pesquisar-glo', function () {
            const contextRow = jQuery(tabelaGlossarios._tabela.row(jQuery(this).closest('tr')).node());
            jQuery(contextRow).find('#loader').attr('style', 'display:inline-block;');
            jQuery(contextRow).find('#campoObrigatorio').attr('style', 'display:none;');
            if (!jQuery(contextRow).parent().find('#nomeGlossario').val()) {
                jQuery(contextRow).find('#loader').attr('style', 'display:none;');
                jQuery(contextRow).find('#campoObrigatorio').attr('style', 'display:inline-block;');
                return;
            }
            const row = tabelaGlossarios._tabela.row(jQuery(contextRow)).data();
            const dataFormPesquisa = {
                action: "pesquisa_glossario_noticia",
                glossarios: [jQuery(contextRow).find('#nomeGlossario').val() + '-' + row.regex]
            };
            AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (glossarios) => {
                if (glossarios) {
                    let glossario = JSON.parse(glossarios)[0];
                    let rows = tabelaGlossarios._tabela.rows().data();
                    const index = tabelaGlossarios._tabela.row($(contextRow)).index();
                    rows[index] = glossario;
                    tabelaGlossarios._tabela.rows().remove();
                    tabelaGlossarios._tabela.rows.add(rows).draw(false);
                }
            });
        });
    }

    _criarEventoConfirmar(context) {
        const tabelaGlossarios = this;
        this._tabela.on('draw', function () {
            jQuery("#comboNomeGlossario").select2({
                templateResult: tabelaGlossarios._formatOptionsCombo
            });
            jQuery(context).on('click', '.btn-confirmar-glo', function () {
                const contextRow = jQuery(tabelaGlossarios._tabela.row(jQuery(this).closest('tr')).node());
                let resultado = tabelaGlossarios._tabela.row(jQuery(contextRow)).data();
                // jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:none;');
                // if (jQuery(contextRow).find('#comboNomeGlossario').length > 0 && !jQuery(contextRow).find('#comboNomeGlossario').children("option:selected").val()) {
                //     jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:inline-block;');
                //     return;
                // }
                if (resultado.opcoes) {
                    const glossario = JSON.parse(jQuery(contextRow).find('#comboNomeGlossario').children("option:selected").val());
                    resultado.glossario = glossario;
                    resultado.opcao = null;
                } else {
                    resultado = tabelaGlossarios._tabela.row(jQuery(contextRow)).data();
                }
                let conteudo = tinyMCE.activeEditor.getContent();
                // E necessario manter o que o usuario digitou, ou seja, a regex (parametro) informada para a pesquisa.
                // conteudo = tabelaGlossarios._replaceAll(conteudo, '[[g' + resultado.regex + ']]', "<span contenteditable='false' id='" + resultado.glossario.id + "' class='termoGlossario' title='" + resultado.glossario.descricao + "'>" + resultado.glossario.titulo + "</span>");
                conteudo = tabelaGlossarios._replaceAll(conteudo, '[[g' + resultado.regex + ']]', "<span contenteditable='false' id='" + resultado.glossario.id + "' class='termoGlossario' data-toggle='tooltip' data-placement='top' title='" + resultado.glossario.descricao + "'>" + resultado.regex + "</span>");
                tinyMCE.activeEditor.setContent(conteudo, { format: 'html' });
                tabelaGlossarios._atualizarTabelaDepoisDaConfirmacao(tabelaGlossarios, resultado);
            });
        });

    }

    _criarEventoSelecionar(context) {
        const tabelaGlossarios = this;
        this._tabela.on('draw', function () {
            jQuery(context).on('click', '.btn-selecionar-glo', function () {
                const contextRow = jQuery(tabelaGlossarios._tabela.row(jQuery(this).closest('tr')).node());
                jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:none;');
                if (jQuery(contextRow).find('#comboNomeGlossario').length > 0 && !jQuery(contextRow).find('#comboNomeGlossario').children("option:selected").val()) {
                    jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:inline-block;');
                    return;
                }
                const glossario = JSON.parse(jQuery(contextRow).find('.comboNomeGlossario').children("option:selected").val());
                let rows = tabelaGlossarios._tabela.rows().data();
                const index = tabelaGlossarios._tabela.row($(contextRow)).index();
                rows[index].glossario = glossario;
                rows[index].opcoes = null;
                tabelaGlossarios._tabela.rows().remove();
                tabelaGlossarios._tabela.rows.add(rows).draw(false);

            });
        });

    }

    _escapeRegExp(str) {
        return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    }

    _replaceAll(str, find, replace) {
        return str.replace(new RegExp(this._escapeRegExp(find), 'g'), replace);
    }

    _atualizarTabelaDepoisDaConfirmacao(tabelaGlossarios, resultado) {
        let rows = tabelaGlossarios._tabela.rows().data();
        let glossariosAtualizados = [];
        for (let i = 0; i <= rows.length; i++) {
            const result = rows[i];
            if (result) {
                if (result.glossario && !result.glossario.confirmado && result.glossario.id === resultado.glossario.id) {
                    result.glossario.confirmado = true;
                }
                glossariosAtualizados.push(result);
            }
        }
        tabelaGlossarios._tabela.rows().remove();
        tabelaGlossarios._tabela.rows.add(glossariosAtualizados).draw(false);
    }

    _formatOptionsCombo(state) {
        if (!state.id) { return state.text; }
        const glossario = JSON.parse(state.id);
        var $state = $(
            "<span style='font-weight: bold;'>" + glossario.titulo + "</span> - " + "<span>" + glossario.descricao + "</span>"
        );
        return $state;
    }
}