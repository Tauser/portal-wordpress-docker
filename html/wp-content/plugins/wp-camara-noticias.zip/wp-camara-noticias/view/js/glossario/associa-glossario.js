class AssociaGlossario {

  constructor(tabelaGlossarios) {
    this._criarEventoAssociaGlossarios();
    this.tabela = tabelaGlossarios.tabela;
  }

  _criarEventoAssociaGlossarios() {
    const associaGlossarios = this;
    jQuery("#btnAssociaGlossarios").on('click', function (event) {
      jQuery("#btnAssociaGlossarios").css('display', 'none');
      jQuery('#loaderAssociaGlossarios').attr('style', 'display:inline-block;');
      AjaxPesquisa.pesquisa('POST', { action: "glossario_regex" }, (regex) => {
        let conteudo = tinyMCE.activeEditor.getContent();
        let glossarios = conteudo.match(new RegExp(regex, "g"));
        event.preventDefault();
        const dataFormPesquisa = {
          action: "pesquisa_glossario_noticia",
          glossarios: glossarios
        };
        AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (resultados) => {
          if (resultados) {
            resultados = JSON.parse(resultados);
            let rows = associaGlossarios.tabela.rows().data();
            rows = associaGlossarios._removerCamposNaoConfirmados(rows);
            for (let i in resultados) {
              if (associaGlossarios._verificarGlossarioNaoConfirmado(resultados[i], rows)) {
                rows.push(resultados[i]);
              }
            }
            associaGlossarios.tabela.rows().remove();
            associaGlossarios.tabela.rows.add(rows).draw(false);
            jQuery('#loaderAssociaGlossarios').attr('style', 'display:none;');
            jQuery("#btnAssociaGlossarios").css('display', 'block');
          }
        });
      });
    });
  }

  _removerCamposNaoConfirmados(rows) {
    return rows.filter(function (row) {
      return row.glossario && row.glossario.confirmado;
    });
  }

  _verificarGlossarioNaoConfirmado(resultado, rows) {
    let glossarioNaLista = false;
    for (let i in rows) {
      if (resultado.glossario === null && rows[i].glossario === null && rows[i].regex === resultado.regex) {
        glossarioNaLista = true;
        break;
      }
      if (resultado.glossario && !resultado.glossario.confirmado && rows[i].glossario && rows[i].glossario.titulo === resultado.glossario.titulo && rows[i].regex === resultado.regex) {
        glossarioNaLista = true;
        break;
      }
    }
    return glossarioNaLista ? false : true;

  }
}

jQuery(document).ready(function () {
  new AssociaGlossario(new TabelaGlossarios());
});