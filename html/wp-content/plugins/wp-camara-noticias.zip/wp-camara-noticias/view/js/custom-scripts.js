jQuery(document).ready(function($) {
    
    // Ativa o select2 
    $('#cd_temaPrincipal').select2({ minimumResultsForSearch: -1, width: 'resolve'}); 
    $('#cd_temas').select2({ width: 'resolve'});
    $('#cd_tipo').select2({minimumResultsForSearch: -1, width: 'resolve'});
    $('#cd_tipoMidia').select2({minimumResultsForSearch: -1});

    // Ajusta os elementos nativos do wordpress nos tabs
    $('#postdivrich').addClass('tab1');
    $('#postbox-container-2').addClass('tab4');

    // Captura o change dos Tabs
    $('input[name=tabs]').change(function(e) {

        switch(this.id) {

            // A case for each action. Your actions here
            case "tab1":
                 $('.tab1').css('display', 'block');
                 $('.tab2').css('display', 'none');
                 $('.tab3').css('display', 'none');
                 $('.tab4').css('display', 'none');

                // Para remediar bug no tinyMCE que quebra o leiuate da barra de ferramentas ao fazer scroll com o editor invisível
                tinymce.EditorManager.execCommand( 'WP_Adv' );
                tinymce.EditorManager.execCommand( 'WP_Adv' );
                 
                 break;
            case "tab2":
                $('.tab1').css('display', 'none');
                $('.tab2').css('display', 'block');
                $('.tab3').css('display', 'none');
                $('.tab4').css('display', 'none');
                 break;
            case "tab3":
                $('.tab1').css('display', 'none');
                $('.tab2').css('display', 'none');
                $('.tab3').css('display', 'block');
                $('.tab4').css('display', 'none');
                 break;
            case "tab4":
                $('.tab1').css('display', 'none');
                $('.tab2').css('display', 'none');
                $('.tab3').css('display', 'none');
                $('.tab4').css('display', 'block');
                 break;
        }

    });

    // Contador de caracteres do título
    $("#titlewrap").append('<div class="qtd-caracteres">(<span id="titulo-qtd-c"></span> caracteres)</div>');

    $("#titulo-qtd-c").text($('input[name=post_title]').val().length);
    
    $('input[name=post_title]').keyup(function(){
        $("#titulo-qtd-c").text($(this).val().length);
    });

    // Contador de caracteres do resumo
    $("#resumo-qtd-c").text($("#excerpt").val().length);

    $("#excerpt").keyup(function(){
        $("#resumo-qtd-c").text($(this).val().length);
    });

    // Contador de caracteres do retranca
    $("#cd_retranca-qtd-c").text($("#cd_retranca").val().length);

    $("#cd_retranca").keyup(function(){
        $("#cd_retranca-qtd-c").text($(this).val().length);
    });

    // Ação do botão novo tema do dia
    $("#novo-tema-do-dia").on('click', function() {
       alert('Funcionalidade não implementada')
       return false;
    });

    // Ação do botão destaque home temática. Deve chamar o plugin dialogo destaque home tematica.
    $("#dialogo-destaque-home-tematica").on('click', function() {
        // acao implementada no plugin wp-camara-destaque-home-tematica
        return false;
     });
    
});
