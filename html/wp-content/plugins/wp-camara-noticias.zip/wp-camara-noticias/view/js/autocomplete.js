jQuery(document).ready(function ($) {
  $('#cd_temaDoDia').select2({
    placeholder: 'Selecione o tema do dia',
    ajax: {
      url: ajaxurl, // AJAX URL is predefined in WordPress admin
      dataType: 'json',
      delay: 250, // delay in ms while typing when to perform a AJAX search
      valorDigitado: '',
      data: function (params) {
        valorDigitado = params.term;
        return {
          q: params.term, // search query
          action: 'temadodia_noticia' // AJAX action for admin-ajax.php
        };
      },
      processResults: function (data) {
        var options = [];
        if (data) {

          // data is the array of arrays, and each of them contains ID and the Label of the option
          $.each(data, function (index, text) { // do not forget that "index" is just auto incremented value
            options.push({ id: text[0], text: text[1] });
          });

        }
        addNovoTemaDoDia(valorDigitado, options);
        return {
          results: options
        };
      },
      cache: true
    },
    minimumInputLength: 3 // the minimum of symbols to input before perform a search
  });

  $('#cd_tags').select2({
    placeholder: 'Tags',
    ajax: {
      url: ajaxurl, // AJAX URL is predefined in WordPress admin
      dataType: 'json',
      delay: 250, // delay in ms while typing when to perform a AJAX search
      valorDigitado: '',
      data: function (params) {
        valorDigitado = params.term;
        return {
          q: params.term, // search query
          action: 'tags_noticia' // AJAX action for admin-ajax.php
        };
      },
      processResults: function (data) {
        var options = [];
        if (data) {

          // data is the array of arrays, and each of them contains ID and the Label of the option
          $.each(data, function (index, text) { // do not forget that "index" is just auto incremented value
            options.push({ id: text[0], text: text[1] });
          });

        }
        // nova tag para auto completar de tag
        addNovaTag(valorDigitado, options);
        return {
          results: options
        };
      },
      cache: true
    },
    minimumInputLength: 3 // the minimum of symbols to input before perform a search
  });


  function addNovaTag (valorDigitado, options){
    if(options.length == 0){
      $('#cd_novaTag').val(valorDigitado);

      $("#elementos" ).remove();
      $(".select2-results").append("<div id=\"elementos\"><b>Deseja inserir tag: </b> "+valorDigitado+" <button id=\"add_tag\" type=\"button\" >Confirmar</button></div>");
      $("#add_tag").click(function(){
        $.ajax({
          type: "POST",
          url: ajaxurl,
          data: {
            action: 'nova_tag_noticia',
          },
          success: function(response) {
            var result = JSON.parse(response);        
            var newOption = new Option(result.term_name, result.term_id, true, true);
            jQuery('#cd_tags').append(newOption).trigger('change');
            $("#elementos" ).remove();
            $('.select2-search__field').val('');
          }
        });
      });
    }else{
      $("#elementos" ).remove();
    }
  }

  function addNovoTemaDoDia (valorDigitado, options){
    if(options.length == 0){
      $('#cd_novo_tema_do_dia').val(valorDigitado);
      $("#elementos" ).remove();
      $(".select2-results").append("<div id=\"elementos\"><b>Deseja inserir novo tema do dia: </b> "+valorDigitado+" <button id=\"add_tema_do_dia\" type=\"button\" >Confirmar</button></div>");
      $("#add_tema_do_dia").click(function(){
        $.ajax({
          type: "POST",
          url: ajaxurl,
          data: {
            action: 'novo_tema_do_dia',
          },
          success: function(response) {
            const result = JSON.parse(response);        
            const newOption = new Option(result.term_name, result.term_id, true, true);
            jQuery('#cd_temaDoDia').append(newOption).trigger('change');
            $("#elementos" ).remove();
            $('.select2-search__field').val('');
          }
        });
      });
    }else{
      $("#elementos" ).remove();
    }
  }

});