class AjaxPesquisa {
    static pesquisa(type, dataFormPesquisa, callbak) {
        $.ajax({
          type: type,
          url: ajaxurl,
          data: dataFormPesquisa,
          success: function (resultado) {
            callbak(resultado);
          },
          error: function (MLHttpRequest, textStatus, errorThrown) {
            console.log(errorThrown);
          }
        });
      }
}