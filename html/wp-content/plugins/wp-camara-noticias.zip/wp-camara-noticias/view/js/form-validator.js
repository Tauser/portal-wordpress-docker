jQuery(document).ready(function ($) {
  let validadorPublish = false;
  $("#publish").on('click', function (event) {
    if (!validadorPublish) {
      validar(event, '#publishing-action .spinner', '#publish', true);
    }
  });
  let validadorSavePost = false;
  $("#save-post").on('click', function (event) {
    if (!validadorSavePost) {
      validar(event, '#save-action .spinner', '#save-post', false);
    }
  });
  function validar (event, spinner, idButton, publicar) {
      event.preventDefault();
      $(spinner).attr('class', 'spinner is-active');
      const dataForm = {
        action: "validador_noticia",
        post_title: $('input[name=post_title]').val(),
        post_content: $('#content_ifr').contents().find('[data-id=content]').text()
      };
      $.ajax({
        type: 'POST',
        url: ajaxurl,
        data: dataForm,
        success: function (data) {
          if (data && data != "0") {
            $('div').remove('.error');
            $('#post-body').prepend(data.replace("0", ""));
            $('.spinner').attr('class', 'spinner');

          } else {
            if(publicar) {
              validadorPublish = true;
            } else {
              validadorSavePost = true;
            }
            $(idButton).click();
          }
        },
        error: function (MLHttpRequest, textStatus, errorThrown) {
          console.log(errorThrown);
        }
      });
  }
});