jQuery(document).ready(function ($) {
    // Id do current post
    const currentPostId = $('#post_id').val();
    const dataForm = {
        action: "obter_continuacao_noticia",
        post_id: currentPostId
    };

    // Cria a grid de noticias relacionadas
    const tabela = $('#grid-continuacao').DataTable({
        "ajax": { url: ajaxurl, dataType: "json", type: 'POST', data: dataForm },
        paging: false,
        ordering: false,
        searching: false,
        autoWidth: false,
        language: {
            infoEmpty: "Nenhum resultado encontrado",
            emptyTable: "Nenhuma continuação associada",
            processing: "Por favor, aguarde...",
            loadingRecords: "Por favor, aguarde...",
        },
        columns: [
            {
                data: "imagem", "width": "60px", render: function (data, type, row) {
                    if(row.thumbnail) {
                        return "<img class='dumb-image' src='" + row.thumbnail + "'/>";
                    } else {
                        return "<div class='dumb-image'></div>";
                    }
                }
            },
            {
                data: "informacoes", render: function (data, type, row) {
                    var html = "";
                    html += "<span class='title-tipo-post'>" + row.tipoDePost + "</span><br />";
                    html += "<span>" + row.data + "</span><br />";
                    html += "<span><strong>" + row.titulo + "</strong></span><br />";
                    if (row.resumo != "") {
                        html += "<span>" + row.resumo + "</span>";
                    }
                    return html;
                }
            },
            {
                data: "delete", render: function (data, type, row) {
                    return "<input type='button' id=" + row.ID + " class='button btn-remove' value='Remover' /> ";
                }
            }
        ]
    });

    // Recupera o resultado e atribui ao objeto principal
    tabela.on('xhr', function (item) {
        const json = tabela.ajax.json();
        if(json && json.data) {
            materiasContinuacao.setPosts(json.data);
        }
    });

    // Quando a grid é renderizada
    tabela.on('draw', function () {
        // Método para remover materias relacionadas
        jQuery('.btn-remove').on('click', function () {
            tabela.row(jQuery(this).parents('tr')).remove().draw();
            materiasContinuacao.removeItem(this.id);
            jQuery('#grid-container').removeClass('closed');
        });
    });


});

const materiasContinuacao = {
    postsId: [],
    posts: [],
    getPostIdsAsString: function () {
        var ids = "";
        for (var i = 0; i < this.posts.length; i++) {
            if (i > 0 && this.posts[i].ID)
                ids += '-';
            if (this.posts[i].ID)
                ids += this.posts[i].ID;
        }
        return ids;
    },
    setPost: function (post) {
        var exist = this.postsId.findIndex(function (id) { id === post.ID });
        if (exist != 0)
            this.setInputVal(post, post.ID);
    },
    setPosts: function (posts) {
        posts.forEach(post => {
            this.setPost(post);
        });
    },
    setInputVal: function (post, postId) {
        this.postsId.push(parseInt(postId));
        this.posts.push(post);
        jQuery('#cd_continuacoes').val(this.postsId);
    },
    removeItem: function (postId) {
        // remove da lista de ids
        this.postsId = this.postsId.filter(function (value, index, arr) {
            return value != parseInt(postId);
        });
        // Remova da lista de posts
        this.posts = this.posts.filter(function (value, index, arr) {
            return value.ID != parseInt(postId)
        });
        jQuery('#cd_continuacoes').val(this.postsId);
    }
}

function open_dlg_continuacao() {
    // Recupera a lista de materias já relacionadas
    const blacklist = materiasContinuacao.getPostIdsAsString();

    // Abre dialogo
    dialogo_padrao_frame('admin.php?page=dialogo-selecao-conteudo&objetowp='
        + 'agencia&contexto=agencia&objetoswp=edicao_programa_tv,edicao_programa_radi,radioagencia,institucional,agencia'
        + '&callback=on_post_selecionado_continuacao&blacklist=' + blacklist,
        1200, 760, 'Associação de conteúdo');

}


// Callback chamado pelo dialogo de seleção de conteúdo (passada na chamada do dialogo modal padrão)
function on_post_selecionado_continuacao(thePost) {
    // Remove a classe que fecha o bloco da grid
    jQuery('#grid-container').removeClass('closed');

    // Recupera a instancia da tabela   
    const tabela = jQuery('#grid-continuacao').DataTable();

    var img_url = '';

    if(thePost.imagem && thePost.imagem.sizes ) {
        img_url = thePost.imagem.sizes[0].url
    }
    

    // Formata os dados retornados pela caixa de diálogo
    var post = {
        ID: thePost.ID, titulo: thePost.titulo, resumo: '',
        tipoDePost: thePost.post_type, data: thePost.data, audio: thePost.audio,
        thumbnail: img_url, link: thePost.link, tema: thePost.tema, video: thePost.video
    };

    // Adiciona o post ao objeto principal de controle.
    materiasContinuacao.setPost(post);

    // Adiciona uma nova linha à tabela
    tabela.row.add(post).draw(false);

    // Fecha a caixa de diálogo.
    dialogo_padrao.dialog("close");
}