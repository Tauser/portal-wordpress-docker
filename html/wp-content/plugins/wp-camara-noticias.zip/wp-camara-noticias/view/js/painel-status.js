var minutes, seconds, count, counter, timer;
var dataPesquisaUrlParam = getUrlParameterByName("dataPesquisa");
var postItemForUpdate;
var delay = function(ms) {
    return new Promise(function(r) {
        setTimeout(r, ms)
    })
};
var time = 2000;
count = 120; //seconds

/** Timer, descomentar para página atualizar a cada 2s */
//counter = setInterval(timer, 1000);

jQuery(document).ready(function($) {

    var dataAtual = getFormattedDate(new Date());
    var dataPesquisa = $('#dataPesquisa');
    var dataUltimaAtualizacao = getDateComHoraMinutoSegundo();

    if (dataPesquisaUrlParam) {
        $('.textDataNovaAtualizacao').hide();
        $('.dataSelecionada').show();
        $('#dataSelecionada').text(dataPesquisaUrlParam);
    }

    $('#dataDeAtualizacao').text(dataUltimaAtualizacao);

    dataPesquisa.datepicker({
        dateFormat: 'dd/mm/yy',
        maxDate: 0
    });

    // Função que realiza o submit para alteração do status do post
    $('.form-post-status').submit(function(event) {
        event.preventDefault();

        var formArray = $(this).serializeArray();
        var idPost = formArray[0].value;
        var newStatus = formArray[1].value;

        var imgLoad = '#loading_' + idPost;

        $(imgLoad).show();
        $(this).hide();

        // Realiza a chamada ajax
        $.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
                idPost: idPost,
                novoStatus: newStatus,
                action: 'camara_noticias_alterar_status',
            },
            success: function(response) {
                var json_response = JSON.parse(response);
                if (json_response['status_update']) {
                    location.reload();
                } else {
                    $(this).show();
                    $(imgLoad).hide();
                }
            },
            error: function(err) {
                $(this).show();
                $(imgLoad).hide();
                console.error('Ocorreu um erro ao alterar status do post: ' + err.message);
            }
        });
    });
});

/** Função que aciona a biblioteca de midias para a seleção de audio */
function associar_audio(postId, dataDaPesquisa) {
    postItemForUpdate = postId;
    dialogo_padrao_frame('admin.php?page=biblioteca-midias&tipo_midia=audio&contexto=painel-status-materia' +
        '&preview=false&callback=select_audio_callback&tipo_retorno=objeto&dataInicial='+dataDaPesquisa, 
        1200, 760, 'Biblioteca de Mídias - Seleção de Áudio ');
}

/** Função de callback que realiza a associação de audios no painel */
function select_audio_callback(midiaObject) {
    // Apresenta a modal de loading
    jQuery('body').loadingModal({
        text: 'Aguarde, realizando associação de áudio...'
    });

    if (midiaObject.ID !== null && postItemForUpdate !== null) {
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
                postId: postItemForUpdate,
                midiaId: midiaObject.ID,
                midia_type: 'audio',
                action: 'associar_midia_painel_de_noticias',
            },
            success: function(response) {
                var json_response = JSON.parse(response);
                if (json_response['status']) {
                    var element = jQuery('#audio' + midiaObject.ID);
                    element.css("display", "none");

                    // Modal de loading e efeitos
                    delay(time)
                        .then(function() { jQuery('body').loadingModal('animation', 'rotatingPlane').loadingModal('backgroundColor', 'red'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'wave'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'wanderingCubes').loadingModal('backgroundColor', 'green'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'spinner'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'chasingDots').loadingModal('backgroundColor', 'blue'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'threeBounce'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'circle').loadingModal('backgroundColor', 'black'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'cubeGrid'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'fadingCircle').loadingModal('backgroundColor', 'gray'); return delay(time);})
                        .then(function() { jQuery('body').loadingModal('animation', 'foldingCube'); return delay(time); } )
                        .then(function() { jQuery('body').loadingModal('color', 'black').loadingModal('text', 'Áudio associado com sucesso :-)').loadingModal('backgroundColor', 'yellow');  return delay(time); } )
                        .then(function() { jQuery('body').loadingModal('hide'); return delay(time); } )
                        .then(function() { jQuery('body').loadingModal('destroy') ;} );       
                }

                // remove a modal de loading
                delay(time).then(function() {
                    location.reload();
                    jQuery('body').loadingModal('destroy');
                });
            },
            error: function(err) {
                console.error('Ocorreu um erro ao associar midia...');
                console.error(err);
                jQuery('body').loadingModal('destroy');
            }
        });
    } else {
        console.error('Ocorreu um erro ao associar midia: Parametros obrigatórios não informados ');
        jQuery('body').loadingModal('destroy');
    }
}

/** Função que aciona a biblioteca de midias para a seleção de video */
function associar_video(postId, dataDaPesquisa) {
    postItemForUpdate = postId;
    dialogo_padrao_frame('admin.php?page=biblioteca-midias&tipo_midia=video&contexto=painel-status-materia' +
        '&preview=false&callback=select_video_callback&tipo_retorno=objeto&dataInicial='+dataDaPesquisa, 
        1200, 760, 'Biblioteca de Mídias - Seleção de Vídeo ');
}

/** Função de callback que realiza a associação de videos no painel */
function select_video_callback(midiaObject) {
    // Apresenta a modal de loading

    jQuery('body').loadingModal({
        text: 'Aguarde, realizando associação de vídeo...'
    });

    if (midiaObject.ID !== null && postItemForUpdate !== null) {
        jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: {
                postId: postItemForUpdate,
                midiaId: midiaObject.ID,
                midia_type: 'video',
                action: 'associar_midia_painel_de_noticias',
            },
            success: function(response) {
                var json_response = JSON.parse(response);
                if (json_response['status']) {
                    var element = jQuery('#video' + midiaObject.ID);
                    element.css("display", "none");
                    
                    // Aoresenta modal 
                    jQuery('body')
                        .loadingModal('animation', 'rotatingPlane')
                        .loadingModal('backgroundColor', 'red')
                        .loadingModal('animation', 'wave')
                        .loadingModal('backgroundColor', '#387d01')
                        .loadingModal('color', 'black')
                        .loadingModal('text', 'Vídeo associado com sucesso :-)');
                }

                // remove a modal de loading
                delay(time).then(function() {
                    location.reload();
                    jQuery('body').loadingModal('destroy');
                });
            },
            error: function(err) {
                console.error('Ocorreu um erro ao associar midia...');
                console.error(err);
                jQuery('body').loadingModal('destroy');
                
            }
        });
    } else {
        console.error('Ocorreu um erro ao associar midia: Parametros obrigatórios não informados ');
        jQuery('body').loadingModal('destroy');
    }
}

// Formata data no padrão dd/MM/aaaa
function getFormattedDate(date) {
    var year = date.getFullYear();
    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;
    var day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;
    return day + '/' + month + '/' + year;
}

function timer() {
    'use strict';

    count = count - 1;
    minutes = checklength(Math.floor(count / 60));
    seconds = checklength(count - minutes * 60);
    var dataNovaAtualizacao = document.getElementById("dataNovaAtualizacao");

    if (count < 0) {
        clearInterval(counter);
        return;
    }

    if (dataNovaAtualizacao !== null && dataNovaAtualizacao !== undefined)
        dataNovaAtualizacao.innerHTML = minutes + ':' + seconds + 's';

    if (count === 0 && dataPesquisaUrlParam == null) {
        location.reload();
    }
}

function checklength(i) {
    'use strict';
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}

function getDateComHoraMinutoSegundo() {
    var date = new Date(),
        year = date.getFullYear(),
        month = (date.getMonth() + 1).toString(),
        formatedMonth = (month.length === 1) ? ("0" + month) : month,
        day = date.getDate().toString(),
        formatedDay = (day.length === 1) ? ("0" + day) : day,
        hour = date.getHours().toString(),
        formatedHour = (hour.length === 1) ? ("0" + hour) : hour,
        minute = date.getMinutes().toString(),
        formatedMinute = (minute.length === 1) ? ("0" + minute) : minute,
        second = date.getSeconds().toString(),
        formatedSecond = (second.length === 1) ? ("0" + second) : second;
    return formatedDay + "/" + formatedMonth + "/" + year + " " + formatedHour + ':' + formatedMinute + ':' + formatedSecond;
};

function getUrlParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}