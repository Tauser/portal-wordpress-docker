const CD_DEPUTADOS = "cd_deputados";

class TabelaDeputados {

    constructor() {
        this._idTabela = 'deputados-associados';
        this._tabela = this._criar();
        this._criarEventoAjaxTabela();
        this._criarAcoes();
    }

    get tabela() {
        return this._tabela;
    }

    _criar() {
        const dataFormPesquisa = {
            action: "deputados_associados",
            post_id: this._getUrlParameter('post')
        };
        return jQuery('#' + this._idTabela).DataTable({
            "ajax": { url: ajaxurl, dataType: "json", type: 'POST', data: dataFormPesquisa, dataSrc: "" },
            paging: false,
            ordering: false,
            searching: false,
            autoWidth: false,
            language: {
                infoEmpty: "Nenhum resultado encontrado",
                emptyTable: "Nenhum deputado associado",
                processing: "Por favor, aguarde...",
                loadingRecords: "Por favor, aguarde...",
            },
            columns: [
                {
                    data: "informacoes", "width": "20%", render: function (data, type, row) {

                        let info = "";

                        if (row.deputado != null) {

                            if (row.deputado.confirmado !== true) {
                                info += '<span class="regex">' + row.regex + '</span> link:<br/>';
                            }

                            if (!row.deputado.existe) {
                                info += "<span class='deputadoNaoExiste'>NÃO LOCALIZADO </span><label>Digite o nome: <label><input type='text' id='nomeDeputado' class='nomeDeputado' /><label>";
                            } else {
                                info += "<img class='dep-image' src='" + row.deputado.urlFoto + "'/>" + '<a href="https://www.camara.leg.br/deputados/' + row.deputado.id + '" target="_blank"><div class="nomeDeputado">' + row.deputado.nome + ' (' + row.deputado.partido + ') </a></div>';
                            }

                        } else {

                            info += '<span class="regex">' + row.regex + '</span> link:<br/>';

                            let combo = "<select id='comboNomeDeputado' class='comboNomeDeputado' style='width: 100%'>";
                            combo += "<option value=''>Selecione</option>";
                            for (let i = 0; i < row.opcoes.length; i++) {
                                combo += "<option value='" + JSON.stringify(row.opcoes[i]) + "' >" + "<span>" + row.opcoes[i].nome + ' (' + row.opcoes[i].partido + ') </span>' + "</option>";
                            }
                            combo += '</select>';
                            info += combo;
                        }
                        return info;
                    }
                },
                {
                    data: "acoes", render: function (data, type, row) {
                        if (row.deputado) {
                            if (row.deputado.confirmado && row.regex === null) {
                                return "<input type='button' class='button btn-remover-dep' value='Remover' />";
                            }
                            if (!row.deputado.existe) {
                                return "<input type='button' class='button btn-pesquisar-dep' value='Pesquisar' /> <span style='display:none;' id='loader' class='spinnerCustom loaderPesquisaDep'></span><span id='campoObrigatorio' class='msgCampoNomeObrigatorio' style='display:none;'>Campo nome é obrigatório</span>";
                            }
                            if (row.deputado.confirmado && row.regex !== null) {
                                return "";
                            }
                        }
                        return "<input type='button' class='button btn-confirmar-dep' value='Confirmar' /> <span id='selecaoObrigatoria' class='msgSelecaoObrigatoria' style='display:none;'>Selecione um deputado</span>";
                    }
                }
            ]
        });
    }

    _criarEventoAjaxTabela() {
        const tabelaDeputados = this;
        this._tabela.on('xhr', function (item) {
            const rows = tabelaDeputados._tabela.ajax.json();
            tabelaDeputados._atualizarIdsDeputadosParaSalvar(rows);
        });
    }

    _getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    }

    _criarAcoes() {
        const tabelaDeputados = this;
        this._tabela.on('draw', function () {
            tabelaDeputados._criarEventoPesquisarDeputadoNaoEncontrado(this);
            tabelaDeputados._criarEventoRemoverDeputado(this);
            tabelaDeputados._criarEventoConfirmar(this);
        });
    }

    _criarEventoRemoverDeputado(context) {
        const tabelaDeputados = this;
        jQuery(context).on('click', '.btn-remover-dep', function () {
            tabelaDeputados._tabela.row(jQuery(this).closest('tr')).remove().draw();
            const rows = tabelaDeputados._tabela.rows().data();
            tabelaDeputados._atualizarIdsDeputadosParaSalvar(rows);
        });
    }

    _criarEventoPesquisarDeputadoNaoEncontrado(context) {
        const tabelaDeputados = this;
        jQuery(context).on('click', '.btn-pesquisar-dep', function () {
            const contextRow = jQuery(tabelaDeputados._tabela.row(jQuery(this).closest('tr')).node());
            contextRow.find('#loader').attr('style', 'display:inline-block;');
            contextRow.find('#campoObrigatorio').attr('style', 'display:none;');
            if (!contextRow.find('#nomeDeputado').val()) {
                contextRow.find('#loader').attr('style', 'display:none;');
                contextRow.find('#campoObrigatorio').attr('style', 'display:inline-block;');
                return;
            }
            const row = tabelaDeputados._tabela.row(contextRow).data();
            const dataFormPesquisa = {
                action: "pesquisa_deputados_noticia",
                deputados: [contextRow.find('#nomeDeputado').val() + '-' + row.regex]
            };
            AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (deputados) => {
                let deputado = JSON.parse(deputados)[0];
                let rows = tabelaDeputados._tabela.rows().data();
                const index = tabelaDeputados._tabela.row(contextRow).index();
                rows[index] = deputado;
                tabelaDeputados._tabela.rows().remove();
                tabelaDeputados._tabela.rows.add(rows).draw(false);
            });
        });
    }

    _criarEventoConfirmar(context) {
        const tabelaDeputados = this;
        jQuery("#comboNomeDeputado").select2({
            templateResult: tabelaDeputados._formatOptionsComboDeputados
        });
        jQuery(context).on('click', '.btn-confirmar-dep', function () {
            const contextRow = jQuery(tabelaDeputados._tabela.row(jQuery(this).closest('tr')).node());
            let resultado = tabelaDeputados._tabela.row(contextRow).data();
            contextRow.find('#selecaoObrigatoria').attr('style', 'display:none;');
            if (contextRow.find('#comboNomeDeputado').length > 0 && !contextRow.find('#comboNomeDeputado').children("option:selected").val()) {
                contextRow.find('#selecaoObrigatoria').attr('style', 'display:inline-block;');
                return;
            }
            if (resultado.opcoes) {
                const teste = contextRow.find('#comboNomeDeputado').children("option:selected").val();
                if (teste) {
                    const deputado = JSON.parse(contextRow.find('#comboNomeDeputado').children("option:selected").val());
                    resultado.deputado = deputado;
                    resultado.opcao = null;
                } else {
                    contextRow.find('#selecaoObrigatoria').attr('style', 'display:inline-block;');
                    return;
                }
            } else {
                resultado = tabelaDeputados._tabela.row(contextRow).data();
            }
            let conteudo = tinyMCE.activeEditor.getContent();
            // E necessario manter o que o usuario digitou, ou seja, a regex (parametro) informada para a pesquisa.
            // conteudo = tabelaDeputados._replaceAll(conteudo, '[[' + resultado.regex + ']]', "<a href='" + resultado.deputado.link + "'>" + resultado.deputado.nome + " (" + resultado.deputado.partido + ")</a>");
            conteudo = tabelaDeputados._replaceAll(conteudo, '[[' + resultado.regex + ']]', "<a href='" + resultado.deputado.link + "'>" + resultado.regex + "</a>");
            tinyMCE.activeEditor.setContent(conteudo);
            tabelaDeputados._atualizarTabelaDepoisDaConfirmacao(tabelaDeputados, resultado);
        });
    }

    _escapeRegExp(str) {
        return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    }

    _replaceAll(str, find, replace) {
        return str.replace(new RegExp(this._escapeRegExp(find), 'g'), replace);
    }

    _atualizarTabelaDepoisDaConfirmacao(tabelaDeputados, resultado) {
        let rows = tabelaDeputados._tabela.rows().data();
        let deputadosAtualizados = [];
        for (let i = 0; i <= rows.length; i++) {
            const result = rows[i];
            if (result) {
                if (result.deputado && !result.deputado.confirmado && result.deputado.id === resultado.deputado.id) {
                    result.deputado.confirmado = true;
                }
                deputadosAtualizados.push(result);
            }
        }
        tabelaDeputados._tabela.rows().remove();
        tabelaDeputados._tabela.rows.add(deputadosAtualizados).draw(false);
        tabelaDeputados._atualizarIdsDeputadosParaSalvar(deputadosAtualizados);
    }

    _atualizarIdsDeputadosParaSalvar(deputados) {
        let deputadosConfirmados = '';
        for (let i in deputados) {
            if (deputados[i].deputado && deputados[i].deputado.confirmado && deputados[i].deputado.confirmado === true) {
                deputadosConfirmados = deputadosConfirmados + deputados[i].deputado.id + ",";
            }
        }
        deputadosConfirmados = deputadosConfirmados.substring(0, deputadosConfirmados.length - 1);
        jQuery("#" + CD_DEPUTADOS).val(deputadosConfirmados);
    }

    _formatOptionsComboDeputados(state) {
        if (!state.id) { return state.text; }
        const deputado = JSON.parse(state.id);
        var $state = jQuery("<div style='display: inline-block;'>" + deputado.nome + "</div>");
        return $state;
    }
}