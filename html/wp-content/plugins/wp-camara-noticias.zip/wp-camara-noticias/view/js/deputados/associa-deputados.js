class AssociaDeputados {

  constructor(tabelaDeputados) {
    this._criarEventoAssociaDeputados();
    this.tabela = tabelaDeputados.tabela;
  }

  _criarEventoAssociaDeputados() {
    const associaDeputados = this;
    jQuery("#btnAssociaDeputados").on('click', function (event) {

      jQuery("#btnAssociaDeputados").css('display', 'none');
      jQuery('#loaderAssociaDeputados').attr('style', 'display:inline-block;');
      AjaxPesquisa.pesquisa('POST', { action: "deputados_regex" }, (regex) => {
        let conteudo = tinyMCE.activeEditor.getContent();
        let deputados = conteudo.match(new RegExp(regex, "g"));
        event.preventDefault();
        const dataFormPesquisa = {
          action: "pesquisa_deputados_noticia",
          deputados: deputados
        };
        AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (resultados) => {
          if (resultados) {
            resultados = JSON.parse(resultados);
            let rows = associaDeputados.tabela.rows().data();
            rows = associaDeputados._removerCamposNaoConfirmados(rows);
            for (let i in resultados) {
              if (associaDeputados._verificarDeputadoNaoConfirmado(resultados[i], rows)) {
                rows.push(resultados[i]);
              }
            }
            associaDeputados.tabela.rows().remove();
            associaDeputados.tabela.rows.add(rows).draw(false);
            jQuery('#loaderAssociaDeputados').attr('style', 'display:none;');
            jQuery("#btnAssociaDeputados").css('display', 'block');
          }
        });
      });
    });
  }

  _removerCamposNaoConfirmados(rows) {
    return rows.filter(function (row) {
      return row.deputado && row.deputado.confirmado;
    });
  }

  _verificarDeputadoNaoConfirmado(resultado, rows) {
    let deputadoNaLista = false;
    for (let i in rows) {
      if (resultado.deputado === null && rows[i].deputado === null && rows[i].regex === resultado.regex) {
        deputadoNaLista = true;
        break;
      }
      if (resultado.deputado && !resultado.deputado.confirmado && rows[i].deputado && rows[i].deputado.nome === resultado.deputado.nome && rows[i].regex === resultado.regex) {
        deputadoNaLista = true;
        break;
      }
    }
    return deputadoNaLista ? false : true;

  }
}

jQuery(document).ready(function () {
  new AssociaDeputados(new TabelaDeputados());
});