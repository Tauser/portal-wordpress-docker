class AssociaProposicoes {

  constructor(tabelaProposicoes) {
    this._criarEventoAssociaProposicoes();
    this.tabela = tabelaProposicoes.tabela;
  }

  _criarEventoAssociaProposicoes() {
    const associaProposicoes = this;
    jQuery("#btnAssociaProposicoes").on('click', function (event) {
      // event.preventDefault();
      jQuery("#btnAssociaProposicoes").css('display', 'none');
      jQuery('#loaderAssociaProposicoes').attr('style', 'display:inline-block;');
      AjaxPesquisa.pesquisa('POST', {action: "proposicoes_regex"}, (regex) => {
        let conteudo = tinyMCE.activeEditor.getContent();
        let linksProposicao = jQuery(conteudo).find('.linkProposicao');
        linksProposicao.map((index, link) => {
          conteudo = conteudo.replace(jQuery(link).text(), '');
        });
        let proposicoes = conteudo.match(new RegExp(regex, "g"));
        const dataFormPesquisa = {
          action: "pesquisa_proposicoes_noticia",
          proposicoes: proposicoes
        };
        AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (resultados) => {
          if (resultados) {
            resultados = JSON.parse(resultados);
            let rows = associaProposicoes.tabela.rows().data();
            rows = associaProposicoes._removerCamposNaoConfirmados(rows);
            for (let i in resultados) {
              if (associaProposicoes._verificarProposicoesNaoConfirmadas(resultados[i], rows)) {
                rows.push(resultados[i]);
              }
            }
            associaProposicoes.tabela.rows().remove();
            associaProposicoes.tabela.rows.add(rows).draw(false);
            jQuery('#loaderAssociaProposicoes').attr('style', 'display:none;');
            jQuery("#btnAssociaProposicoes").css('display', 'block');
          }
        });
      });
    });
  }

  _removerCamposNaoConfirmados(rows) {
    return rows.filter(function (row) {
      return row.proposicao && row.proposicao.confirmado;
    });
  }

  _verificarProposicoesNaoConfirmadas(resultado, rows) {
    let proposicaoNaLista = false;
    for (let i in rows) {
      if (resultado.proposicao === null && rows[i].proposicao === null && rows[i].regex === resultado.regex) {
        proposicaoNaLista = true;
        break;
      }
      if (resultado.proposicao && !resultado.proposicao.confirmado && rows[i].proposicao && rows[i].proposicao.sigla === resultado.proposicao.sigla 
        && rows[i].proposicao.numero === resultado.proposicao.numero
        && rows[i].proposicao.ano === resultado.proposicao.ano
        && rows[i].regex === resultado.regex) {
        proposicaoNaLista = true;
        break;
      }
    }
    return proposicaoNaLista ? false : true;

  }
}

jQuery(document).ready(function () {
  new AssociaProposicoes(new TabelaProposicoes());
});