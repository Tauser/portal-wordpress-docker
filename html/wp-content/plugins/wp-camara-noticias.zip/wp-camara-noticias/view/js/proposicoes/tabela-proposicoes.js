const CD_PROPOSICOES = "cd_proposicoes";

class TabelaProposicoes {

    constructor() {
        this._idTabela = 'proposicoes-associadas';
        this._tabela = this._criar();
        this._criarEventoAjaxTabela();
        this._criarAcoes();
    }

    get tabela() {
        return this._tabela;
    }

    _criar() {
        const dataFormPesquisa = {
            action: "proposicoes_associadas",
            post_id: this._getUrlParameter('post')
        };
        const tabelaProposicoes = this;
        return jQuery('#' + tabelaProposicoes._idTabela).DataTable({
            "ajax": { url: ajaxurl, dataType: "json", type: 'POST', data: dataFormPesquisa, dataSrc: "" },
            paging: false,
            ordering: false,
            searching: false,
            language: {
                infoEmpty: "Nenhum resultado encontrado",
                emptyTable: "Nenhuma proposição associada",
                processing: "Por favor, aguarde...",
                loadingRecords: "Por favor, aguarde...",
            },
            columns: [
                {
                    data: "informacoes", "width": "50%", render: function (data, type, row, meta) {

                        let info = "";

                        if (row.proposicao != null) {

                            if (row.proposicao.confirmado !== true) {

                                const propsicao_teste = row.proposicao.sigla + ' ' + row.proposicao.numero + '/' + row.proposicao.ano;

                                if (row.regex != propsicao_teste) {
                                    info += "<span class='titulo-prop'><span class='regex'>" + row.regex + "</span> link:<br/></span>";
                                }

                            }

                            if (!row.proposicao.existe) {
                                info += "<span class='proposicaoNaoExiste'>NÃO LOCALIZADO </span><label>Digite a proposição: <label><input type='text' id='proposicaoCompleta' class='proposicaoCompleta' /><label>";
                            } else {
                                info += "<span class='proposicaoCompleta'><b><a href='https://www.camara.leg.br/proposicoesWeb/fichadetramitacao?idProposicao=" + row.proposicao.id + "' target='_blank'>" + row.proposicao.sigla + ' ' + row.proposicao.numero + '/' + row.proposicao.ano + '</a></b></span>';
                            }

                        } else {

                            info += "<span class='titulo-prop'><span class='regex'>" + row.regex + "</span> link:<br/></span>";

                            let combo = "<select id='comboProposicao' class='comboProposicao' style='width: 100%'>";

                            combo += "<option value=''>Selecione</option>";

                            for (let i = 0; i < row.opcoes.length; i++) {
                                combo += "<option value='" + JSON.stringify(row.opcoes[i]) + "' >" + "<span>" + row.opcoes[i].sigla + ' ' + row.opcoes[i].numero + '/' + row.opcoes[i].ano + '</span>' + "</option>";
                            }

                            combo += '</select>';

                            info += combo;
                        }
                        return info;
                    }
                },
                {
                    data: "acoes", render: function (data, type, row, meta) {
                        if (row.proposicao) {
                            if (row.proposicao.confirmado && row.regex === null) {
                                return "<input type='button' class='button btn-remover-prop' value='Remover' />";
                            }
                            if (!row.proposicao.existe) {
                                return "<input type='button' class='button btn-pesquisar-prop' value='Pesquisar' /> <span style='display:none;'  id='loader' class='spinnerCustom loaderPesquisaProp'></span><span id='campoObrigatorio' class='msgCampoObrigatorio' style='display:none;'>Campo proposição é obrigatório</span>";
                            }
                            if (row.proposicao.confirmado && row.regex !== null) {
                                return "";
                            }
                        }
                        let rowIndex = meta.row + 1;

                        jQuery('#' + tabelaProposicoes._idTabela + ' tbody tr:nth-child(' + rowIndex + ')').addClass('red');

                        return "<input type='button' class='button btn-confirmar-prop' value='Confirmar' /> <span id='selecaoObrigatoria' class='msgSelecaoObrigatoria' style='display:none;'>Selecione uma proposição</span>";
                    }
                }
            ]
        });
    }

    _criarEventoAjaxTabela() {
        const tabelaProposicoes = this;
        this._tabela.on('xhr', function (item) {
            const rows = tabelaProposicoes._tabela.ajax.json();
            tabelaProposicoes._atualizarIdsParaSalvar(rows);
        });
    }

    _getUrlParameter(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
            }
        }
    }

    _criarAcoes() {
        const tabelaProposicoes = this;
        this.tabela.on('draw', function () {
            tabelaProposicoes._criarEventoConfirmar(this);
            tabelaProposicoes._criarEventoPesquisarProposicaoNaoEncontrada(this);
            tabelaProposicoes._criarEventoRemoverProposicao(this);
        });
    }

    _criarEventoRemoverProposicao(context) {
        const tabelaProposicoes = this;
        jQuery(context).on('click', '.btn-remover-prop', function () {
            tabelaProposicoes._tabela.row(jQuery(this).closest('tr')).remove().draw();
            const rows = tabelaProposicoes._tabela.rows().data();
            tabelaProposicoes._atualizarIdsParaSalvar(rows);
        });
    }

    _criarEventoPesquisarProposicaoNaoEncontrada(context) {
        const tabelaProposicoes = this;
        jQuery(context).on('click', '.btn-pesquisar-prop', function () {
            const contextRow = jQuery(tabelaProposicoes._tabela.row(jQuery(this).closest('tr')).node());
            jQuery(contextRow).find('#loader').attr('style', 'display:inline-block;');
            jQuery(contextRow).find('#campoObrigatorio').attr('style', 'display:none;');
            if (!jQuery(contextRow).find('#proposicaoCompleta').val()) {
                jQuery(contextRow).find('#loader').attr('style', 'display:none;');
                jQuery(contextRow).find('#campoObrigatorio').attr('style', 'display:inline-block;');
                return;
            }
            const row = tabelaProposicoes._tabela.row(jQuery(contextRow)).data();
            const dataFormPesquisa = {
                action: "pesquisa_proposicoes_noticia",
                proposicoes: [jQuery(contextRow).find('#proposicaoCompleta').val() + '-' + row.regex]
            };
            AjaxPesquisa.pesquisa('POST', dataFormPesquisa, (proposicoes) => {
                let proposicao = JSON.parse(proposicoes)[0];
                let rows = tabelaProposicoes._tabela.rows().data();
                const index = tabelaProposicoes._tabela.row(jQuery(contextRow)).index();
                rows[index] = proposicao;
                tabelaProposicoes._tabela.rows().remove();
                tabelaProposicoes._tabela.rows.add(rows).draw(false);
            });
        });
    }

    _criarEventoConfirmar(context) {
        const tabelaProposicoes = this;
        jQuery("#comboProposicao").select2();
        jQuery(context).on('click', '.btn-confirmar-prop', function () {
            const contextRow = jQuery(tabelaProposicoes._tabela.row(jQuery(this).closest('tr')).node());
            let resultado = tabelaProposicoes._tabela.row(jQuery(this).parents('tr')).data();
            jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:none;');
            if (jQuery(contextRow).find('#comboProposicao').length > 0 && !jQuery(this).parents('tr').find('#comboProposicao').children("option:selected").val()) {
                jQuery(contextRow).find('#selecaoObrigatoria').attr('style', 'display:inline-block;');
                return;
            }
            if (resultado.opcoes) {
                const proposicao = JSON.parse(jQuery(contextRow).find('#comboProposicao').children("option:selected").val());
                resultado.proposicao = proposicao;
                resultado.opcao = null;
            } else {
                resultado = tabelaProposicoes._tabela.row(jQuery(contextRow)).data();
            }
            let conteudo = tinyMCE.activeEditor.getContent();
            // E necessario manter o que o usuario digitou, ou seja, a regex (parametro) informada para a pesquisa.
            // conteudo = tabelaProposicoes._replaceAll(conteudo, resultado.regex, "<a class='linkProposicao' href='" + resultado.proposicao.link + "'>" + resultado.proposicao.sigla + ' ' + resultado.proposicao.numero + '/' + resultado.proposicao.ano + "</a>");
            conteudo = tabelaProposicoes._replaceAll(conteudo, resultado.regex, "<a class='linkProposicao' href='" + resultado.proposicao.link + "'>" + resultado.regex + "</a>");
            tinyMCE.activeEditor.setContent(conteudo, { format: 'html' });
            tabelaProposicoes._atualizarTabelaDepoisDaConfirmacao(tabelaProposicoes, resultado);
        });
    }

    _escapeRegExp(str) {
        return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    }

    _replaceAll(str, find, replace) {
        return str.replace(new RegExp(this._escapeRegExp(find), 'g'), replace);
    }

    _atualizarTabelaDepoisDaConfirmacao(tabelaProposicoes, resultado) {
        let rows = tabelaProposicoes._tabela.rows().data();
        let proposicoesAtualizados = [];
        for (let i = 0; i <= rows.length; i++) {
            const result = rows[i];
            if (result) {
                if (result.proposicao && !result.proposicao.confirmado && result.proposicao.id === resultado.proposicao.id) {
                    result.proposicao.confirmado = true;
                }
                proposicoesAtualizados.push(result);
            }
        }
        tabelaProposicoes._tabela.rows().remove();
        tabelaProposicoes._tabela.rows.add(proposicoesAtualizados).draw(false);
        tabelaProposicoes._atualizarIdsParaSalvar(proposicoesAtualizados);
    }

    _atualizarIdsParaSalvar(proposicoes) {
        let proposicoesConfirmadas = '';
        for (let i in proposicoes) {
            if (proposicoes[i].proposicao && proposicoes[i].proposicao.confirmado && proposicoes[i].proposicao.confirmado === true) {
                proposicoesConfirmadas = proposicoesConfirmadas + proposicoes[i].proposicao.id + ",";
            }
        }
        proposicoesConfirmadas = proposicoesConfirmadas.substring(0, proposicoesConfirmadas.length - 1);
        jQuery("#" + CD_PROPOSICOES).val(proposicoesConfirmadas);
    }

}