<?php require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
use noticias\mapeamento\CamposDB as CamposDB;
?>

<div class="tab1">
    <table id="resumo" class="field-table resumo">
        <tr>
            <td>
                <div>
                    <label>Resumo:</label><br>
                    <textarea class="text-area-fields" style="resize: none;" id="excerpt" name="excerpt" rows="2" cols="40" data-label="Resumo" id="excerpt"><?php echo $this->noticia->getResumo() ?></textarea>
                    <div class="qtd-caracteres">(<span id="resumo-qtd-c"></span> caracteres)</div>
                </div>
            </td>
        </tr>
    </table>
    <table id="rodape" class="field-table rodape">
        <tr>
            <td>
                <div style="width: 100%;">
                    <label>Rodapé:</label><br>
                    <textarea class="text-area-fields" style="resize: none;" name="<?= CamposDB::CD_NOTICIA_RODAPE ?>" rows="1" cols="40" data-label="Rodapé" id="<?= CamposDB::CD_NOTICIA_RODAPE ?>"><?php echo $this->noticia->getRodape() ?></textarea>
                </div>
            </td>
        </tr>
    </table>

</div>

<div class="tab2">

    <table id="tags" class="field-table tags">
        <tr>
            <td>
              <div>
                <!-- Form com campo para inserir uma nova tag -- campo hidden guarda valor da tag para inserir -->
                <form class="form-inline oculta" role="form" method="POST" action="#">
                <input type="hidden" name="<?php echo 'cd_novaTag' ?>" id="<?php echo 'cd_novaTag' ?>" />
                </form>
                <label for="<?= CamposDB::CD_NOTICIA_TAGS ?>"><b>Tags</b>:</label><br>
                <select name="<?= CamposDB::CD_NOTICIA_TAGS ?>[]" id="<?= CamposDB::CD_NOTICIA_TAGS ?>" multiple="multiple" style="width: 100%;">
                    <?php 
                        foreach ($this->noticia->getTags() as $tag) :
                              echo "<option selected='selected' value=\"$tag->id\" >$tag->titulo</option>";
                        endforeach; 
                    ?>
                </select>
              </div>
            </td>
        </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
     <tr>
      <td>
        <div class="tb-container">
           <div class="conteudo-relacionado">
                <table>
                  <tr>
                    <td><div class="box-titulo"><b>Continuação da Notícia</b></div></td>
                    <td class="td-associar">
                        <button class="button add_media" type="button" onclick="open_dlg_continuacao()">Associar</button>
                    </td>
                  <tr>
                </table>
                <input type="hidden" name="<?php echo CamposDB::CD_NOTICIA_CONTINUACAO ?>" id="<?php echo CamposDB::CD_NOTICIA_CONTINUACAO ?>" />
                <input type="hidden" name="post_id" id="post_id" value="<?php echo get_the_ID() ?>" />
                <table id="grid-continuacao" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
       </td>
      </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
     <tr>
      <td>
        <div class="tb-container">
            <div class="conteudo-relacionado">
                <table>
                  <tr>
                    <td><div class="box-titulo"><b>Conteúdo Relacionado</b></div></td>
                    <td class="td-associar"><button class="button add_media" type="button" onclick="open_dlg_associar()">Associar</button></td>
                  <tr>
                </table>
                <input type="hidden" name="<?php echo CamposDB::CD_NOTICIA_RELACIONADA ?>" id="<?php echo CamposDB::CD_NOTICIA_RELACIONADA ?>" />
                <!-- Campo para controle  -->
                <input type="hidden" name="post_id" id="post_id" value="<?php echo get_the_ID() ?>" />
                <table id="grid-relacionadas" class="display">
                    <thead>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
       </td>
      </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
     <tr>
      <td>
        <div class="tb-container">
           <div class="conteudo-relacionado">
                <table>
                  <tr>
                    <td>
                      <div class="box-titulo"><b>Deputados</b></div>
                    </td>
                    <td class="td-associar">
                       <button class="button add_media" type="button" id="btnAssociaDeputados">Procurar</button>
                       <span id="loaderAssociaDeputados" style="display:none;" class="spinnerCustom"></span>
                    </td>
                  <tr>
                </table>
                <input type="hidden" name="<?php echo CamposDB::CD_DEPUTADOS ?>" id="<?php echo CamposDB::CD_DEPUTADOS ?>" />
                <table id="deputados-associados" class="display" style="width:100%">
                  <thead>
                      <tr>
                        <th></th>
                        <th></th>
                      </tr>
                  </thead>
                </table>
            </div>
        </div>
       </td>
      </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
     <tr>
      <td>
        <div class="tb-container">
           <div class="conteudo-relacionado">
                <table>
                  <tr>
                    <td><div class="box-titulo"><b>Proposições</b></div></td>
                    <td class="td-associar">
                        <button class="button add_media" type="button" id="btnAssociaProposicoes">Procurar</button>
                        <span id="loaderAssociaProposicoes" style="display:none;" class="spinnerCustom"></span>
                    </td>
                  <tr>
                </table>
                <input type="hidden" name="<?php echo CamposDB::CD_PROPOSICOES ?>" id="<?php echo CamposDB::CD_PROPOSICOES ?>" />
                <table id="proposicoes-associadas" class="display" style="width:100%">
                    <thead>
                        <tr>
                          <th></th>
                          <th></th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
       </td>
      </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
     <tr>
      <td>
        <div class="tb-container">
           <div class="conteudo-relacionado">
                <table>
                  <tr>
                    <td>
                        <div class="box-titulo"><b>Leis</b></div>
                    </td>
                    <td class="td-associar">
                        <button class="button add_media" type="button" id="btnAssociaLegislacoes">Procurar</button>
                        <span id="loaderAssociaLegislacoes" style="display:none;" class="spinnerCustom"></span>
                    </td>
                  <tr>
                </table>
                <input type="hidden" name="<?php echo CamposDB::CD_LEGISLACOES ?>" id="<?php echo CamposDB::CD_LEGISLACOES ?>" />
               <table id="legislacoes-associadas" class="display" style="width:100%">
                 <thead>
                   <tr>
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
               </table>
            </div>
        </div>
       </td>
      </tr>
    </table>

    <table id="tabela-conteudo-relacionado" class="field-table tabela-conteudo-relacionado">
     <tr>
      <td>
        <div class="tb-container">
           <div class="conteudo-relacionado">
                <table>
                  <tr>
                    <td>
                        <div class="box-titulo"><b>Glossários</b></div>
                    </td>
                    <td class="td-associar">
                        <button class="button add_media" type="button" id="btnAssociaGlossarios">Procurar</button>
                        <span id="loaderAssociaGlossarios" style="display:none;" class="spinnerCustom"></span>
                    </td>
                  <tr>
                </table>
                    <table id="glossarios-associados" class="display" style="width:100%">
                      <thead>
                        <tr>
                            <th></th>
                            <th></th>
                        </tr>
                      </thead>
                   </table>
            </div>
        </div>
       </td>
      </tr>
    </table>

</div>