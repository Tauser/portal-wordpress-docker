<?php require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php'); 
use noticias\mapeamento\CamposDB as CamposDB;
?>
<div class="data-modificacao">
    <span id="timestamp">
        <label for="<?php echo CamposDB::CD_NOTICIA_DATA_ATUALIZACAO ?>"><b>Data de atualização:</b></label>
        <input type="date" style="width: 150px;" id="<?= CamposDB::CD_NOTICIA_DATA_ATUALIZACAO ?>" value="<?= $this->noticia->getDataAtualizacao() ?>" name="<?= CamposDB::CD_NOTICIA_DATA_ATUALIZACAO ?>">
        <input type="text" name="<?= CamposDB::CD_NOTICIA_HORA_ATUALIZACAO ?>" value="<?= $this->noticia->getHoraAtualizacao() ?>" id="<?php echo CamposDB::CD_NOTICIA_HORA_ATUALIZACAO ?>"
            onfocus="javascript: InputTextMask.processMaskFocus(this, '99:99', true);" style="width: 50px;" />
    </span>
</div>

<div class="tema-principal">
        <label for="<?= CamposDB::CD_NOTICIA_TEMA_PRINCIPAL ?>" class="required"><b>Tema Principal: </b></label><br>
        <select id="<?= CamposDB::CD_NOTICIA_TEMA_PRINCIPAL ?>" name="<?= CamposDB::CD_NOTICIA_TEMA_PRINCIPAL ?>" style="width: 100%">
        <option value="">Selecione</option>
        <?php foreach ($this->getTemas() as $tema) :
            if ($this->noticia->getTemaPrincipal() && $this->noticia->getTemaPrincipal()->id == $tema->id) {
                echo "<option selected='selected' value=\"$tema->id\" >$tema->titulo</option>";
            } else {
                echo "<option value=\"$tema->id\" >$tema->titulo</option>";
            }
        endforeach; ?>
    </select>
</div>
<div class="outros-temas">
    <label style="margin-left: 5px;" for="<?= CamposDB::CD_NOTICIA_TEMAS ?>"><b>Outros temas: </b></label><br>
       <select name="<?= CamposDB::CD_NOTICIA_TEMAS ?>[]" id="<?= CamposDB::CD_NOTICIA_TEMAS ?>" multiple="multiple" style="width: 100%">
        <?php foreach ($this->getTemas() as $tema) :
            if (in_array($tema, $this->noticia->getTemas())) {
                echo "<option selected='selected' value=\"$tema->id\" >$tema->titulo</option>";
            } else {
                echo "<option value=\"$tema->id\" >$tema->titulo</option>";
            }
        endforeach; ?>
    </select>
</div>

<div class="misc-pub-section curtime misc-pub-curtime publish-visibility-option">
    <input type="checkbox" name="<?= CamposDB::CD_NOTICIA_VISIVEL_HOME ?>" <?=$this->noticia->getVisivelHome() == 'true' ? 'checked' : '' ?>>
    <label>Visível na Home</label>
</div>
<div class="misc-pub-section curtime misc-pub-curtime publish-visibility-option">
    <input type="checkbox" name="<?= CamposDB::CD_NOTICIA_VISIVEL_BOLETIM ?>" <?=$this->noticia->getVisivelBoletim() == 'true' ? 'checked' : ''?>>
    <label>Visível no Boletim</label>
</div>
<div class="misc-pub-section curtime misc-pub-curtime publish-visibility-option">
    <input type="checkbox" name="<?= CamposDB::CD_NOTICIA_PORTAL_CONGRESSO ?>" <?=$this->noticia->getNoticiaPortalCongresso() == 'true' ? 'checked' : ''?>>
    <label>Visível no Portal do Congresso</label>
</div>