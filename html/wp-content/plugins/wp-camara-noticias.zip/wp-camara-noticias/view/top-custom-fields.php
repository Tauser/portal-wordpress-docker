<div class="editor-tabs">

  <input id="tab1" type="radio" name="tabs" checked>
  <label for="tab1">Conteúdo Principal</label>

  <input id="tab2" type="radio" name="tabs">
  <label for="tab2">Associações</label>

  <input id="tab3" type="radio" name="tabs">
  <label for="tab3">Mídias</label>

  <input id="tab4" type="radio" name="tabs">
  <label for="tab4">Revisões e Comentários</label>

  <section id="content1"></section>
  <section id="content2"></section>
  <section id="content3"></section>
  <section id="content4"></section>

</div>