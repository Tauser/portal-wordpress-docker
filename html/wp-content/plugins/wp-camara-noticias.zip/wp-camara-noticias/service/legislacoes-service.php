<?php namespace noticias\service;

require_once(plugin_dir_path(__FILE__) . '../domain/legislacao.php');
require_once(plugin_dir_path(__FILE__) . '../domain/resultado-pesquisa-legislacoes.php');

use noticias\domain\Legislacao as Legislacao;
use noticias\domain\ResultadoPesquisaLegislacoes as ResultadoPesquisaLegislacoes;



class LegislacoesService
{

    const URL_LEGIN = 'https://www.camara.leg.br/wslegislacao/legado/normas?formato=json&tipo=lei';

    public function retornar_regex_legislacoes()
    {

        return Legislacao::REGEX;
    }

    public function pesquisa_legislacoes_por_id($ids)
    {

        $result = $this->exec_url(self::URL_LEGIN . '&' . $ids);
        $legislacoes = array();
        if ($result && sizeof($result) > 0) {
            foreach ($result as $dado) {
                array_push($legislacoes,  new ResultadoPesquisaLegislacoes(null, new Legislacao(
                    $dado->id,
                    $dado->numero,
                    $dado->ano,
                    $dado->urlPublicacao,
                    true,
                    true
                ), null));
            }
        }
        return $legislacoes;
    }

    public function pesquisar_legislacoes($legs)
    {
        $regex_sem_resultado = null;
        if (sizeof($legs) == 1 && strpos($legs[0], '-')) {
            $str_array = explode('-', $legs[0]);
            $regex_sem_resultado = $str_array[1];
            $legs[0] = $str_array[0];
        }
        $legislacoes = array();
        foreach ($legs as $leg) {
            $arrayLeg = explode("/", $leg);
            $ano = $arrayLeg[1];
            $siglaENumero = explode(" ", $arrayLeg[0]);
            $numero = str_replace('.', '', $siglaENumero[1]);
            $url = self::URL_LEGIN . '&numero=' . $numero . '&ano=' . $ano;
            $legislacoes = $this->pesquisar($url, $legislacoes, $leg, $numero, $regex_sem_resultado);
        }
        return $legislacoes;
    }

    private function pesquisar($url, $legislacoes, $legislacao, $numero, $regex_sem_resultado)
    {
        $qtdConsultas = 0;
        while ($qtdConsultas < 2) {
            if ($qtdConsultas == 1) {
                // Sigla + Numero
                $url = self::URL_LEGIN . '&numero=' . $numero;
            }
            $result = $this->exec_url($url);
            if ($result) {
                $legislacoes = $this->adiciona_legislacao($legislacoes, $result, $regex_sem_resultado, $legislacao);
                break;
            }
            $qtdConsultas++;
        }
        if (!$result) {
            array_push($legislacoes, new ResultadoPesquisaLegislacoes($regex_sem_resultado == null ? $legislacao : $regex_sem_resultado, new Legislacao(null, $legislacao, null, null, false, false), null));
        }
        return $legislacoes;
    }

    private function adiciona_legislacao($legislacoes, $result, $regex_sem_resultado, $legislacao)
    {
        if ($result && sizeof($result) == 1) {
            $dado = $result[0];
            array_push($legislacoes,  new ResultadoPesquisaLegislacoes($regex_sem_resultado == null ? $legislacao : $regex_sem_resultado, new Legislacao(
                $dado->id,
                $dado->numero,
                $dado->ano,
                $dado->urlPublicacao,
                true,
                false
            ), null));
        } else {
            $opcoesProposicoes = array();
            foreach ($result as $dado) {
                array_push($opcoesProposicoes, new Legislacao(
                    $dado->id,
                    $dado->numero,
                    $dado->ano,
                    $dado->urlPublicacao,
                    true,
                    false
                ));
            }
            array_push($legislacoes, new ResultadoPesquisaLegislacoes($regex_sem_resultado == null ? $legislacao : $regex_sem_resultado, null, $opcoesProposicoes));
        }
        return $legislacoes;
    }

    private function exec_url($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, str_replace(" ", "%20", $url)); //Url together with parameters
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13");
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        $resultado = json_decode(curl_exec($ch));
        curl_close($ch);
        return $resultado;
    }
}
