<?php namespace noticias\service;

require_once(plugin_dir_path(__FILE__) . '../domain/glossario.php');
require_once(plugin_dir_path(__FILE__) . '../domain/resultado-pesquisa-glossario.php');

use noticias\domain\Glossario as Glossario;
use noticias\domain\ResultadoPesquisaGlossario as ResultadoPesquisaGlossario;



class GlossarioService
{

    public function retornar_regex_glossario()
    {
        return Glossario::REGEX;
    }

    public function pesquisar($palavras)
    {
        $regex_sem_resultado = null;
        if (sizeof($palavras) == 1 && strpos($palavras[0], '-')) {
            $str_array = explode('-', $palavras[0]);
            $regex_sem_resultado = $str_array[1];
            $palavras[0] = $str_array[0];
        }
        $glossarios = array();
        foreach ($palavras as $palavra) {
            $palavra = str_replace('g', '', $palavra);
            $args = array(
                'taxonomy' => 'glossario',
                'hide_empty' => false,
                'orderby' => 'name',
                'order' => 'ASC',
                'search' => trim($palavra)
            );
            $terms = get_terms($args);
            if (!$terms || sizeof($terms) == 0) {
                array_push($glossarios, new ResultadoPesquisaGlossario($regex_sem_resultado == null ? $palavra : $regex_sem_resultado, new Glossario(null, $palavra, null, false, false), null));
            } else {
                if (sizeof($terms) == 1) {
                    foreach ($terms as $term) {
                        array_push($glossarios, new ResultadoPesquisaGlossario($regex_sem_resultado == null ? $palavra : $regex_sem_resultado, new Glossario($term->term_id, $term->name, $term->description, true, false), null));
                    }
                } else {
                    $opcoesGlossario = array();
                    foreach ($terms as $term) {
                        array_push($opcoesGlossario, new Glossario(
                            $term->term_id,
                            $term->name,
                            $term->description,
                            true,
                            false
                        ));
                    }
                    array_push($glossarios, new ResultadoPesquisaGlossario($regex_sem_resultado == null ? $palavra : $regex_sem_resultado, null, $opcoesGlossario));
                }
            }
        }
        return $glossarios;
    }
}
