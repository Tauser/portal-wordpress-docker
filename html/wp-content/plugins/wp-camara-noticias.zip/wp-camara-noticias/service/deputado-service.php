<?php namespace noticias\service;

require_once(plugin_dir_path(__FILE__) . '../domain/deputado.php');
require_once(plugin_dir_path(__FILE__) . '../domain/resultado-pesquisa-deputado.php');

use noticias\domain\Deputado as Deputado;
use noticias\domain\ResultadoPesquisaDeputado as ResultadoPesquisaDeputado;



class DeputadoService
{

    const URL_DADOS_ABERTOS = 'https://dadosabertos.camara.leg.br/api/v2/deputados';

    public function retornar_regex_deputados()
    {
        return Deputado::REGEX;
    }

    public function pesquisa_deputados_por_id($ids)
    {

        $result = $this->exec_url(self::URL_DADOS_ABERTOS . '?' . $ids);
        $deputados = array();
        if ($result->dados && sizeof($result->dados) > 0) {
            foreach ($result->dados as $dado) {
                array_push($deputados,  new ResultadoPesquisaDeputado(null, new Deputado(
                    $dado->id,
                    $dado->nome,
                    $dado->siglaPartido,
                    $dado->siglaUf,
                    $dado->urlFoto,
                    true,
                    true
                ), null));
            }
        }
        return $deputados;
    }

    public function pesquisar_deputados($nomes)
    {
        $regex_sem_resultado = null;
        if (sizeof($nomes) == 1 && strpos($nomes[0], '-')) {
            $str_array = explode('-', $nomes[0]);
            $regex_sem_resultado = $str_array[1];
            $nomes[0] = $str_array[0];
        }
        $deputados = array();
        foreach ($nomes as $nome) {
            $result = $this->exec_url(self::URL_DADOS_ABERTOS . '?nome=' . urlencode($nome));
            if ($result->dados) {
                $deputados = $this->adiciona_deputados($deputados, $result, $regex_sem_resultado, $nome);
            } else {
                array_push($deputados, new ResultadoPesquisaDeputado($regex_sem_resultado == null ? $nome : $regex_sem_resultado, new Deputado(null, $nome, null, null, null, false, false), null));
            }
        }
        return $deputados;
    }

    private function adiciona_deputados($deputados, $result, $regex_sem_resultado, $nome) {
        if (sizeof($result->dados) == 1) {
            $dado = $result->dados[0];
            array_push($deputados,  new ResultadoPesquisaDeputado($regex_sem_resultado == null ? $nome : $regex_sem_resultado, new Deputado(
                $dado->id,
                $dado->nome,
                $dado->siglaPartido,
                $dado->siglaUf,
                $dado->urlFoto,
                true,
                false
            ), null));
        } else {
            $opcoesDeputados = array();
            foreach ($result->dados as $dado) {
                array_push($opcoesDeputados, new Deputado(
                    $dado->id,
                    $dado->nome,
                    $dado->siglaPartido,
                    $dado->siglaUf,
                    $dado->urlFoto,
                    true,
                    false
                ));
            }
            array_push($deputados, new ResultadoPesquisaDeputado($regex_sem_resultado == null ? $nome : $regex_sem_resultado, null, $opcoesDeputados));
        }
        return $deputados;
    }

    private function exec_url($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); //Url together with parameters
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('accept:application/json'));
        $resultado = json_decode(curl_exec($ch));
        curl_close($ch);
        return $resultado;
    }
}
