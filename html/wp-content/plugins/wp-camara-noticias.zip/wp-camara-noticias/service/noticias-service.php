<?php namespace noticias\service;

require_once(plugin_dir_path(__FILE__) . '../mapeamento/campos.php');
require_once(plugin_dir_path(__FILE__) . '../domain/tema-agencia.php');
require_once(plugin_dir_path(__FILE__) . '../domain/noticia-agencia.php');
require_once(plugin_dir_path(__FILE__) . '../domain/relacionada.php');
require_once(plugin_dir_path(__FILE__) . '../domain/deputado.php');
require_once(plugin_dir_path(__FILE__) . '../domain/continuacao.php');
require_once(plugin_dir_path(__FILE__) . '../util/validator-util.php');
require_once(plugin_dir_path(__FILE__) . '../domain/tags.php');

use noticias\mapeamento\CamposDB as CamposDB;
use noticias\domain\TemaAgencia as TemaAgencia;
use noticias\domain\NoticiaAgencia as NoticiaAgencia;
use noticias\domain\Relacionada as Relacionada;
use noticias\domain\Continuacao as Continuacao;
use noticias\domain\Tags as Tags;
use noticias\domain\Deputado as Deputado;
use noticias\config\ConfigPlugin as ConfigPlugin;
use noticias\util\ValidationUtil as ValidationUtil;

class NoticiasService
{
    private $validationUtil;
    private $taxonomyTags = 'post_tag';
    const TAXONOMY_TEMA_DO_DIA = 'tema_do_dia';

    public function __construct($deputadoService, $proposicaoService, $legislacoesService) {
        $this->deputadoService = $deputadoService;
        $this->proposicaoService = $proposicaoService;
        $this->legislacoesService = $legislacoesService;
        $this->validationUtil = new ValidationUtil();   
    }

    public function get_legislacoes($postId, $field)
    {
        $ids = get_post_meta($postId, $field, false);
        $legislacoes = array();
        $params = '';
        foreach ($ids as $id) {
            $params = $params . 'id=' . $id . '&';
        }
        $params = substr_replace($params ,"",-1);
        if($params != '') {
            $legislacoes = $this->legislacoesService->pesquisa_legislacoes_por_id($params);
        }
        return $legislacoes;
    }
    
    public function get_proposicoes($postId, $field)
    {
        $ids = get_post_meta($postId, $field, false);
        $proposicoes = array();
        $params = '';
        foreach ($ids as $id) {
            $params = $params . 'id=' . $id . '&';
        }
        $params = substr_replace($params ,"",-1);
        if($params != '') {
            $proposicoes = $this->proposicaoService->pesquisa_proposicoes_por_id($params);
        }
        return $proposicoes;
    }

    public function get_deputados($postId, $field)
    {
        $ids = get_post_meta($postId, $field, false);
        $deputados = array();
        $params = '';
        foreach ($ids as $id) {
            if ($id->deputado instanceof Deputado)
                $id = $id->deputado->getId();
            $params = $params . 'id=' . $id . '&';
        }
        $params = substr_replace($params ,"",-1);
        if($params != '') {
            $deputados = $this->deputadoService->pesquisa_deputados_por_id($params);
        }
        return $deputados;
    }

    public function get_relacionadas($postId, $field)
    {
        $ids = get_post_meta($postId, $field, false);
        $posts = array('data' => array(), 'ids' => array());
        foreach ($ids as $id) {
            $post = get_post($id);
            $imagens = dsc_obter_imagem_destaque_post($post->ID);
            if( $imagens ) {
                $thumbnail_url = $imagens['sizes'][0]['url'];
            } else {
                $thumbnail_url = null;
            }
            
            $postType = get_post_type_object( $post->post_type );
            $resumo = wp_strip_all_tags(get_post_meta($post->ID, 'resumo', true));

            $obj = new Relacionada(
                $post->ID,  
                $post->post_title, 
                $post->post_date,
                $thumbnail_url,
                $resumo,
                $postType->label
            );
            array_push($posts['data'], $obj);
            array_push($posts['ids'], $obj->getId());
        }
        return $posts;
    }

    public function get_continuacao($postId, $field)
    {
        $ids = get_post_meta($postId, $field, false);
        $posts = array('data' => array());
        foreach ($ids as $id) {

            if (!is_array($id)) {
                $post = get_post($id);
                $imagens = dsc_obter_imagem_destaque_post($post->ID);
                if( $imagens ) {
                    $thumbnail_url = $imagens['sizes'][0]['url'];
                } else {
                    $thumbnail_url = null;
                }
                $postType = get_post_type_object( $post->post_type );
                $resumo = wp_strip_all_tags(get_post_meta($post->ID, 'resumo', true));
    
                $obj = new Continuacao(
                    $post->ID,  
                    $post->post_title, 
                    $post->post_date,
                    $thumbnail_url,
                    $resumo,
                    $postType->label
                );
                array_push($posts['data'], $obj);
            }

            if (is_array($id) && sizeof($id) > 0) {

                foreach ($id as $continuacao) {
                    if ($continuacao instanceof Continuacao)
                        $continuacaoId = $continuacao->getId();

                    $post = get_post($continuacaoId);
                    $imagens = dsc_obter_imagem_destaque_post($post->ID);
                    if( $imagens ) {
                        $thumbnail_url = $imagens['sizes'][0]['url'];
                    } else {
                        $thumbnail_url = null;
                    }
                    $postType = get_post_type_object( $post->post_type );
                    $resumo = wp_strip_all_tags(get_post_meta($post->ID, 'resumo', true));
        
                    $obj = new Continuacao(
                        $post->ID,  
                        $post->post_title, 
                        $post->post_date,
                        $thumbnail_url,
                        $resumo,
                        $postType->label
                    );
                    array_push($posts['data'], $obj);
                }
            }
        }
        return $posts;
    }

    public function get_tema_principal($idPost, $field)
    {
        $idTema = $this->get_post_meta($idPost, $field);
        $term = get_term($idTema);
        return new TemaAgencia($term->term_id, $term->name);
    }

    public function get_temas_by_id_post($idPost)
    {
        $temas = array();
        $terms = wp_get_object_terms($idPost, 'tema');

        foreach ($terms as $term) {
            array_push($temas, new TemaAgencia($term->term_id, $term->name));
        }
        return $temas;

    }

    public function get_tema_do_dia_by_id($id)
    {
        $term = wp_get_object_terms($id, self::TAXONOMY_TEMA_DO_DIA)[0];

        return new TemaAgencia($term->term_id, $term->name);

    }

    private function get_temas_do_dia_by_date($taxonomy, $data)
    {
        $temas = array();
        $args = array(
            'taxonomy' => $taxonomy,
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
            'meta_key' => 'data_do_tema',
            'meta_value' => $data
        );
        $terms = get_terms($args);
        foreach ($terms as $term) {
            $temas[] = array($term->term_id, $term->name);
        }
        return $temas;

    }

    public function get_taxonomy($taxonomy, $term)
    {
        $temas = $this->get_temas_do_dia_by_date($taxonomy, $term);
        if (sizeof($temas) <= 0) {
            $temas = array();
            $args = array(
                'taxonomy' => $taxonomy,
                'hide_empty' => false,
                'orderby' => 'name',
                'order' => 'ASC',
                'search' => $term
            );
            $terms = get_terms($args);
            foreach ($terms as $term) {
                $temas[] = array($term->term_id, $term->name);
            }
        }
        return $temas;
    }

    public function get_posts($term)
    {
        $return = array();
        $search_results = new \WP_Query(array(
            's' => $term,
            'post_status' => 'publish',
            'ignore_sticky_posts' => 1,
            'posts_per_page' => 50
        ));
        if ($search_results->have_posts()) :
            while ($search_results->have_posts()) : $search_results->the_post();
        $id_area = get_post_meta($search_results->post->ID, CamposDB::CD_NOTICIA_AREA, true);
        $area = get_post($id_area);
        $title = $area->post_title . ' - ' . $search_results->post->post_title;
        $return[] = array($search_results->post->ID, $title);
        endwhile;
        endif;
        return $return;
    }

    public function get_tags_by_id_post($idPost)
    {
        $tags = array();
        $terms = wp_get_object_terms($idPost, $this->taxonomyTags);
        foreach ($terms as $term) {
            array_push($tags, new Tags($term->term_id, $term->name));
        }
        return $tags;
    }

    public function pesquisar_tags($term)
    {
        $tags = array();
        $args = array(
                'taxonomy' => $this->taxonomyTags,
                'hide_empty' => false,
                'orderby' => 'name',
                'order' => 'ASC',
                'search' => $term
        );
        $terms = get_terms($args);
        foreach ($terms as $term) {
            array_push($tags, array($term->term_id, $term->name));
        }
        return $tags;

    }

    public function get_tags()
    {
        $tags = array();
        $args = array(
            'taxonomy' => $this->taxonomyTags,
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC'
        );
        $terms = get_terms($args);
        foreach ($terms as $term) {
            array_push($tags, new Tags($term->term_id, $term->name));
        }

        return $tags;
    }

    public function duplicar_post($original_id, $global_settings) {

        $duplicate = get_post( $original_id, 'ARRAY_A' );
        $originalPost = get_post( $original_id);      
        $settings = wp_parse_args( $args, $global_settings );

        $appended = ( $settings['title'] != '' ) ? ' '.$settings['title'] : '';
        $duplicate['post_title'] = $duplicate['post_title'].' - '.$appended;
        $duplicate['post_name'] = sanitize_title($duplicate['post_name'].'-'.$settings['slug']);
        $duplicate['post_status'] = 'draft';

        $timestamp = ( $settings['timestamp'] == 'duplicate' ) ? strtotime($duplicate['post_date']) : current_time('timestamp',0);
	    $timestamp_gmt = ( $settings['timestamp'] == 'duplicate' ) ? strtotime($duplicate['post_date_gmt']) : current_time('timestamp',1);
	
        if( $settings['time_offset'] ) {
            $offset = intval($settings['time_offset_seconds']+$settings['time_offset_minutes']*60+$settings['time_offset_hours']*3600+$settings['time_offset_days']*86400);
            if( $settings['time_offset_direction'] == 'newer' ) {
                $timestamp = intval($timestamp+$offset);
                $timestamp_gmt = intval($timestamp_gmt+$offset);
            } else {
                $timestamp = intval($timestamp-$offset);
                $timestamp_gmt = intval($timestamp_gmt-$offset);
            }
        }

        $duplicate['post_date'] = date('Y-m-d H:i:s', $timestamp);
        $duplicate['post_date_gmt'] = date('Y-m-d H:i:s', $timestamp_gmt);
        $duplicate['post_modified'] = date('Y-m-d H:i:s', current_time('timestamp',0));
        $duplicate['post_modified_gmt'] = date('Y-m-d H:i:s', current_time('timestamp',1));

        // Remove os identificadores
        unset( $duplicate['ID'] );
        unset( $duplicate['guid'] );
        unset( $duplicate['comment_count'] );

        // Insere o novo post no banco de dados
        $duplicate_id = wp_insert_post( $duplicate );
        
        $noticia = $this->carregar_modelo($originalPost);  

        // Grava o novo post
        $this->save($duplicate_id, $noticia);

        // Ação executada quando um post é duplicado
        do_action( 'camara_agencia_post_duplicator_created', $original_id, $duplicate_id, $settings );
        
        return $duplicate_id;
    }

    private function carregar_modelo ($post) {
        return new NoticiaAgencia(
            $this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_TIPO),
            $this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_VISIVEL_HOME),
            $this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_VISIVEL_BOLETIM),
            $this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_RODAPE),
            $this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_PORTAL_CONGRESSO),
            $this->get_tema_principal($post->ID, CamposDB::CD_NOTICIA_TEMA_PRINCIPAL, 'tema'),
            $this->get_temas_by_id_post($post->ID),
            $this->get_relacionadas($post->ID, CamposDB::CD_NOTICIA_RELACIONADA),
            $this->get_tema_do_dia_by_id($post->ID, CamposDB::CD_NOTICIA_TEMA_DO_DIA),
            $this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_TIPO_MIDIA),
            $this->get_continuacao($post->ID, CamposDB::CD_NOTICIA_CONTINUACAO),
            $this->validationUtil->extrairData($this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_DATA_ATUALIZACAO)),
            $this->validationUtil->extrairHora($this->get_post_meta($post->ID, CamposDB::CD_NOTICIA_DATA_ATUALIZACAO)),
            $this->get_tags_by_id_post($post->ID),
            $post->post_excerpt,
            $this->get_deputados($post->ID, CamposDB::CD_DEPUTADOS),
            $this->get_proposicoes($post->ID, CamposDB::CD_PROPOSICOES),
            $this->get_legislacoes($post->ID, CamposDB::CD_LEGISLACOES)
        );
    }

    public function save($post_ID, $noticia)
    {
        $areaConteudoNoticias = $this->get_area_conteudo('noticias');
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_AREA, $areaConteudoNoticias->ID);
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_TIPO, $noticia->getTipo());
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_VISIVEL_HOME, $noticia->getVisivelHomeBoolean());
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_VISIVEL_BOLETIM, $noticia->getVisivelBoletimBoolean());
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_RODAPE, $noticia->getRodape());
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_RETRANCA, $noticia->getRetranca());
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_PORTAL_CONGRESSO, $noticia->getNoticiaPortalCongressoBoolean());
        update_post_meta($post_ID, CamposDB::CD_NOTICIA_TIPO_MIDIA, $noticia->getTipoMidia());

        $this->save_tema_principal($post_ID, $noticia->getTemaPrincipal());
        $this->save_tema_do_dia($post_ID, $noticia->getTemaDoDia());
        $this->save_temas($post_ID, $noticia->getTemas());
        $this->save_data_atualizacao($post_ID, $noticia);
        $this->save_relacionadas($post_ID, $noticia->getRelacionadas());
        $this->save_continuacao($post_ID, $noticia->getContinuacao());
        $this->save_deputados($post_ID, $noticia->getDeputados());
        $this->save_proposicoes($post_ID, $noticia->getProposicoes());
        $this->save_legislacoes($post_ID, $noticia->getLegislacoes());
        $this->save_tags($post_ID, $noticia->getTags());
    }

    public function save_nova_tag($novaTag)
    {
        $tagInsirida = '';
        $verificaTag = term_exists($novaTag, $this->taxonomyTags);
        if(!$verificaTag){
            wp_insert_term(
                $novaTag,
                $this->taxonomyTags,
                array()
            );
            $term = term_exists($novaTag, $this->taxonomyTags);
            $tagInsirida = array('term_id' => $term['term_id'], 'term_name' => $novaTag);
        } 
        return $tagInsirida;
    }

    public function incluir_novo_tema_do_dia($novoTemaDoDia)
    {
        if(!term_exists($novoTemaDoDia, self::TAXONOMY_TEMA_DO_DIA)){
            wp_insert_term(
                $novoTemaDoDia,
                self::TAXONOMY_TEMA_DO_DIA
            );
            $term = term_exists($novoTemaDoDia, self::TAXONOMY_TEMA_DO_DIA);
            return array('term_id' => $term['term_id'], 'term_name' => $novoTemaDoDia);
        } 
    }

    private function save_tema_do_dia ($post_ID, $temaDoDia) {
        if ($temaDoDia instanceof TemaAgencia)
                $temaDoDia = $temaDoDia->getId();
        wp_set_object_terms($post_ID, (int) $temaDoDia, self::TAXONOMY_TEMA_DO_DIA);

    }

    private function save_tema_principal ($post_ID, $temaPrincipal) {
        if (!is_null($temaPrincipal)) {
            // Verifica se é uma instancia
            if ($temaPrincipal instanceof TemaAgencia)
                $temaPrincipal = $temaPrincipal->getId();
            update_post_meta($post_ID, CamposDB::CD_NOTICIA_TEMA_PRINCIPAL, $temaPrincipal);
        }
    }

    private function save_data_atualizacao($post_ID, $noticia){
        if($noticia->getDataAtualizacao()){
            update_post_meta(
                $post_ID, 
                CamposDB::CD_NOTICIA_DATA_ATUALIZACAO, 
                $this->validationUtil->agregandoDataHoraParaString($noticia->getDataAtualizacao(), $noticia->getHoraAtualizacao()));
        }
    }

    private function save_tags($post_ID, $idsTags){
        $tagsAntigas = wp_get_object_terms($post_ID, $this->taxonomyTags);
        if ($tagsAntigas) {
            foreach ($tagsAntigas as $tag) {
                wp_remove_object_terms($post_ID, $tag->term_id, $this->taxonomyTags);
            }
        }
        if ($idsTags) {
            foreach ($idsTags as $idTag) {
                if ($idTag instanceof Tags)
                    $idTag = $idTag->getId();
                wp_set_object_terms($post_ID, (int) $idTag, $this->taxonomyTags, true);
            }
        }
    }

    private function save_relacionadas ($post_ID, $idsRelacionadas) {
        delete_post_meta($post_ID, CamposDB::CD_NOTICIA_RELACIONADA);

        if (isset($idsRelacionadas['ids']))
            $idsRelacionadas = $idsRelacionadas['ids'];

        if($idsRelacionadas) {
            foreach($idsRelacionadas as $id) {
                if (!is_null($id))
                    add_post_meta($post_ID, CamposDB::CD_NOTICIA_RELACIONADA, (int) $id);
            }
        }
    }

    private function save_deputados ($post_ID, $idsDeputados) {
        if($idsDeputados) {
            $idsDeputadosNaoDuplicados = array_unique($idsDeputados);
        }
        delete_post_meta($post_ID, CamposDB::CD_DEPUTADOS);
        if($idsDeputadosNaoDuplicados) {
            foreach($idsDeputadosNaoDuplicados as $id) {
                if (!is_null($id))
                    add_post_meta($post_ID, CamposDB::CD_DEPUTADOS, $id);
            }
        }
    }

    private function save_proposicoes ($post_ID, $idsProposicoes) {
        if($idsProposicoes) {
            $idsProposicoes = array_unique($idsProposicoes);
        }
        delete_post_meta($post_ID, CamposDB::CD_PROPOSICOES);
        if($idsProposicoes) {
            foreach($idsProposicoes as $id) {
                if (!is_null($id))
                    add_post_meta($post_ID, CamposDB::CD_PROPOSICOES, $id);
            }
        }
    }

    private function save_legislacoes ($post_ID, $idsLegislacoes) {
        if($idsLegislacoes) {
            $idsLegislacoes = array_unique($idsLegislacoes);
        }
        delete_post_meta($post_ID, CamposDB::CD_LEGISLACOES);
        if($idsLegislacoes) {
            foreach($idsLegislacoes as $id) {
                if (!is_null($id))
                    add_post_meta($post_ID, CamposDB::CD_LEGISLACOES, $id);
            }
        }
    }

    private function save_continuacao ($post_ID, $idsContinuacao) {
        delete_post_meta($post_ID, CamposDB::CD_NOTICIA_CONTINUACAO);
        if($idsContinuacao) {
            foreach($idsContinuacao as $id) {
                if (!is_null($id))
                    add_post_meta($post_ID, CamposDB::CD_NOTICIA_CONTINUACAO,  $id);
            }
        }
    }

    private function save_temas($post_ID, $idsTemas)
    {
        $temasAntigos = wp_get_object_terms($post_ID, 'tema');
        if ($temasAntigos) {
            foreach ($temasAntigos as $tema) {
                wp_remove_object_terms($post_ID, $tema->term_id, 'tema');
            }
        }
        if ($idsTemas) {
            foreach ($idsTemas as $idTema) {
                if ($idTema instanceof TemaAgencia)
                    $idTema = $idTema->getId();
                wp_set_object_terms($post_ID, (int) $idTema, 'tema', true);
            }
        }
    }

    public function get_temas()
    {
        $temas = array();
        $args = array(
            'taxonomy' => 'tema',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC'
        );
        $terms = get_terms($args);
        foreach ($terms as $term) {
            array_push($temas, new TemaAgencia($term->term_id, $term->name));
        }

        return $temas;
    }

    public function get_area_conteudo($post_name)
    {
        return get_posts(array('post_type' => 'areaconteudo', 'name' => $post_name))[0];
    }

    public function get_post_type($id)
    {
        return get_post_type($id);
    }

    public function get_post_meta_array($postId, $field)
    {
        return get_post_meta($postId, $field, false);
    }

    public function get_post_meta($postId, $field)
    {
        return get_post_meta($postId, $field, true);
    }

    public function add_post_type_support($postType, $fields)
    {
        foreach ($fields as $value) {
            add_post_type_support($postType, $value);
        }
    }

    public function get_option($name)
    {
        return get_option($name);
    }

    public function json_decode($value)
    {
        return json_decode($value);
    }

    public function json_encode($value)
    {
        return json_encode($value);
    }

    public function update_option($name, $autoload)
    {
        return update_option($name, $autoload);
    }

    public function get_permalink()
    {
        return get_permalink(get_the_ID());
    }

    /** PAINEL STATUS MATERIA */

    public function array_random_color($arr, $num = 1) {
        shuffle($arr);
        $r = array();
        for ($i = 0; $i < $num; $i++) {
            $r[] = $arr[$i];
        }
        return $num == 1 ? $r[0] : $r;
    }

    public function get_status_materia ($postType) {
        global $wpdb;
        return $wpdb->get_col("SELECT DISTINCT post_status FROM $wpdb->posts WHERE post_type = '$postType'");
    }

    public function get_status_names () {
        $array_status_name = array();
        $status_name = $this->get_status_materia(ConfigPlugin::POST_TYPE_NAME);
        foreach ($status_name as $status) {
            $array_status_name[$status] = array();
        }
        return $array_status_name;
    }

    public function get_array_status_ordem () {
        $status = array(
            'publish' => 4,
            'draft' => 0,
            'pending' => 1,
            'liberado' => 3,
            'edicao' => 2
        );
        // Ordena o array
        asort($status);

        return $status;
    }

    public function get_array_status_name () {
        $status = array(
            'publish' => 'PUBLICADO',
            'draft' => 'RASCUNHO',
            'pending' => 'PENDENTE',
            'liberado' => 'LIBERADO',
            'edicao' => 'EDIÇÃO'
        );
        return $status;
    }

    public function get_video_nao_associado ($queryParams) {
        global $wpdb;

        // Monta o filtro de data
        if (isset($queryParams['dateParm'])) {
            $dateFilter = " AND DATE(p.post_date) = '".$queryParams['dateParm']."' ";
        } else {
            $dateFilter = " AND DATE(p.post_date) = CURDATE() ";
        }

        $querystr = "
            SELECT p.*, DATE_FORMAT(p.post_date, '%Y-%m-%d')
            FROM $wpdb->posts p
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type LIKE 'video%'
            ".$dateFilter."
            AND p.post_parent = 0
            ORDER BY p.post_date DESC
        ";
        $result = $wpdb->get_results($querystr, OBJECT);
        return $result;
    }

    public function get_audio_nao_associado ($queryParams) {
        global $wpdb;
        
        // Monta o filtro de data
        if (isset($queryParams['dateParm'])) {
            $dateFilter = " AND DATE(p.post_date) = '".$queryParams['dateParm']."' ";
        } else {
            $dateFilter = " AND DATE(p.post_date) = CURDATE() ";
        }

        $querystr = "
            SELECT p.*, DATE_FORMAT(p.post_date, '%Y-%m-%d') as custom_post_date
            FROM $wpdb->posts p
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type LIKE 'audio%'
            ".$dateFilter."
            AND p.post_parent = 0
            ORDER BY p.post_date DESC
        ";
        $result = $wpdb->get_results($querystr, OBJECT);
        return $result;    
    }

    public function associar_midia ($postId, $midiaId, $midia_type) {
               
        if ($midia_type  == 'audio') {
            $result = add_post_meta($postId, CamposDB::CD_POST_AUDIO, $midiaId);
        } else {
            $result = add_post_meta($postId, CamposDB::CD_POST_VIDEO, $midiaId);
        }

        $this->update_post_parent($postId, $midiaId);

        return $result;
    }

    private function update_post_parent ($postId, $midiaId) {
        global $wpdb;
        /**
        * Adicionado ao post_parent para query de midias no painel e dashboard
        * Atualizando post_parent via wpdb pois o wp_update_post gera um erro desconhecido.
        */ 
        $wpdb->update($wpdb->posts, array( 'post_parent' => $postId), array('ID' => $midiaId));
    }

    public function get_materias_do_dia ($queryParams) {
        // Este parametro só é utilizando em audio e video
        unset($queryParams['dateParm']);

        $defaultPostStatus = array();
        $queryParams['post_type'] = ConfigPlugin::POST_TYPE_NAME;
        $queryParams['post_status__in'] = $this->get_status_names();
        $queryParams['posts_per_page'] = -1;

        $query = new \WP_Query( $queryParams );
        // Agrupa as materias do dia por status
        foreach ($query->posts as $key => $post) {

            $status = $post->post_status;
            
            if (isset($defaultPostStatus[$status]['count'])) {
                $defaultPostStatus[$post->post_status]['count'] += 1;
                array_push($defaultPostStatus[$status]['posts'], $post);

            } else {
                $defaultPostStatus[$status]['count'] = 1;
                $defaultPostStatus[$status]['posts'] = array($post);

            }
        }

        // Ordenação dos status
        $ordem = $this->get_array_status_ordem();
        $statusArrayOrder = array();

        foreach ($ordem as $key => $value) {
            if (isset($defaultPostStatus[$key])) {
                $statusArrayOrder[$key] = $defaultPostStatus[$key];
            }
        }
        return $statusArrayOrder;
    }

    /** METODOS UTILIZADOS PELA REST API */

    public function obter_objeto_por_id($id) {
        
        if (!is_numeric($id))
            return new WP_Error('bad_request', __('Requisição inválida.', 'camara-noticias-rest-api'), array('status' => 400, ));

        $post = get_post($id);

        if (is_null($post))
            return new WP_Error('not_found', __('Notícia não encontrada.', 'camara-noticias-rest-api'), array('status' => 404, ));

        return new Noticia($post);
    }

    public function obter_ultimas_noticias ($params, $tema) {
        $args = array(
            'post_type' => 'any', 
            'orderby' => 'publish_date', 
            'order' => 'DESC',
            'meta_query' => array(
                array(
                    'key' => 'portal_do_congresso',
                    'value' => '1'
                )
            )
        );

        // Valida e verifica se o valor é um id ou titulo
        if (!is_null($tema)) {
            // Se for titulo
            $teste = preg_match('/[^A-Za-z0-9]/', $tema);
            if (preg_match('/[^A-Za-z0-9]/', $tema)) {
                $argsTema = array('post_type' => 'tema', 'title' =>  $tema);
                $queryTema = new \WP_Query($argsTema);
                if ( $queryTema->have_posts() ) {
                    $posts = $queryTema->posts;
                    foreach ($posts as $post) {
                        $arrayFilterTema = array('key' => 'tema_principal','value' => $post->ID);
                        array_push ($args['meta_query'], $arrayFilterTema);     
                    }
                }
            }
            // Se for ID
            if (is_numeric($tema)) {
                $arrayFilterTema = array('key' => 'tema_principal', 'value' => $tema);
                array_push ($args['meta_query'], $arrayFilterTema);
            }
        }

        // Adiciona os parametros extras à query
        foreach ($params as $key => $value) {
            $args[$key] = $value;
        }
        // Realiza a query
        $query = new \WP_Query($args);
        return $this->converte_noticias_padrao_site_congresso($query->posts);
    }

    private function converte_noticias_padrao_site_congresso ($posts) {
        $list_posts = array();
        foreach ($posts as $post) {

            $link = null;

            if (!is_null(constant('NOTICIAS_BASE_URL')) && !empty(constant('NOTICIAS_BASE_URL'))) 
                $link = constant('NOTICIAS_BASE_URL').$post->ID.'-'.$post->post_name;
            
            array_push($list_posts, 
                array(
                    'id' => $post->ID, 
                    'data' => strtotime($post->post_date),
                    'titulo' => $post->post_title,
                    'resumo' => get_post_meta($post->ID, 'resumo')[0],
                    'link' => $link
                )
            );
        }
        return array('list' => $list_posts);
    }
}
?>