<?php namespace noticias\service;

require_once(plugin_dir_path(__FILE__) . '../domain/proposicoes.php');
require_once(plugin_dir_path(__FILE__) . '../domain/deputado.php');
require_once(plugin_dir_path(__FILE__) . '../domain/resultado-pesquisa-proposicoes.php');

use noticias\domain\Proposicoes as Proposicoes;
use noticias\domain\ResultadoPesquisaProposicoes as ResultadoPesquisaProposicoes;



class ProposicoesService
{

    const URL_DADOS_ABERTOS = 'https://dadosabertos.camara.leg.br/api/v2';

    public function retornar_regex_proposicoes()
    {

        $result = $this->exec_url(self::URL_DADOS_ABERTOS . '/referencias/tiposProposicao');
        $regex = '(';
        if ($result->dados && sizeof($result->dados) > 0) {
            foreach ($result->dados as $dado) {
                if (!strpos($regex, $dado->sigla) && !empty($dado->sigla)) {
                    $sigla = $dado->sigla;
                    if (in_array($sigla, Proposicoes::MAP_SIGLAS_EXCLUIDAS)) {
                        continue;
                    }
                    if (strpos($dado->sigla, '(')) {
                        $sigla = str_replace("(", "\(", $sigla);
                        $sigla = str_replace(")", "\)", $sigla);
                    }
                    if (strpos($dado->sigla, '/')) {
                        $sigla = str_replace("/", "\/", $sigla);
                    }
                    $regex .= $sigla . '|';
                }
            }
            $regex .= Proposicoes::ADICIONAIS_REGEX_SIGLA . ')' . Proposicoes::PARTIAL_REGEX;
        }

        return $regex;
    }

    public function pesquisa_proposicoes_por_id($ids)
    {

        $result = $this->exec_url(self::URL_DADOS_ABERTOS . '/proposicoes?' . $ids);
        $proposicoes = array();
        if ($result->dados && sizeof($result->dados) > 0) {
            foreach ($result->dados as $dado) {
                array_push($proposicoes,  new ResultadoPesquisaProposicoes(null, new Proposicoes(
                    $dado->id,
                    $dado->siglaTipo,
                    $dado->numero,
                    $dado->ano,
                    true,
                    true
                ), null));
            }
        }
        return $proposicoes;
    }

    public function pesquisar_proposicoes($props)
    {
        $regex_sem_resultado = null;
        if (sizeof($props) == 1 && strpos($props[0], '-')) {
            $str_array = explode('-', $props[0]);
            $regex_sem_resultado = $str_array[1];
            $props[0] = $str_array[0];
        }
        $proposicoes = array();
        foreach ($props as $prop) {
            $arrayProp = explode("/", $prop);
            $ano = $arrayProp[1];
            $siglaENumero = explode(" ", $arrayProp[0]);
            $sigla = $siglaENumero[0];
            $numero = $siglaENumero[1];
            $proposicao = $sigla . " " . $numero . '/' . $ano;
            $siglaPesquisa = Proposicoes::MAP_SIGLAS[$sigla] != null ? Proposicoes::MAP_SIGLAS[$sigla] : $sigla;
            $url = self::URL_DADOS_ABERTOS . '/proposicoes?siglaTipo=' . $siglaPesquisa . '&numero=' . $numero . '&ano=' . $ano;
            $proposicoes = $this->pesquisar($url, $proposicoes, $proposicao, $siglaPesquisa, $numero, $ano, $regex_sem_resultado);
        }
        return $proposicoes;
    }

    private function pesquisar($url, $proposicoes, $proposicao, $siglaPesquisa, $numero, $ano, $regex_sem_resultado)
    {
        $qtdConsultas = 0;
        while ($qtdConsultas < 3) {
            if ($qtdConsultas == 1) {
                // Sigla + Numero
                $url = self::URL_DADOS_ABERTOS . '/proposicoes?siglaTipo=' . $siglaPesquisa . '&numero=' . $numero;
            }
            if ($qtdConsultas == 2) {
                // Sigla + Ano
                $url = self::URL_DADOS_ABERTOS . '/proposicoes?siglaTipo=' . $siglaPesquisa . '&ano=' . $ano;
            }
            $result = $this->exec_url($url);
            if ($result->dados) {
                $proposicoes = $this->adiciona_proposicao($proposicoes, $result, $regex_sem_resultado, $proposicao);
                break;
            }
            $qtdConsultas++;
        }
        if (!$result->dados) {
            array_push($proposicoes, new ResultadoPesquisaProposicoes($regex_sem_resultado == null ? $proposicao : $regex_sem_resultado, new Proposicoes(null, $proposicao, null, null, false, false), null));
        }
        return $proposicoes;
    }

    private function adiciona_proposicao($proposicoes, $result, $regex_sem_resultado, $proposicao)
    {
        if (sizeof($result->dados) == 1) {
            $dado = $result->dados[0];
            array_push($proposicoes,  new ResultadoPesquisaProposicoes($regex_sem_resultado == null ? $proposicao : $regex_sem_resultado, new Proposicoes(
                $dado->id,
                $dado->siglaTipo,
                $dado->numero,
                $dado->ano,
                true,
                false
            ), null));
        } else {
            $opcoesProposicoes = array();
            foreach ($result->dados as $dado) {
                array_push($opcoesProposicoes, new Proposicoes(
                    $dado->id,
                    $dado->siglaTipo,
                    $dado->numero,
                    $dado->ano,
                    true,
                    false
                ));
            }
            array_push($proposicoes, new ResultadoPesquisaProposicoes($regex_sem_resultado == null ? $proposicao : $regex_sem_resultado, null, $opcoesProposicoes));
        }
        return $proposicoes;
    }

    private function exec_url($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, str_replace(" ", "%20", $url)); //Url together with parameters
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('accept:application/json'));
        $resultado = json_decode(curl_exec($ch));
        curl_close($ch);
        return $resultado;
    }
}
