<?php namespace noticias\config;
require_once(plugin_dir_path(__FILE__) . '../service/noticias-service.php');
require_once(plugin_dir_path(__FILE__) . '../service/deputado-service.php');
require_once(plugin_dir_path(__FILE__) . '../service/proposicoes-service.php');
require_once(plugin_dir_path(__FILE__) . '../service/legislacoes-service.php');
require_once(plugin_dir_path(__FILE__) . '../service/glossario-service.php');

use noticias\service\NoticiasService as NoticiasService;
use noticias\service\DeputadoService as DeputadoService;
use noticias\service\ProposicoesService as ProposicoesService;
use noticias\service\LegislacoesService as LegislacoesService;
use noticias\service\GlossarioService as GlossarioService;

class ConfigService {
    
    public function noticiasService () {
        return new NoticiasService($this->deputadoService(), $this->proposicoesService(), $this->legislacoesService());
    }

    public function deputadoService () {
        return new DeputadoService();
    }

    public function proposicoesService () {
        return new ProposicoesService();
    }

    public function legislacoesService () {
        return new LegislacoesService();
    }

    public function glossarioService () {
        return new GlossarioService();
    }
}

?>