<?php namespace noticias\config;

require_once(plugin_dir_path(__FILE__) . './config-form.php');
require_once(plugin_dir_path(__FILE__) . './config-styles.php');
require_once(plugin_dir_path(__FILE__) . './config-scripts.php');
require_once(plugin_dir_path(__FILE__) . '../domain/actions-ajax.php');

use noticias\config\ConfigForm as ConfigForm;
use noticias\config\ConfigStyles as ConfigStyles;
use noticias\config\ConfigScripts as ConfigScripts;
use noticias\domain\ActionsAjax as ActionsAjax;

class ConfigPlugin
{
    private const PLUGIN_NAME = 'Notícias';
    private const PLUGIN_SINGULAR_NAME = 'Notícias';
    private const PLUGIN_DESCRIPTION = 'Posts de Notícias';
    private const PLUGIN_ADD_NEW = 'Nova Notícia';
    private const PLUGIN_SEARCH_ITEMS = 'Pesquisar Notícias';
    private const PLUGIN_ADD_NEW_ITEM = 'Adicionar Nova Notícia';
    private const PLUGIN_EDIT_ITEM = 'Editar Notícia';
    public const POST_TYPE_NAME = 'agencia';
    public const PAINEL_STATUS_NAME = 'Painel de Notícias';
    public const PAINEL_STATUS_DESCRIPTION = 'Painel de Notícias';
    private const URL_PREVIEW_TES = 'https://socittes.camara.gov.br';
    private $baseUrl;
    private $actions_ajax;
    private $configScripts;

    public function __construct($baseUrl)
    {
        $this->baseUrl = $baseUrl;
        $this->actions_ajax = array();
        $this->configScripts = new ConfigScripts();
    }

    public function config()
    {
        $this->register_post_type();

        if ($this->isWPPreview()) {
            return $this->process(true);
        }
        if ($this->isHeartbeat()) {
            return $this->process(true);
        }
        if ($this->isActionAjaxCustom()) {
            return $this->process(true);
        }
        if ($this->isPostTypeValid()) {
            return $this->process(true);
        }
        return false;
    }

    private function process($valid) {
        if ($valid) {
            new ConfigStyles($this->baseUrl);
            $this->configScripts->config_scripts($this->baseUrl);
            $this->configForm()->config_remove_meta_box(self::POST_TYPE_NAME);
        }
        return $valid;
    }

    public function configForm()
    {
        return new ConfigForm();
    }

    public function add_ajax_action($action, $callback)
    {
        $this->configScripts->add_ajax_action($action, $callback);
    }
    
    public function register_post_type()
    {
        register_post_type(self::POST_TYPE_NAME, $this->config_post_type());
    }

    private function config_post_type()
    {
        return array(
            'labels' => array(
                'name' => self::PLUGIN_NAME,
                'singular_name' => self::PLUGIN_SINGULAR_NAME,
                'add_new' => self::PLUGIN_ADD_NEW,
                'search_items' => self::PLUGIN_SEARCH_ITEMS,
                'add_new_item' => self::PLUGIN_ADD_NEW_ITEM,
                'edit_item' => self::PLUGIN_EDIT_ITEM
            ),
            'description' => self::PLUGIN_DESCRIPTION,
            'supports' => array(
                'title', 'editor', 'revisions'
            ),
            'public' => true,
            'menu_icon' => 'dashicons-book',
            'menu_position' => 16,
            'rewrite' => false
        );

    }

    function alter_link_preview( $actions, $post ) {
        if ($post->post_type == self::POST_TYPE_NAME) {
            $actions['view'] = '<a href="' . $this->get_link_preview() . '">Visualizar</a>';
        }
        return $actions;
    }

    private function isHeartbeat () {
        return $_POST['action'] == 'heartbeat' && $_POST['screen_id'] == self::POST_TYPE_NAME;
    }

    private function isWPPreview () {
        return isset($_POST['wp-preview']) && 'dopreview' == $_POST['wp-preview']  && $_POST['post_type'] == self::POST_TYPE_NAME;
    }

    private function isActionAjaxCustom () {
        if ($_POST['action'] || $_GET['action'] != 'edit') {
            $actions_ajax = ActionsAjax::getValores();
            if (in_array($_POST['action'], $actions_ajax) || in_array($_GET['action'], $actions_ajax)) {
                return true;
            }
        }
        return false;
    }

    private function isPostTypeValid() {
        if ($_GET['post_type'] || $_GET['post'] || $_POST['post_type']) {
            $post_type = $_GET['post_type'] ? $_GET['post_type'] : get_post_type($_GET['post']);
            if ($post_type == self::POST_TYPE_NAME || $_POST['post_type'] == self::POST_TYPE_NAME) {
                return true;
            }
        }
        return false;
    }
}

?>