<?php namespace noticias\config;

class ConfigStyles {

    public function __construct($baseUrl) {
        $this->config_styles($baseUrl);
    }

    private function config_styles($baseUrl) {
        
        wp_register_style('noticia-css', $baseUrl . '/view/css/noticia.css');
        wp_enqueue_style('noticia-css');
        wp_register_style('noticia-select2-css', $baseUrl . '/view/css/select2.min.css');
        wp_enqueue_style('noticia-select2-css');
        wp_register_style('camara-datatables', $baseUrl . '/view/css/datatables.min.css');
        wp_enqueue_style('camara-datatables');
        
        if($_GET['page'] == 'painel-status-materia') {
            wp_register_style('bootstrap-painel-status-css', $baseUrl . '/view/css/bootstrap.min.css');
            wp_enqueue_style('bootstrap-painel-status-css');
            wp_register_style('painel-status-css', $baseUrl . '/view/css/painel-status.css');
            wp_enqueue_style('painel-status-css');

            wp_register_style('modal-loading', $baseUrl . '/view/css/jquery.loadingModal.css');
            wp_enqueue_style('modal-loading');
     
        }
        
    }
}

?>