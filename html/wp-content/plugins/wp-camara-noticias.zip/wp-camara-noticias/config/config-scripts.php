<?php namespace noticias\config;

class ConfigScripts
{

    public function __construct()
    {
        $this->actions_ajax = array();
    }

    public function add_ajax_action($action, $callback)
    {
        $this->validatorCallbackActions($callback);
        add_action('wp_ajax_' . $action, $callback);
        add_action('wp_ajax_nopriv_' . $action, $callback);
        return $action;
    }

    public function get_actions_ajax()
    {
        return $this->actions_ajax;
    }

    public function config_scripts($baseUrl)
    {
        global $pagenow;

        if ($pagenow != 'edit.php') {

            wp_enqueue_script('jquery');

            wp_enqueue_script('jquery-ui-tooltip');

            wp_enqueue_script('custom_form_js', $baseUrl . '/view/js/custom-scripts.js');
            wp_enqueue_script('select2-js', $baseUrl . '/view/js/select2.min.js');

            // Alterado para ter o mesmo id em todos os plugins
            wp_enqueue_script('camara-datatables', $baseUrl . '/view/js/datatables.min.js');

            //TODO falta a implementacao do autosave para os campos customizados, ou seja, quando forem alterados tem que disparar o autosave
            wp_enqueue_script('autosave_custom', $baseUrl . '/view/js/autosave.js');
            wp_enqueue_script('validador_noticia', $baseUrl . '/view/js/form-validator.js');
            wp_enqueue_script('autocomplete_noticia', $baseUrl . '/view/js/autocomplete.js');
            wp_enqueue_script('materias_relacionadas', $baseUrl . '/view/js/materias-relacionadas.js');
            wp_enqueue_script('materias_continuacao', $baseUrl . '/view/js/materias-continuacao.js');
            wp_enqueue_script('i18n_pt_BR', $baseUrl . '/view/js/pt-BR.js');

            wp_enqueue_script('tabela_deputados', $baseUrl . '/view/js/deputados/tabela-deputados.js');
            wp_enqueue_script('associa_deputados', $baseUrl . '/view/js/deputados/associa-deputados.js');
            wp_enqueue_script('tabela_proposicoes', $baseUrl . '/view/js/proposicoes/tabela-proposicoes.js');
            wp_enqueue_script('associa_proposicoes', $baseUrl . '/view/js/proposicoes/associa-proposicoes.js');
            wp_enqueue_script('tabela_legislacoes', $baseUrl . '/view/js/legislacoes/tabela-legislacoes.js');
            wp_enqueue_script('associa_legislacoes', $baseUrl . '/view/js/legislacoes/associa-legislacoes.js');

            wp_enqueue_script('tabela_glossarios', $baseUrl . '/view/js/glossario/tabela-glossarios.js');
            wp_enqueue_script('associa_glossarios', $baseUrl . '/view/js/glossario/associa-glossario.js');
            wp_enqueue_script('ajax-pesquisa', $baseUrl . '/view/js/ajax-pesquisa.js');

            wp_enqueue_script('mascara_input', $baseUrl . '/view/js/inputTextMask.js');

        } else {

            wp_enqueue_script('jquery');
            wp_enqueue_script('duplicate_post_js', $baseUrl . '/view/js/post-duplicate.js');

        }

        if ($_GET['page'] == 'painel-status-materia') {

            wp_enqueue_script('jquery-ui-widget');
            wp_enqueue_script('jquery-ui-autocomplete');
            wp_enqueue_script('jquery-ui-datepicker');

            wp_enqueue_script('bootstrap_js', $baseUrl . '/view/js/bootstrap.min.js');
            wp_enqueue_script('modal_loading_js', $baseUrl . '/view/js/jquery.loadingModal.js');
            wp_enqueue_script('painel_status_js', $baseUrl . '/view/js/painel-status.js');
        }
    }

    private function validatorCallbackActions($callback)
    {
        if (!is_array($callback)) {
            throw new \Exception('O formato do callback deve ser um array. Ex: array($this, "nome do método") ');
        }
    }
}
